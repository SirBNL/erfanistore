<?php
/**
 * ============================================================
 *  فروشگاه آنلاین  -  index.php
 *  PHP خالص + SQLite
 *  فروش + انبار چندگانه + حسابداری + تخفیف + کالابرگ + کد تخفیف
 * ============================================================
 */

error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE);
ini_set('display_errors', 0);
date_default_timezone_set('Asia/Tehran');
session_start();

define('DB_FILE', __DIR__ . '/shop_data.sqlite');
define('UPLOAD_DIR', __DIR__ . '/uploads');

if (!is_dir(UPLOAD_DIR)) @mkdir(UPLOAD_DIR, 0755, true);

// =====================================================
//  دیتابیس
// =====================================================
function db() {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO('sqlite:' . DB_FILE);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $pdo->exec('PRAGMA foreign_keys = ON;');
        init_db($pdo);
    }
    return $pdo;
}

function init_db($pdo) {
    $pdo->exec("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)");
    $pdo->exec("CREATE TABLE IF NOT EXISTS categories (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, sort_order INTEGER DEFAULT 0)");
    $pdo->exec("CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL, description TEXT,
        price INTEGER NOT NULL DEFAULT 0,
        discount_price INTEGER DEFAULT 0,
        discount_percent INTEGER DEFAULT 0,
        cost_price INTEGER DEFAULT 0,
        image TEXT, category_id INTEGER,
        stock INTEGER DEFAULT 0,
        min_stock INTEGER DEFAULT 5,
        is_featured INTEGER DEFAULT 0,
        is_active INTEGER DEFAULT 1,
        barcode TEXT,
        sku TEXT,
        created_at TEXT
    )");
    $pdo->exec("CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_code TEXT, customer_name TEXT NOT NULL, phone TEXT NOT NULL,
        address TEXT NOT NULL, city TEXT DEFAULT '', note TEXT,
        total INTEGER NOT NULL DEFAULT 0,
        subtotal INTEGER DEFAULT 0,
        discount_amount INTEGER DEFAULT 0,
        cost_total INTEGER DEFAULT 0, profit INTEGER DEFAULT 0,
        items TEXT, status TEXT DEFAULT 'pending',
        payment_method TEXT DEFAULT 'cod', voucher_code TEXT,
        discount_code TEXT,
        is_paid INTEGER DEFAULT 0, is_archived INTEGER DEFAULT 0,
        closed_at TEXT, created_at TEXT
    )");
    $pdo->exec("CREATE TABLE IF NOT EXISTS warehouses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL, is_main INTEGER DEFAULT 0,
        is_active INTEGER DEFAULT 1, sort_order INTEGER DEFAULT 0,
        note TEXT, created_at TEXT
    )");
    $pdo->exec("CREATE TABLE IF NOT EXISTS stock (
        product_id INTEGER NOT NULL, warehouse_id INTEGER NOT NULL,
        quantity INTEGER DEFAULT 0,
        PRIMARY KEY (product_id, warehouse_id)
    )");
    $pdo->exec("CREATE TABLE IF NOT EXISTS stock_movements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER NOT NULL, warehouse_id INTEGER NOT NULL,
        from_warehouse_id INTEGER, to_warehouse_id INTEGER,
        type TEXT NOT NULL, quantity INTEGER NOT NULL,
        unit_price INTEGER DEFAULT 0, ref_id INTEGER,
        note TEXT, created_at TEXT
    )");
    $pdo->exec("CREATE TABLE IF NOT EXISTS expenses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL, amount INTEGER NOT NULL,
        category TEXT, expense_date TEXT, note TEXT, created_at TEXT
    )");

    // --- جداول جدید ---
    // تخفیف لحظه‌ای (Flash Sale)
    $pdo->exec("CREATE TABLE IF NOT EXISTS flash_sales (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER NOT NULL,
        discount_percent INTEGER DEFAULT 0,
        discount_price INTEGER DEFAULT 0,
        starts_at TEXT NOT NULL,
        ends_at TEXT NOT NULL,
        is_active INTEGER DEFAULT 1,
        created_at TEXT
    )");

    // کدهای تخفیف
    $pdo->exec("CREATE TABLE IF NOT EXISTS discount_codes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE NOT NULL,
        type TEXT NOT NULL,
        value INTEGER NOT NULL,
        min_order INTEGER DEFAULT 0,
        max_uses INTEGER DEFAULT 0,
        current_uses INTEGER DEFAULT 0,
        max_per_customer INTEGER DEFAULT 0,
        starts_at TEXT,
        ends_at TEXT,
        applies_to TEXT DEFAULT 'all',
        category_id INTEGER,
        product_id INTEGER,
        first_order_only INTEGER DEFAULT 0,
        is_active INTEGER DEFAULT 1,
        created_at TEXT
    )");

    $pdo->exec("CREATE TABLE IF NOT EXISTS discount_code_usage (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code_id INTEGER NOT NULL,
        order_id INTEGER,
        customer_phone TEXT,
        discount_amount INTEGER DEFAULT 0,
        used_at TEXT
    )");

    // تب‌های سفارشی
    $pdo->exec("CREATE TABLE IF NOT EXISTS custom_tabs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL,
        tab_type TEXT NOT NULL,
        filter_data TEXT,
        sort_order INTEGER DEFAULT 0,
        is_active INTEGER DEFAULT 1,
        icon TEXT,
        created_at TEXT
    )");

    // مهاجرت
    $cols = $pdo->query("PRAGMA table_info(products)")->fetchAll(PDO::FETCH_COLUMN, 1);
    $int_cols = ['stock','is_featured','is_active','discount_price','cost_price','discount_percent','min_stock'];
    $text_cols = ['barcode','sku'];
    foreach ($int_cols as $c) {
        if (!in_array($c, $cols)) {
            $def = '0';
            if ($c === 'min_stock') $def = '5';
            $pdo->exec("ALTER TABLE products ADD COLUMN $c INTEGER DEFAULT $def");
        }
    }
    foreach ($text_cols as $c) {
        if (!in_array($c, $cols)) {
            $pdo->exec("ALTER TABLE products ADD COLUMN $c TEXT DEFAULT ''");
        }
    }
    $oc = $pdo->query("PRAGMA table_info(orders)")->fetchAll(PDO::FETCH_COLUMN, 1);
    foreach (['is_paid','payment_method','city','cost_total','profit','is_archived','closed_at','subtotal','discount_amount','voucher_code','discount_code'] as $c) {
        if (!in_array($c, $oc)) {
            $def = ($c === 'is_archived' || $c === 'is_paid' || $c === 'cost_total' || $c === 'profit' || $c === 'subtotal' || $c === 'discount_amount') ? '0' : '';
            $pdo->exec("ALTER TABLE orders ADD COLUMN $c $def");
        }
    }

    // تنظیمات پیش‌فرض
    $defaults = [
        'shop_name'=>'فروشگاه تربت','shop_slogan'=>'خرید آنلاین، تحویل درب منزل',
        'shop_phone'=>'051-00000000','shop_address'=>'تربت حیدریه، خیابان اصلی',
        'shop_about'=>'ما بهترین کالاها را با قیمت مناسب و تحویل درب منزل ارائه می‌دهیم.',
        'shop_instagram'=>'','shop_telegram'=>'','admin_password'=>'admin123',
        'delivery_fee'=>'0','min_order'=>'0','primary_color'=>'#e63946','allowed_city'=>'تربت حیدریه',
        'site_logo'=>'','site_bg_image'=>'','site_bg_text_color'=>'#ffffff','site_bg_overlay'=>'0.4',
        'hero_title'=>'','hero_subtitle'=>'','hero_badge_text'=>'پرداخت درب منزل (نقدی هنگام تحویل)',
        'voucher_payment_label'=>'کالابرگ','voucher_payment_enabled'=>'1',
        'show_voucher_payment'=>'1','show_cod_payment'=>'1',
        'btn_cart_label'=>'سبد خرید','btn_add_to_cart_label'=>'افزودن به سبد',
        'btn_checkout_label'=>'ادامه و ثبت سفارش','btn_continue_label'=>'بازگشت به فروشگاه',
        'btn_phone_label'=>'تماس','btn_address_label'=>'آدرس','btn_search_label'=>'جستجوی محصول...',
        'btn_empty_cart_label'=>'سبد خرید شما خالی است',
        'discount_code_label'=>'کد تخفیف دارید؟','voucher_label'=>'کالابرگ دارید؟',
    ];
    $st = $pdo->prepare("INSERT OR IGNORE INTO settings (key,value) VALUES (?,?)");
    foreach ($defaults as $k=>$v) $st->execute([$k,$v]);

    // مهاجرت مقادیر جدید (در دیتابیس‌های قدیمی)
    foreach (['site_logo'=>'','site_bg_image'=>'','site_bg_text_color'=>'#ffffff','site_bg_overlay'=>'0.4',
              'hero_title'=>'','hero_subtitle'=>'',
              'show_cod_payment'=>'1',
              'btn_cart_label'=>'سبد خرید','btn_add_to_cart_label'=>'افزودن به سبد',
              'btn_checkout_label'=>'ادامه و ثبت سفارش','btn_continue_label'=>'بازگشت به فروشگاه',
              'btn_empty_cart_label'=>'سبد خرید شما خالی است',
              'discount_code_label'=>'کد تخفیف دارید؟',
              'hero_badge_text'=>'پرداخت درب منزل (نقدی هنگام تحویل)'] as $k=>$v) {
        $st->execute([$k,$v]);
    }

    $whc = $pdo->query("SELECT COUNT(*) c FROM warehouses")->fetch()['c'];
    if ($whc == 0) {
        $now = date('Y-m-d H:i:s');
        $pdo->prepare("INSERT INTO warehouses (name,is_main,sort_order,created_at) VALUES (?,1,1,?)")->execute(['انبار اصلی',$now]);
        $pdo->prepare("INSERT INTO warehouses (name,is_main,sort_order,created_at) VALUES (?,0,2,?)")->execute(['انبار ۲',$now]);
    }

    $main = main_warehouse_id();
    $prods = $pdo->query("SELECT id, stock FROM products")->fetchAll();
    $chk = $pdo->prepare("SELECT COUNT(*) c FROM stock WHERE product_id=?");
    $ins = $pdo->prepare("INSERT INTO stock (product_id,warehouse_id,quantity) VALUES (?,?,?)");
    foreach ($prods as $p) {
        $chk->execute([$p['id']]);
        if ($chk->fetch()['c'] == 0 && $p['stock'] > 0) {
            $ins->execute([$p['id'], $main, $p['stock']]);
        }
    }

    $count = $pdo->query("SELECT COUNT(*) c FROM products")->fetch()['c'];
    if ($count == 0) {
        $catStmt = $pdo->prepare("INSERT INTO categories (name,sort_order) VALUES (?,?)");
        $cats = ['خواروبار','لوازم خانگی','دیجیتال','پوشاک'];
        $catIds = [];
        foreach ($cats as $i=>$c) { $catStmt->execute([$c,$i]); $catIds[] = $pdo->lastInsertId(); }
        $samples = [
            ['برنج ایرانی درجه یک', 'برنج طارم معطر ۱۰ کیلوگرمی', 1200000, 990000, 0, 900000, $catIds[0], 25, 1],
            ['روغن مایع سرخ‌کردنی', 'روغن آفتابگردان ۱.۸ لیتری', 180000, 0, 10, 130000, $catIds[0], 40, 0],
            ['چای کله مورچه', 'چای ممتاز ۵۰۰ گرمی', 350000, 299000, 0, 240000, $catIds[0], 30, 1],
            ['پلوپز دیجیتال', 'پلوپز ۸ نفره با صفحه نمایش', 4500000, 3990000, 0, 3200000, $catIds[1], 10, 1],
            ['جاروبرقی', 'جاروبرقی ۲۰۰۰ وات کم مصرف', 6800000, 0, 5, 4900000, $catIds[1], 8, 0],
            ['هندزفری بلوتوثی', 'هندزفری بی‌سیم با کیفیت صدای عالی', 950000, 750000, 0, 620000, $catIds[2], 50, 1],
            ['پاوربانک ۱۰۰۰۰', 'پاوربانک شارژ سریع ۱۰۰۰۰ میلی‌آمپر', 680000, 0, 0, 470000, $catIds[2], 35, 0],
            ['تیشرت نخی مردانه', 'تیشرت نخ پنبه ۱۰۰٪ راحت', 420000, 350000, 15, 230000, $catIds[3], 60, 1],
        ];
        $pStmt = $pdo->prepare("INSERT INTO products (name,description,price,discount_price,discount_percent,cost_price,category_id,stock,is_featured,is_active,created_at) VALUES (?,?,?,?,?,?,?,?,?,1,?)");
        $now = date('Y-m-d H:i:s');
        foreach ($samples as $s) {
            $pStmt->execute([$s[0],$s[1],$s[2],$s[3],$s[4],$s[5],$s[6],$s[7],$s[8],$now]);
            $pid = $pdo->lastInsertId();
            $pdo->prepare("INSERT INTO stock (product_id,warehouse_id,quantity) VALUES (?,?,?)")->execute([$pid,$main,$s[7]]);
        }
    }
}

function setting($key, $default = '') {
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        foreach (db()->query("SELECT key, value FROM settings")->fetchAll() as $r) {
            $cache[$r['key']] = $r['value'];
        }
    }
    return isset($cache[$key]) ? $cache[$key] : $default;
}
function e($s) { return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
function toman($n) { return number_format((int)$n); }

function main_warehouse_id() {
    static $id = null;
    if ($id === null) {
        $r = db()->query("SELECT id FROM warehouses WHERE is_main=1 ORDER BY id ASC LIMIT 1")->fetch();
        $id = $r ? (int)$r['id'] : 1;
    }
    return $id;
}
function get_stock($product_id, $warehouse_id = null) {
    if ($warehouse_id === null) $warehouse_id = main_warehouse_id();
    $st = db()->prepare("SELECT quantity FROM stock WHERE product_id=? AND warehouse_id=?");
    $st->execute([$product_id, $warehouse_id]);
    $r = $st->fetch();
    return $r ? (int)$r['quantity'] : 0;
}

// دریافت تخفیف فعال فلش‌سیل
function get_flash_sale($product_id) {
    $now = date('Y-m-d H:i:s');
    $st = db()->prepare("SELECT * FROM flash_sales WHERE product_id=? AND is_active=1 AND starts_at<=? AND ends_at>=? ORDER BY id DESC LIMIT 1");
    $st->execute([$product_id, $now, $now]);
    return $st->fetch();
}

function eff_price($p, $flash = null) {
    // اولویت: فلش‌سیل > درصد تخفیف > قیمت تخفیف‌خورده
    if ($flash) {
        if ($flash['discount_percent'] > 0 && $flash['discount_percent'] < 100) {
            return (int)round($p['price'] * (1 - $flash['discount_percent'] / 100));
        }
        if ($flash['discount_price'] > 0 && $flash['discount_price'] < $p['price']) {
            return $flash['discount_price'];
        }
    }
    if (!empty($p['discount_percent']) && $p['discount_percent'] > 0 && $p['discount_percent'] < 100) {
        return (int)round($p['price'] * (1 - $p['discount_percent'] / 100));
    }
    if ($p['discount_price'] > 0 && $p['discount_price'] < $p['price']) {
        return $p['discount_price'];
    }
    return $p['price'];
}

// =====================================================
//  سبد خرید
// =====================================================
if (!isset($_SESSION['cart'])) $_SESSION['cart'] = [];
$action = $_REQUEST['action'] ?? '';

if ($action === 'add_to_cart') {
    header('Content-Type: application/json; charset=utf-8');
    $pid = (int)($_POST['product_id'] ?? 0);
    $qty = max(1, (int)($_POST['qty'] ?? 1));
    $pdo = db();
    $p = $pdo->prepare("SELECT id, name, is_active FROM products WHERE id=?");
    $p->execute([$pid]);
    $p = $p->fetch();
    if (!$p || !$p['is_active']) {
        echo json_encode(['ok'=>false, 'error'=>'محصول یافت نشد یا غیرفعال است', 'count'=>array_sum($_SESSION['cart'])]); exit;
    }
    $available = get_stock($pid);
    $cur = $_SESSION['cart'][$pid] ?? 0;
    $new_qty = $cur + $qty;
    if ($available <= 0) {
        echo json_encode(['ok'=>false, 'error'=>'موجودی محصول صفر است', 'count'=>array_sum($_SESSION['cart'])]); exit;
    }
    if ($new_qty > $available) $new_qty = $available;
    $_SESSION['cart'][$pid] = $new_qty;
    echo json_encode(['ok'=>true, 'count'=>array_sum($_SESSION['cart']), 'msg'=>'به سبد خرید اضافه شد ✓']); exit;
}

if ($action === 'update_cart') {
    header('Content-Type: application/json; charset=utf-8');
    $pid = (int)($_POST['product_id'] ?? 0);
    $qty = (int)($_POST['qty'] ?? 0);
    if ($qty <= 0) {
        unset($_SESSION['cart'][$pid]);
    } else {
        $available = get_stock($pid);
        if ($available > 0 && $qty > $available) $qty = $available;
        $_SESSION['cart'][$pid] = $qty;
    }
    echo json_encode(['ok'=>true, 'count'=>array_sum($_SESSION['cart'])]); exit;
}

if ($action === 'cart_count') {
    header('Content-Type: application/json; charset=utf-8');
    echo json_encode(['count'=>array_sum($_SESSION['cart'])]); exit;
}

if (isset($_GET['ajax_cart'])) {
    header('Content-Type: text/html; charset=utf-8');
    $pdo = db();
    $cart_items = [];
    $cart_total = 0;
    if (!empty($_SESSION['cart'])) {
        $in = implode(',', array_map('intval', array_keys($_SESSION['cart'])));
        $rows = $pdo->query("SELECT * FROM products WHERE id IN ($in)")->fetchAll();
        $map = [];
        foreach ($rows as $r) $map[$r['id']] = $r;
        foreach ($_SESSION['cart'] as $pid => $qty) {
            if (isset($map[$pid])) {
                $flash = get_flash_sale($pid);
                $price = eff_price($map[$pid], $flash);
                $cart_items[] = ['p'=>$map[$pid], 'qty'=>$qty, 'price'=>$price, 'line'=>$price*$qty, 'flash'=>$flash];
                $cart_total += $price * $qty;
            }
        }
    }
    ob_start();
    if ($cart_items):
      foreach ($cart_items as $ci): $p=$ci['p']; $curStock = get_stock($p['id']);
    ?>
    <div class="cart-item" data-id="<?= $p['id'] ?>" data-stock="<?= $curStock ?>" data-item-id="<?= $p['id'] ?>">
      <div class="ci-img"><?php if($p['image']): ?><img src="<?= e($p['image']) ?>" alt=""><?php else: ?><i class="fa-solid fa-box"></i><?php endif; ?></div>
      <div class="ci-info">
        <div class="ci-name"><?= e($p['name']) ?></div>
        <div class="ci-price"><?= toman($ci['price']) ?> تومان</div>
        <?php if($ci['flash']): ?><div class="ci-flash"><i class="fa-solid fa-bolt"></i> آخر لحظه</div><?php endif; ?>
        <div class="ci-stock">موجودی: <?= $curStock ?> عدد</div>
        <div class="qty-ctrl">
          <button onclick="window._changeQty(<?= $p['id'] ?>,<?= $ci['qty']-1 ?>)">−</button>
          <span><?= $ci['qty'] ?></span>
          <button onclick="window._changeQty(<?= $p['id'] ?>,<?= $ci['qty']+1 ?>)">+</button>
          <button class="ci-remove" onclick="window._changeQty(<?= $p['id'] ?>,0)" title="حذف"><i class="fa-solid fa-trash"></i></button>
        </div>
      </div>
    </div>
    <?php endforeach;
    else: ?>
    <div class="cart-empty"><i class="fa-solid fa-cart-shopping"></i><p>سبد خرید شما خالی است</p></div>
    <?php endif;
    if ($cart_items): ?>
    <div class="cart-footer">
      <div class="cart-total-row"><span>جمع کالاها:</span><span><?= toman($cart_total) ?> تومان</span></div>
      <div class="cart-total-row"><span>هزینه ارسال:</span><span><?= $delivery_fee>0 ? toman($delivery_fee).' تومان' : 'رایگان' ?></span></div>
      <div class="cart-total-row grand"><span>قابل پرداخت:</span><span><?= toman($cart_total+$delivery_fee) ?> تومان</span></div>
      <button class="btn-checkout" id="openCheckout"><i class="fa-solid fa-bag-shopping"></i> ادامه و ثبت سفارش</button>
    </div>
    <?php endif;
    echo ob_get_clean();
    exit;
}

if ($action === 'clear_cart') {
    $_SESSION['cart'] = [];
    header('Location: index.php'); exit;
}

// اعتبارسنجی کد تخفیف
if ($action === 'validate_discount_code') {
    header('Content-Type: application/json; charset=utf-8');
    $code = trim($_POST['code'] ?? '');
    $subtotal = (int)($_POST['subtotal'] ?? 0);
    $result = ['ok'=>false, 'error'=>''];
    if ($code === '') {
        $result['error'] = 'کد تخفیف را وارد کنید';
    } else {
        $st = db()->prepare("SELECT * FROM discount_codes WHERE code=?");
        $st->execute([$code]);
        $dc = $st->fetch();
        if (!$dc) {
            $result['error'] = 'کد تخفیف نامعتبر است';
        } elseif (!$dc['is_active']) {
            $result['error'] = 'این کد تخفیف غیرفعال است';
        } else {
            $now = date('Y-m-d H:i:s');
            if ($dc['starts_at'] && $dc['starts_at'] > $now) $result['error'] = 'زمان استفاده از این کد هنوز نرسیده';
            elseif ($dc['ends_at'] && $dc['ends_at'] < $now) $result['error'] = 'کد تخفیف منقضی شده';
            elseif ($dc['max_uses'] > 0 && $dc['current_uses'] >= $dc['max_uses']) $result['error'] = 'ظرفیت استفاده از این کد تمام شده';
            elseif ($dc['min_order'] > 0 && $subtotal < $dc['min_order']) $result['error'] = 'حداقل مبلغ سفارش برای این کد ' . toman($dc['min_order']) . ' تومان است';
        }
        if (!$result['error'] && $dc) {
            if ($dc['type'] === 'percent') {
                $amount = (int)round($subtotal * $dc['value'] / 100);
            } else {
                $amount = $dc['value'];
            }
            $result = ['ok'=>true, 'amount'=>$amount, 'type'=>$dc['type'], 'value'=>$dc['value'], 'message'=>'کد تخفیف اعمال شد ✓'];
        }
    }
    echo json_encode($result); exit;
}

// =====================================================
//  ثبت سفارش
// =====================================================
$order_success = null;
$order_error = null;
if ($action === 'place_order' && $_SERVER['REQUEST_METHOD'] === 'POST') {
    $name    = trim($_POST['customer_name'] ?? '');
    $phone   = trim($_POST['phone'] ?? '');
    $address = trim($_POST['address'] ?? '');
    $note    = trim($_POST['note'] ?? '');
    $payment_method = $_POST['payment_method'] ?? 'cod';
    $discount_code = trim($_POST['discount_code'] ?? '');
    $allowed_city = setting('allowed_city', 'تربت حیدریه');

    // تعیین روش‌های پرداخت مجاز
    $cod_enabled = setting('show_cod_payment', '1') === '1';
    $valid_methods = [];
    if ($cod_enabled) $valid_methods[] = 'cod';
    // همیشه کالابرگ به عنوان یک روش پرداخت در دسترس است (ساده)
    $valid_methods[] = 'voucher';
    if (!in_array($payment_method, $valid_methods)) $payment_method = $valid_methods[0] ?? 'cod';

    if (empty($_SESSION['cart'])) {
        $order_error = 'سبد خرید شما خالی است.';
    } elseif ($name === '' || $phone === '' || $address === '') {
        $order_error = 'لطفاً تمام فیلدهای ضروری را پر کنید.';
    } elseif (!preg_match('/^09\d{9}$/', $phone)) {
        $order_error = 'شماره موبایل باید ۱۱ رقم و با ۰۹ شروع شود.';
    } else {
        $pdo = db();
        try {
            $pdo->beginTransaction();

            $items = [];
            $total = 0;
            $cost_total = 0;
            $in = implode(',', array_map('intval', array_keys($_SESSION['cart'])));
            if (!$in) throw new Exception('سبد خرید نامعتبر است.');

            $rows = $pdo->query("SELECT * FROM products WHERE id IN ($in)")->fetchAll();
            $map = [];
            foreach ($rows as $r) $map[$r['id']] = $r;

            $main_wh = main_warehouse_id();
            $stock_lock = [];

            foreach ($_SESSION['cart'] as $pid => $qty) {
                $pid = (int)$pid; $qty = (int)$qty;
                if (!isset($map[$pid]) || !$map[$pid]['is_active']) continue;
                if ($qty <= 0) continue;

                $available = get_stock($pid, $main_wh);
                if ($available <= 0) {
                    throw new Exception("محصول «{$map[$pid]['name']}» ناموجود است.");
                }
                if ($qty > $available) {
                    throw new Exception("موجودی «{$map[$pid]['name']}» فقط {$available} عدد است.");
                }

                $flash = get_flash_sale($pid);
                $price = eff_price($map[$pid], $flash);
                $line = $price * $qty;
                $cost = (int)$map[$pid]['cost_price'] * $qty;
                $total += $line;
                $cost_total += $cost;
                $items[] = [
                    'id'=>$pid, 'name'=>$map[$pid]['name'], 'price'=>$price,
                    'cost_price'=>(int)$map[$pid]['cost_price'],
                    'qty'=>$qty, 'line'=>$line,
                    'flash_sale_id'=>$flash?$flash['id']:null,
                ];
                $stock_lock[$pid] = ['qty'=>$qty, 'name'=>$map[$pid]['name']];
            }

            if (empty($items)) throw new Exception('سبد خرید نامعتبر است.');

            $delivery = (int)setting('delivery_fee', 0);
            $min_order = (int)setting('min_order', 0);
            if ($min_order > 0 && $total < $min_order) {
                throw new Exception('حداقل مبلغ سفارش ' . toman($min_order) . ' تومان است.');
            }

            $subtotal = $total;
            $discount_amount = 0;

            // اعمال کد تخفیف
            $valid_dc = null;
            if ($discount_code !== '') {
                $st = $pdo->prepare("SELECT * FROM discount_codes WHERE code=?");
                $st->execute([$discount_code]);
                $dc = $st->fetch();
                if (!$dc || !$dc['is_active']) throw new Exception('کد تخفیف نامعتبر است');
                $now = date('Y-m-d H:i:s');
                if ($dc['starts_at'] && $dc['starts_at'] > $now) throw new Exception('زمان استفاده از کد تخفیف نرسیده');
                if ($dc['ends_at'] && $dc['ends_at'] < $now) throw new Exception('کد تخفیف منقضی شده');
                if ($dc['max_uses'] > 0 && $dc['current_uses'] >= $dc['max_uses']) throw new Exception('ظرفیت کد تخفیف تمام شده');
                if ($dc['min_order'] > 0 && $total < $dc['min_order']) throw new Exception('حداقل مبلغ برای این کد ' . toman($dc['min_order']) . ' تومان');
                if ($dc['max_per_customer'] > 0) {
                    $c = $pdo->prepare("SELECT COUNT(*) c FROM discount_code_usage WHERE code_id=? AND customer_phone=?");
                    $c->execute([$dc['id'], $phone]);
                    if ($c->fetch()['c'] >= $dc['max_per_customer']) throw new Exception('شما قبلاً از این کد استفاده کرده‌اید');
                }
                if ($dc['first_order_only']) {
                    $c = $pdo->prepare("SELECT COUNT(*) c FROM orders WHERE phone=? AND status!='cancelled'");
                    $c->execute([$phone]);
                    if ($c->fetch()['c'] > 0) throw new Exception('این کد فقط برای اولین سفارش است');
                }
                if ($dc['type'] === 'percent') {
                    $discount_amount = (int)round($total * $dc['value'] / 100);
                } else {
                    $discount_amount = $dc['value'];
                }
                if ($discount_amount > $total) $discount_amount = $total;
                $valid_dc = $dc;
            }

            $after_discount = $total - $discount_amount;

            $grand = $after_discount + $delivery;
            if ($grand < 0) $grand = 0;
            $profit = ($total - $discount_amount) - $cost_total; // سود پس از تخفیف
            $code = 'TH' . date('ymd') . rand(100, 999);

            $stmt = $pdo->prepare("INSERT INTO orders (order_code,customer_name,phone,address,city,note,total,subtotal,discount_amount,cost_total,profit,items,status,payment_method,voucher_code,discount_code,is_paid,is_archived,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
            $stmt->execute([$code,$name,$phone,$address,$allowed_city,$note,$grand,$subtotal,$discount_amount,$cost_total,$profit,json_encode($items,JSON_UNESCAPED_UNICODE),'pending',$payment_method,null,$valid_dc?$valid_dc['code']:null,$payment_method==='voucher'?1:0,0,date('Y-m-d H:i:s')]);
            $order_id = $pdo->lastInsertId();

            // کسر موجودی
            $upd = $pdo->prepare("UPDATE stock SET quantity = quantity - ? WHERE product_id=? AND warehouse_id=?");
            $mov = $pdo->prepare("INSERT INTO stock_movements (product_id,warehouse_id,from_warehouse_id,to_warehouse_id,type,quantity,unit_price,ref_id,note,created_at) VALUES (?,?,?,?,?,?,?,?,?,?)");
            $now = date('Y-m-d H:i:s');
            foreach ($stock_lock as $pid => $info) {
                $upd->execute([$info['qty'], $pid, $main_wh]);
                $mov->execute([$pid, $main_wh, $main_wh, null, 'sale', $info['qty'], 0, $order_id, "فروش سفارش $code", $now]);
            }

            // ثبت استفاده از کد تخفیف
            if ($valid_dc) {
                $pdo->prepare("INSERT INTO discount_code_usage (code_id,order_id,customer_phone,discount_amount,used_at) VALUES (?,?,?,?,?)")
                    ->execute([$valid_dc['id'], $order_id, $phone, $discount_amount, $now]);
                $pdo->prepare("UPDATE discount_codes SET current_uses=current_uses+1 WHERE id=?")->execute([$valid_dc['id']]);
            }

            $pdo->commit();
            $_SESSION['cart'] = [];
            $order_success = [
                'code'=>$code, 'total'=>$grand, 'payment_method'=>$payment_method,
                'discount_amount'=>$discount_amount, 'voucher_used'=>0,
            ];
        } catch (Exception $ex) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $order_error = $ex->getMessage();
        }
    }
}

// =====================================================
//  بارگذاری داده‌ها برای نمایش
// =====================================================
$pdo = db();
$catId = isset($_GET['cat']) ? (int)$_GET['cat'] : 0;
$search = trim($_GET['q'] ?? '');
$tab_id = isset($_GET['tab']) ? (int)$_GET['tab'] : 0;

$categories = $pdo->query("SELECT * FROM categories ORDER BY sort_order, id")->fetchAll();
$custom_tabs = $pdo->query("SELECT * FROM custom_tabs WHERE is_active=1 ORDER BY sort_order, id")->fetchAll();

// محصولات برای تب‌های سفارشی
function get_products_for_tab($tab) {
    $pdo = db();
    $main_wh = main_warehouse_id();
    $where = "p.is_active=1";
    $params = [];
    switch ($tab['tab_type']) {
        case 'low_stock':
            $where .= " AND s.quantity <= p.min_stock AND s.quantity > 0";
            break;
        case 'out_of_stock':
            $where .= " AND s.quantity = 0";
            break;
        case 'discounted':
            $where .= " AND ((p.discount_percent > 0 AND p.discount_percent < 100) OR (p.discount_price > 0 AND p.discount_price < p.price))";
            break;
        case 'featured':
            $where .= " AND p.is_featured = 1";
            break;
        case 'flash_sale':
            $now = date('Y-m-d H:i:s');
            $where .= " AND p.id IN (SELECT product_id FROM flash_sales WHERE is_active=1 AND starts_at<=? AND ends_at>=?)";
            $params[] = $now; $params[] = $now;
            break;
        case 'newest':
        default:
            // newest
            break;
    }
    $sql = "SELECT p.* FROM products p LEFT JOIN stock s ON s.product_id=p.id AND s.warehouse_id=? WHERE $where ORDER BY p.id DESC LIMIT 12";
    array_unshift($params, $main_wh);
    $st = $pdo->prepare($sql);
    $st->execute($params);
    return $st->fetchAll();
}

$where = "p.is_active=1";
$params = [];
if ($catId) { $where .= " AND p.category_id=?"; $params[] = $catId; }
if ($search !== '') { $where .= " AND (p.name LIKE ? OR p.description LIKE ?)"; $params[] = "%$search%"; $params[] = "%$search%"; }
$pstmt = $pdo->prepare("SELECT p.* FROM products p WHERE $where ORDER BY p.created_at DESC, p.id DESC");
$pstmt->execute($params);
$products = $pstmt->fetchAll();

$featured = $pdo->query("SELECT * FROM products WHERE is_active=1 AND is_featured=1 ORDER BY id DESC LIMIT 8")->fetchAll();
$now_date = date('Y-m-d H:i:s');
$discounted = $pdo->query("SELECT * FROM products WHERE is_active=1 AND ((discount_price>0 AND discount_price<price) OR (discount_percent>0 AND discount_percent<100)) ORDER BY id DESC LIMIT 8")->fetchAll();
$flash_products = $pdo->prepare("SELECT p.* FROM products p JOIN flash_sales f ON f.product_id=p.id WHERE p.is_active=1 AND f.is_active=1 AND f.starts_at<=? AND f.ends_at>=? ORDER BY f.id DESC LIMIT 8");
$flash_products->execute([$now_date, $now_date]);
$flash_products = $flash_products->fetchAll();

$cart_items = [];
$cart_total = 0;
if (!empty($_SESSION['cart'])) {
    $in = implode(',', array_map('intval', array_keys($_SESSION['cart'])));
    $rows = $pdo->query("SELECT * FROM products WHERE id IN ($in)")->fetchAll();
    $map = [];
    foreach ($rows as $r) $map[$r['id']] = $r;
    foreach ($_SESSION['cart'] as $pid => $qty) {
        if (isset($map[$pid])) {
            $flash = get_flash_sale($pid);
            $price = eff_price($map[$pid], $flash);
            $cart_items[] = ['p'=>$map[$pid], 'qty'=>$qty, 'price'=>$price, 'line'=>$price*$qty, 'flash'=>$flash];
            $cart_total += $price * $qty;
        }
    }
}
$cart_count = array_sum($_SESSION['cart']);
$delivery_fee = (int)setting('delivery_fee', 0);
$primary = setting('primary_color', '#e63946');
$current_cat_name = '';
foreach ($categories as $c) if ($c['id'] == $catId) $current_cat_name = $c['name'];

// تنظیمات سفارشی‌سازی
$site_logo = setting('site_logo', '');
$site_bg_image = setting('site_bg_image', '');
$site_bg_text_color = setting('site_bg_text_color', '#ffffff');
$site_bg_overlay = (float)setting('site_bg_overlay', '0.4');
$hero_title = setting('hero_title', '') ?: setting('shop_name', 'فروشگاه');
$hero_subtitle = setting('hero_subtitle', '') ?: setting('shop_slogan', 'خرید آنلاین، تحویل درب منزل');
$hero_badge = setting('hero_badge_text', 'پرداخت درب منزل (نقدی هنگام تحویل)');
$btn_cart = setting('btn_cart_label', 'سبد خرید');
$btn_add = setting('btn_add_to_cart_label', 'افزودن به سبد');
$btn_checkout = setting('btn_checkout_label', 'ادامه و ثبت سفارش');
$btn_continue = setting('btn_continue_label', 'بازگشت به فروشگاه');
$btn_empty = setting('btn_empty_cart_label', 'سبد خرید شما خالی است');
$btn_search = setting('btn_search_label', 'جستجوی محصول...');
$show_cod = setting('show_cod_payment', '1') === '1';
$show_voucher = true; // کالابرگ همیشه به عنوان روش پرداخت نمایش داده می‌شود (ساده، بدون کد)
$voucher_label = 'کالابرگ';
$discount_code_label = setting('discount_code_label', 'کد تخفیف دارید؟');
$voucher_field_label = 'کالابرگ';

function product_card($p, $primary, $btn_add_label = 'افزودن به سبد') {
    $flash = get_flash_sale($p['id']);
    $price = eff_price($p, $flash);
    $hasDiscount = $flash || ($p['discount_percent'] > 0 && $p['discount_percent'] < 100) || ($p['discount_price'] > 0 && $p['discount_price'] < $p['price']);
    if ($flash) {
        $off = $flash['discount_percent'] ?: round(100 - ($flash['discount_price'] / $p['price'] * 100));
    } elseif ($p['discount_percent'] > 0 && $p['discount_percent'] < 100) {
        $off = (int)$p['discount_percent'];
    } else {
        $off = $hasDiscount ? round(100 - ($p['discount_price'] / $p['price'] * 100)) : 0;
    }
    $img = $p['image'] ? e($p['image']) : '';
    $stock = get_stock($p['id']);
    $min_stock = (int)($p['min_stock'] ?? 5);
    ob_start(); ?>
    <article class="product-card">
        <div class="product-img-wrap">
            <?php if ($hasDiscount): ?><span class="badge-off"><?= (int)$off ?>٪ تخفیف</span><?php endif; ?>
            <?php if ($flash): ?><span class="badge-flash"><i class="fa-solid fa-bolt"></i> آخر لحظه</span><?php endif; ?>
            <?php if ($p['is_featured']): ?><span class="badge-feat"><i class="fa-solid fa-star"></i> ویژه</span><?php endif; ?>
            <?php if ($img): ?>
                <img src="<?= $img ?>" alt="<?= e($p['name']) ?>" loading="lazy">
            <?php else: ?>
                <div class="no-img"><i class="fa-solid fa-box-open"></i></div>
            <?php endif; ?>
            <?php if ($stock <= 0): ?><span class="badge-out">ناموجود</span>
            <?php elseif ($stock <= $min_stock): ?><span class="badge-low">تنها <?= $stock ?> عدد</span>
            <?php endif; ?>
            <?php if ($flash): ?>
            <div class="flash-timer" data-ends="<?= e($flash['ends_at']) ?>">
                <i class="fa-solid fa-stopwatch"></i>
                <span class="countdown">در حال شمارش...</span>
            </div>
            <?php endif; ?>
        </div>
        <div class="product-body">
            <h3 class="product-name"><?= e($p['name']) ?></h3>
            <p class="product-desc"><?= e(mb_substr($p['description'] ?? '', 0, 60)) ?></p>
            <div class="product-price-row">
                <?php if ($hasDiscount): ?>
                    <span class="old-price"><?= toman($p['price']) ?></span>
                <?php endif; ?>
                <span class="price"><?= toman($price) ?> <small>تومان</small></span>
            </div>
            <?php if ($stock > 0): ?>
                <button class="btn-add" data-id="<?= $p['id'] ?>" data-stock="<?= $stock ?>"><i class="fa-solid fa-cart-plus"></i> <?= e($btn_add_label) ?></button>
            <?php else: ?>
                <button class="btn-add disabled" disabled>ناموجود</button>
            <?php endif; ?>
        </div>
    </article>
    <?php return ob_get_clean();
}
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= e(setting('shop_name')) ?> | <?= e(setting('shop_slogan')) ?></title>
<meta name="description" content="<?= e(setting('shop_slogan')) ?>">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css">
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<style>
:root{
  --primary: <?= e($primary) ?>;
  --primary-dark: <?= e($primary) ?>;
  --bg:#f5f6f8; --card:#fff; --text:#222; --muted:#777; --border:#eee;
  --green:#2a9d8f; --shadow:0 4px 18px rgba(0,0,0,.07);
  --hero-text: <?= e($site_bg_text_color) ?>;
  --hero-overlay: <?= $site_bg_overlay ?>;
}
*{margin:0;padding:0;box-sizing:border-box;font-family:'Vazirmatn',sans-serif;}
body{background:var(--bg);color:var(--text);line-height:1.7;}
a{text-decoration:none;color:inherit;}
img{max-width:100%;display:block;}
.container{max-width:1240px;margin:0 auto;padding:0 16px;}
button{cursor:pointer;font-family:inherit;border:none;}

header.site-header{background:#fff;box-shadow:0 2px 10px rgba(0,0,0,.05);position:sticky;top:0;z-index:100;}
.topbar{background:var(--primary);color:#fff;font-size:13px;padding:6px 0;}
.topbar .container{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;}
.topbar a{color:#fff;}
.header-main{display:flex;align-items:center;gap:20px;padding:14px 0;flex-wrap:wrap;}
.logo{display:flex;align-items:center;gap:10px;font-size:22px;font-weight:800;color:var(--primary);}
.logo img{max-height:46px;width:auto;}
.logo i{font-size:26px;}
.search-box{flex:1;min-width:200px;display:flex;border:2px solid var(--border);border-radius:12px;overflow:hidden;}
.search-box input{flex:1;border:none;padding:11px 14px;font-size:15px;outline:none;}
.search-box button{background:var(--primary);color:#fff;padding:0 18px;font-size:16px;}
.header-actions{display:flex;align-items:center;gap:14px;}
.track-link{background:#fff;border:2px solid var(--primary);color:var(--primary);padding:8px 14px;border-radius:12px;font-weight:600;font-size:14px;text-decoration:none;display:inline-flex;align-items:center;gap:6px;transition:all .2s ease;}
.track-link:hover{background:var(--primary);color:#fff;}
.cart-btn{position:relative;background:var(--primary);color:#fff;padding:10px 16px;border-radius:12px;font-weight:600;font-size:15px;display:flex;align-items:center;gap:8px;border:none;cursor:pointer;}
.cart-btn .count{background:#fff;color:var(--primary);border-radius:50%;width:22px;height:22px;display:inline-flex;align-items:center;justify-content:center;font-size:12px;font-weight:700;}

nav.cat-nav{background:#fff;border-top:1px solid var(--border);}
nav.cat-nav .container{display:flex;gap:6px;overflow-x:auto;padding:8px 16px;}
nav.cat-nav a{padding:8px 16px;border-radius:10px;white-space:nowrap;font-size:14px;font-weight:500;color:#555;transition:.2s;}
nav.cat-nav a:hover,nav.cat-nav a.active{background:var(--primary);color:#fff;}

/* Hero با پشتیبانی از بک‌گراند */
.hero{
  <?php if($site_bg_image): ?>
  background-image:
    linear-gradient(rgba(0,0,0,var(--hero-overlay)), rgba(0,0,0,var(--hero-overlay))),
    url('<?= e($site_bg_image) ?>');
  background-size:cover;background-position:center;
  <?php else: ?>
  background:linear-gradient(135deg,var(--primary),#1d3557);
  <?php endif; ?>
  color:var(--hero-text);
  border-radius:18px;margin:22px 0;padding:46px 34px;position:relative;overflow:hidden;
}
.hero h1{font-size:32px;font-weight:800;margin-bottom:12px;}
.hero p{font-size:17px;opacity:.95;max-width:560px;}
.hero .hero-badge{display:inline-flex;align-items:center;gap:8px;background:rgba(255,255,255,.2);padding:8px 16px;border-radius:30px;margin-top:18px;font-size:14px;}
.hero i.bg-icon{position:absolute;left:-20px;bottom:-30px;font-size:200px;opacity:.08;}

.section{margin:36px 0;}
.section-head{display:flex;align-items:center;justify-content:space-between;margin-bottom:18px;border-right:5px solid var(--primary);padding-right:12px;}
.section-head h2{font-size:22px;font-weight:700;}
.products-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:18px;}

/* کارت محصول */
.product-card{background:var(--card);border-radius:16px;overflow:hidden;box-shadow:var(--shadow);transition:.25s;display:flex;flex-direction:column;}
.product-card:hover{transform:translateY(-5px);box-shadow:0 10px 28px rgba(0,0,0,.12);}
.product-img-wrap{position:relative;aspect-ratio:1/1;background:#f0f1f4;display:flex;align-items:center;justify-content:center;}
.product-img-wrap img{width:100%;height:100%;object-fit:cover;}
.no-img{font-size:54px;color:#ccc;}
.badge-off{position:absolute;top:10px;right:10px;background:#e63946;color:#fff;padding:4px 10px;border-radius:20px;font-size:12px;font-weight:700;z-index:2;}
.badge-feat{position:absolute;top:10px;left:10px;background:#f4a261;color:#fff;padding:4px 10px;border-radius:20px;font-size:11px;font-weight:600;z-index:2;}
.badge-flash{position:absolute;top:40px;left:10px;background:linear-gradient(135deg,#ff416c,#ff4b2b);color:#fff;padding:4px 10px;border-radius:20px;font-size:11px;font-weight:700;z-index:2;animation:pulse 1.5s infinite;}
@keyframes pulse{0%,100%{opacity:1}50%{opacity:.7}}
.badge-out{position:absolute;inset:0;background:rgba(255,255,255,.75);display:flex;align-items:center;justify-content:center;font-size:18px;font-weight:700;color:#999;}
.badge-low{position:absolute;bottom:10px;left:10px;background:#f4a261;color:#fff;padding:4px 10px;border-radius:20px;font-size:11px;font-weight:600;z-index:2;}
.flash-timer{position:absolute;bottom:10px;right:10px;background:rgba(0,0,0,.75);color:#fff;padding:5px 10px;border-radius:8px;font-size:12px;font-weight:600;z-index:2;display:flex;align-items:center;gap:5px;direction:ltr}
.flash-timer.expired{background:rgba(100,100,100,.75);}
.product-body{padding:14px;display:flex;flex-direction:column;gap:8px;flex:1;}
.product-name{font-size:15px;font-weight:600;min-height:44px;}
.product-desc{font-size:12px;color:var(--muted);min-height:34px;}
.product-price-row{display:flex;align-items:center;gap:10px;flex-wrap:wrap;margin-top:auto;}
.old-price{text-decoration:line-through;color:#bbb;font-size:13px;}
.price{font-size:18px;font-weight:800;color:var(--primary);}
.price.old{color:#999;text-decoration:line-through;}
.price small{font-size:11px;font-weight:400;color:var(--muted);}
.btn-add{background:var(--primary);color:#fff;padding:10px;border-radius:10px;font-weight:600;font-size:14px;display:flex;align-items:center;justify-content:center;gap:8px;transition:.2s;}
.btn-add:hover{filter:brightness(1.1);}
.btn-add.disabled{background:#ccc;cursor:not-allowed;}

.overlay{position:fixed;inset:0;background:rgba(0,0,0,.5);z-index:200;display:none;}
.overlay.show{display:block;}
.cart-drawer{position:fixed;top:0;left:0;height:100%;width:400px;max-width:92vw;background:#fff;z-index:201;transform:translateX(-100%);transition:.3s;display:flex;flex-direction:column;}
.cart-drawer.show{transform:translateX(0);}
.cart-head{padding:18px;background:var(--primary);color:#fff;display:flex;justify-content:space-between;align-items:center;}
.cart-head h3{font-size:18px;}
.cart-head .close{background:none;color:#fff;font-size:22px;}
.cart-body{flex:1;overflow-y:auto;padding:16px;}
.cart-item{display:flex;gap:12px;padding:12px 0;border-bottom:1px solid var(--border);}
.cart-item .ci-img{width:60px;height:60px;border-radius:10px;background:#f0f1f4;flex-shrink:0;display:flex;align-items:center;justify-content:center;overflow:hidden;color:#ccc;}
.cart-item .ci-img img{width:100%;height:100%;object-fit:cover;}
.ci-info{flex:1;}
.ci-info .ci-name{font-size:14px;font-weight:600;}
.ci-info .ci-price{color:var(--primary);font-weight:700;font-size:14px;}
.ci-info .ci-flash{font-size:11px;color:#e63946;font-weight:600;margin-top:2px;}
.qty-ctrl{display:flex;align-items:center;gap:6px;margin-top:6px;}
.qty-ctrl button{width:28px;height:28px;border-radius:8px;background:#f0f1f4;font-weight:700;font-size:16px;}
.qty-ctrl span{min-width:28px;text-align:center;font-weight:600;}
.ci-remove{color:#e63946;background:none;font-size:13px;}
.ci-stock{font-size:11px;color:#999;margin-top:2px;}
.cart-empty{text-align:center;color:var(--muted);padding:50px 0;}
.cart-empty i{font-size:60px;color:#ddd;margin-bottom:14px;}
.cart-empty p{font-size:15px;}
.cart-footer{padding:18px;border-top:1px solid var(--border);background:#fafafa;}
.cart-total-row{display:flex;justify-content:space-between;font-size:15px;margin-bottom:6px;}
.cart-total-row.grand{font-size:18px;font-weight:800;color:var(--primary);margin-top:8px;border-top:1px dashed #ddd;padding-top:8px;}
.btn-checkout{display:block;width:100%;background:var(--green);color:#fff;text-align:center;padding:14px;border-radius:12px;font-weight:700;font-size:16px;margin-top:14px;}

.modal{position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:300;display:none;align-items:center;justify-content:center;padding:16px;overflow-y:auto;}
.modal.show{display:flex;}
.modal-box{background:#fff;border-radius:18px;width:100%;max-width:540px;max-height:92vh;overflow-y:auto;}
.modal-head{padding:18px 22px;border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;}
.modal-head h3{font-size:19px;}
.modal-head .close{background:none;font-size:24px;color:#999;}
.modal-body{padding:22px;}
.form-group{margin-bottom:16px;}
.form-group label{display:block;font-size:14px;font-weight:600;margin-bottom:6px;}
.form-group label .req{color:#e63946;}
.form-control{width:100%;padding:12px 14px;border:2px solid var(--border);border-radius:11px;font-size:15px;outline:none;transition:.2s;font-family:inherit;}
.form-control:focus{border-color:var(--primary);}
textarea.form-control{resize:vertical;min-height:70px;}
.city-lock{display:flex;align-items:center;gap:8px;background:#fff3cd;color:#856404;padding:11px 14px;border-radius:11px;font-size:13px;}

.cod-info{display:flex;align-items:center;gap:10px;background:#e7f5ee;color:#1b6e57;padding:13px 16px;border-radius:12px;font-size:14px;margin-bottom:16px;}
.cod-info i{font-size:22px;}
.voucher-info{display:flex;align-items:center;gap:10px;background:#fff3e0;color:#d98324;padding:13px 16px;border-radius:12px;font-size:14px;margin-bottom:16px;}

.alert{padding:12px 16px;border-radius:11px;font-size:14px;margin-bottom:16px;}
.alert-error{background:#fde8e8;color:#c0392b;}
.alert-success{background:#e7f5ee;color:#1b6e57;}
.summary-line{display:flex;justify-content:space-between;font-size:14px;margin-bottom:6px;color:#555;}
.summary-line.discount{color:var(--green);font-weight:600;}
.summary-line.voucher{color:#d98324;font-weight:600;}
.summary-line.total{font-size:17px;font-weight:800;color:var(--primary);border-top:1px dashed #ddd;padding-top:10px;margin-top:10px;}

.btn-submit{width:100%;background:var(--green);color:#fff;padding:15px;border-radius:12px;font-weight:700;font-size:16px;margin-top:8px;}

/* روش‌های پرداخت */
.payment-methods{display:grid;grid-template-columns:repeat(auto-fit,minmax(160px,1fr));gap:12px;margin-bottom:16px;}
.payment-option{position:relative;}
.payment-option input{position:absolute;opacity:0;}
.payment-option label{display:flex;flex-direction:column;align-items:center;gap:8px;padding:16px;border:2px solid var(--border);border-radius:12px;cursor:pointer;transition:.2s;background:#fff;}
.payment-option input:checked + label{border-color:var(--primary);background:#fff5f5;}
.payment-option label i{font-size:28px;color:var(--primary);}
.payment-option label .pm-title{font-weight:700;font-size:14px;}
.payment-option label .pm-desc{font-size:11.5px;color:var(--muted);text-align:center;}

/* کد تخفیف / کالابرگ */
.code-input-row{display:flex;gap:8px;margin-bottom:8px;}
.code-input-row input{flex:1;}
.code-input-row button{padding:0 18px;background:var(--primary);color:#fff;border-radius:11px;font-weight:600;white-space:nowrap;}
.code-msg{font-size:12.5px;margin-top:6px;display:none;}
.code-msg.show{display:block;}
.code-msg.ok{color:var(--green);}
.code-msg.err{color:#c0392b;}

/* تب‌های سفارشی */
.custom-tabs-nav{display:flex;gap:8px;overflow-x:auto;padding:8px 0;margin-bottom:18px;border-bottom:1px solid var(--border);}
.custom-tabs-nav a{padding:8px 16px;border-radius:10px;white-space:nowrap;font-size:14px;font-weight:600;color:#555;background:#fff;border:1px solid var(--border);transition:.2s;}
.custom-tabs-nav a:hover, .custom-tabs-nav a.active{background:var(--primary);color:#fff;border-color:var(--primary);}

.success-box{text-align:center;padding:30px 10px;}
.success-box .ic{width:90px;height:90px;border-radius:50%;background:#e7f5ee;color:var(--green);font-size:46px;display:flex;align-items:center;justify-content:center;margin:0 auto 18px;}
.success-box h3{font-size:22px;margin-bottom:8px;}
.success-box .code{font-size:20px;font-weight:800;color:var(--primary);background:#f5f6f8;padding:10px 20px;border-radius:12px;display:inline-block;margin:12px 0;}

footer.site-footer{background:#1d2630;color:#cfd6dd;margin-top:50px;padding:40px 0 20px;}
footer .footer-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:30px;}
footer h4{color:#fff;font-size:17px;margin-bottom:14px;}
footer p,footer li{font-size:14px;margin-bottom:8px;color:#aab3bd;}
footer ul{list-style:none;}
footer .social{display:flex;gap:12px;margin-top:10px;}
footer .social a{width:40px;height:40px;border-radius:10px;background:rgba(255,255,255,.1);display:flex;align-items:center;justify-content:center;font-size:18px;color:#fff;transition:.2s;}
footer .social a:hover{background:var(--primary);}
.footer-bottom{text-align:center;margin-top:30px;padding-top:18px;border-top:1px solid rgba(255,255,255,.1);font-size:13px;color:#8b95a0;}
.empty-result{text-align:center;padding:60px 0;color:var(--muted);}
.empty-result i{font-size:70px;color:#ddd;margin-bottom:16px;}

.toast{position:fixed;bottom:24px;right:24px;background:#2a9d8f;color:#fff;padding:14px 22px;border-radius:12px;font-weight:600;box-shadow:0 6px 20px rgba(0,0,0,.2);z-index:400;transform:translateY(120px);opacity:0;transition:.35s;max-width:90vw;}
.toast.show{transform:translateY(0);opacity:1;}
.toast.error{background:#e63946;}

@media(max-width:768px){
  .hero{padding:32px 22px;}
  .hero h1{font-size:24px;}
  .header-main{gap:12px;}
  .logo{font-size:18px;}
  .search-box{order:3;width:100%;flex:none;}
  .cart-btn span.txt{display:none;}
  .track-link span{display:none;}
  .track-link{padding:8px 10px;}
  .products-grid{grid-template-columns:repeat(auto-fill,minmax(150px,1fr));gap:12px;}
  .product-name{font-size:14px;min-height:40px;}
}
</style>
</head>
<body>

<header class="site-header">
  <div class="topbar">
    <div class="container">
      <span><i class="fa-solid fa-truck-fast"></i> ارسال درب منزل فقط در <?= e(setting('allowed_city','تربت حیدریه')) ?></span>
      <span><i class="fa-solid fa-phone"></i> <?= e(setting('shop_phone')) ?></span>
    </div>
  </div>
  <div class="container header-main">
    <a href="index.php" class="logo">
      <?php if($site_logo): ?><img src="<?= e($site_logo) ?>" alt="logo"><?php else: ?><i class="fa-solid fa-store"></i><?php endif; ?>
      <?php if(!$site_logo): ?><?= e(setting('shop_name')) ?><?php endif; ?>
    </a>
    <form class="search-box" method="get" action="index.php">
      <input type="text" name="q" placeholder="<?= e($btn_search) ?>" value="<?= e($search) ?>">
      <button type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
    </form>
    <div class="header-actions">
      <a href="track.php" class="track-link"><i class="fa-solid fa-magnifying-glass-location"></i> <span>پیگیری سفارش</span></a>
      <button class="cart-btn" id="openCart">
        <i class="fa-solid fa-cart-shopping"></i>
        <span class="txt"><?= e($btn_cart) ?></span>
        <span class="count" id="cartCount"><?= $cart_count ?></span>
      </button>
    </div>
  </div>
  <nav class="cat-nav">
    <div class="container">
      <a href="index.php" class="<?= (!$catId && $search==='' && !$tab_id) ? 'active':'' ?>"><i class="fa-solid fa-house"></i> همه</a>
      <?php foreach ($categories as $c): ?>
        <a href="index.php?cat=<?= $c['id'] ?>" class="<?= $catId==$c['id']?'active':'' ?>"><?= e($c['name']) ?></a>
      <?php endforeach; ?>
    </div>
  </nav>
</header>

<div class="container">

<?php if ($search === '' && !$catId && !$tab_id): ?>
  <section class="hero">
    <i class="fa-solid fa-bags-shopping bg-icon"></i>
    <h1><?= e($hero_title) ?></h1>
    <p><?= e($hero_subtitle) ?></p>
    <span class="hero-badge"><i class="fa-solid fa-hand-holding-dollar"></i> <?= e($hero_badge) ?></span>
  </section>

  <?php if ($flash_products): ?>
  <section class="section">
    <div class="section-head"><h2><i class="fa-solid fa-bolt" style="color:#e63946"></i> تخفیف‌های آخر لحظه</h2></div>
    <div class="products-grid">
      <?php foreach ($flash_products as $p) echo product_card($p, $primary, $btn_add); ?>
    </div>
  </section>
  <?php endif; ?>

  <?php if ($discounted): ?>
  <section class="section">
    <div class="section-head"><h2><i class="fa-solid fa-fire" style="color:#e63946"></i> پیشنهادهای شگفت‌انگیز</h2></div>
    <div class="products-grid">
      <?php foreach ($discounted as $p) echo product_card($p, $primary, $btn_add); ?>
    </div>
  </section>
  <?php endif; ?>

  <?php if ($featured): ?>
  <section class="section">
    <div class="section-head"><h2><i class="fa-solid fa-star" style="color:#f4a261"></i> محصولات ویژه</h2></div>
    <div class="products-grid">
      <?php foreach ($featured as $p) echo product_card($p, $primary, $btn_add); ?>
    </div>
  </section>
  <?php endif; ?>

  <?php if ($custom_tabs): ?>
  <section class="section">
    <div class="custom-tabs-nav">
      <?php foreach($custom_tabs as $i => $t): ?>
        <a href="index.php?tab=<?= $t['id'] ?>" class="<?= $tab_id==$t['id']?'active':'' ?>">
          <?= $t['icon'] ? '<i class="'.$t['icon'].'"></i> ' : '' ?><?= e($t['title']) ?>
        </a>
      <?php endforeach; ?>
    </div>
    <?php if ($tab_id):
      $current_tab = null;
      foreach($custom_tabs as $t) if ($t['id']==$tab_id) $current_tab = $t;
      if ($current_tab):
        $tab_products = get_products_for_tab($current_tab);
    ?>
      <div class="section-head"><h2><?= e($current_tab['title']) ?> (<?= count($tab_products) ?>)</h2></div>
      <?php if($tab_products): ?>
      <div class="products-grid">
        <?php foreach ($tab_products as $p) echo product_card($p, $primary, $btn_add); ?>
      </div>
      <?php else: ?>
      <div class="empty-result"><i class="fa-solid fa-box-open"></i><p>محصولی یافت نشد.</p></div>
      <?php endif; ?>
    <?php endif; endif; ?>
  </section>
  <?php endif; ?>
<?php endif; ?>

<?php if ($search !== '' || $catId): ?>
<section class="section">
  <div class="section-head">
    <h2>
      <?php if ($search !== ''): ?>
        <i class="fa-solid fa-magnifying-glass"></i> نتایج جستجو: «<?= e($search) ?>»
      <?php elseif ($catId): ?>
        <i class="fa-solid fa-tags"></i> <?= e($current_cat_name) ?>
      <?php endif; ?>
    </h2>
  </div>
  <?php if ($products): ?>
    <div class="products-grid">
      <?php foreach ($products as $p) echo product_card($p, $primary, $btn_add); ?>
    </div>
  <?php else: ?>
    <div class="empty-result">
      <i class="fa-solid fa-box-open"></i>
      <p>محصولی یافت نشد.</p>
    </div>
  <?php endif; ?>
</section>
<?php endif; ?>

</div>

<footer class="site-footer">
  <div class="container">
    <div class="footer-grid">
      <div>
        <h4><i class="fa-solid fa-store"></i> <?= e(setting('shop_name')) ?></h4>
        <p><?= e(setting('shop_about')) ?></p>
      </div>
      <div>
        <h4>اطلاعات تماس</h4>
        <ul>
          <li><i class="fa-solid fa-location-dot"></i> <?= e(setting('shop_address')) ?></li>
          <li><i class="fa-solid fa-phone"></i> <?= e(setting('shop_phone')) ?></li>
          <li><i class="fa-solid fa-truck"></i> ارسال فقط در <?= e(setting('allowed_city','تربت حیدریه')) ?></li>
        </ul>
      </div>
      <div>
        <h4>راهنمای خرید</h4>
        <ul>
          <li><i class="fa-solid fa-check"></i> پرداخت درب منزل (نقدی)</li>
          <li><i class="fa-solid fa-check"></i> <?= e($voucher_label) ?> الکترونیکی</li>
          <li><i class="fa-solid fa-check"></i> کد تخفیف ویژه</li>
        </ul>
      </div>
      <div>
        <h4>پیگیری سفارش</h4>
        <ul>
          <li><i class="fa-solid fa-magnifying-glass-location"></i> <a href="track.php" style="color:#aab3bd">پیگیری سفارش با کد</a></li>
          <li><i class="fa-solid fa-phone"></i> <?= e(setting('shop_phone')) ?></li>
          <li><i class="fa-solid fa-truck"></i> ارسال فقط در <?= e(setting('allowed_city','تربت حیدریه')) ?></li>
        </ul>
      </div>
      <div>
        <h4>ما را دنبال کنید</h4>
        <div class="social">
          <?php if (setting('shop_instagram')): ?><a href="<?= e(setting('shop_instagram')) ?>" target="_blank"><i class="fa-brands fa-instagram"></i></a><?php endif; ?>
          <?php if (setting('shop_telegram')): ?><a href="<?= e(setting('shop_telegram')) ?>" target="_blank"><i class="fa-brands fa-telegram"></i></a><?php endif; ?>
          <a href="tel:<?= e(setting('shop_phone')) ?>"><i class="fa-solid fa-phone"></i></a>
        </div>
      </div>
    </div>
    <div class="footer-bottom">
      © <?= date('Y') ?> <?= e(setting('shop_name')) ?> — تمامی حقوق محفوظ است. | <a href="admin.php" style="color:#8b95a0">ورود مدیریت</a>
    </div>
  </div>
</footer>

<div class="overlay" id="overlay"></div>
<aside class="cart-drawer" id="cartDrawer">
  <div class="cart-head">
    <h3><i class="fa-solid fa-cart-shopping"></i> <?= e($btn_cart) ?></h3>
    <button class="close" id="closeCart">&times;</button>
  </div>
  <div class="cart-body" id="cartBody">
    <?php if ($cart_items): ?>
      <?php foreach ($cart_items as $ci): $p=$ci['p']; $curStock = get_stock($p['id']); ?>
      <div class="cart-item" data-id="<?= $p['id'] ?>" data-stock="<?= $curStock ?>">
        <div class="ci-img"><?php if($p['image']): ?><img src="<?= e($p['image']) ?>" alt=""><?php else: ?><i class="fa-solid fa-box"></i><?php endif; ?></div>
        <div class="ci-info">
          <div class="ci-name"><?= e($p['name']) ?></div>
          <div class="ci-price"><?= toman($ci['price']) ?> تومان</div>
          <?php if($ci['flash']): ?><div class="ci-flash"><i class="fa-solid fa-bolt"></i> آخر لحظه</div><?php endif; ?>
          <div class="ci-stock">موجودی: <?= $curStock ?> عدد</div>
          <div class="qty-ctrl">
            <button onclick="changeQty(<?= $p['id'] ?>,<?= $ci['qty']-1 ?>)">−</button>
            <span><?= $ci['qty'] ?></span>
            <button onclick="changeQty(<?= $p['id'] ?>,<?= $ci['qty']+1 ?>)">+</button>
            <button class="ci-remove" onclick="changeQty(<?= $p['id'] ?>,0)" title="حذف"><i class="fa-solid fa-trash"></i></button>
          </div>
        </div>
      </div>
      <?php endforeach; ?>
    <?php else: ?>
      <div class="cart-empty"><i class="fa-solid fa-cart-shopping"></i><p><?= e($btn_empty) ?></p></div>
    <?php endif; ?>
  </div>
  <?php if ($cart_items): ?>
  <div class="cart-footer">
    <div class="cart-total-row"><span>جمع کالاها:</span><span><?= toman($cart_total) ?> تومان</span></div>
    <div class="cart-total-row"><span>هزینه ارسال:</span><span><?= $delivery_fee>0 ? toman($delivery_fee).' تومان' : 'رایگان' ?></span></div>
    <div class="cart-total-row grand"><span>قابل پرداخت:</span><span><?= toman($cart_total+$delivery_fee) ?> تومان</span></div>
    <button class="btn-checkout" id="openCheckout"><i class="fa-solid fa-bag-shopping"></i> <?= e($btn_checkout) ?></button>
  </div>
  <?php endif; ?>
</aside>

<div class="modal" id="checkoutModal">
  <div class="modal-box">
    <div class="modal-head">
      <h3><i class="fa-solid fa-clipboard-list"></i> تکمیل سفارش</h3>
      <button class="close" id="closeCheckout">&times;</button>
    </div>
    <div class="modal-body">
      <?php if ($order_error): ?><div class="alert alert-error"><i class="fa-solid fa-triangle-exclamation"></i> <?= e($order_error) ?></div><?php endif; ?>

      <form method="post" action="index.php?action=place_order" id="checkoutForm">
        <div class="form-group">
          <label>نام و نام خانوادگی <span class="req">*</span></label>
          <input type="text" name="customer_name" class="form-control" required value="<?= e($_POST['customer_name'] ?? '') ?>">
        </div>
        <div class="form-group">
          <label>شماره موبایل <span class="req">*</span></label>
          <input type="tel" name="phone" class="form-control" placeholder="09xxxxxxxxx" required value="<?= e($_POST['phone'] ?? '') ?>">
        </div>
        <div class="form-group">
          <label>شهر</label>
          <input type="text" class="form-control" value="<?= e(setting('allowed_city','تربت حیدریه')) ?>" readonly style="background:#f5f6f8">
        </div>
        <div class="form-group">
          <label>آدرس دقیق (در <?= e(setting('allowed_city','تربت حیدریه')) ?>) <span class="req">*</span></label>
          <textarea name="address" class="form-control" placeholder="خیابان، کوچه، پلاک، واحد..." required><?= e($_POST['address'] ?? '') ?></textarea>
        </div>
        <div class="form-group">
          <label>توضیحات (اختیاری)</label>
          <textarea name="note" class="form-control"><?= e($_POST['note'] ?? '') ?></textarea>
        </div>

        <h4 style="margin:18px 0 12px;font-size:15px">روش پرداخت</h4>
        <div class="payment-methods">
          <?php if ($show_cod): ?>
          <div class="payment-option">
            <input type="radio" name="payment_method" value="cod" id="pm-cod" checked>
            <label for="pm-cod">
              <i class="fa-solid fa-hand-holding-dollar"></i>
              <div class="pm-title">پرداخت نقدی</div>
              <div class="pm-desc">درب منزل هنگام تحویل</div>
            </label>
          </div>
          <?php endif; ?>
          <div class="payment-option">
            <input type="radio" name="payment_method" value="voucher" id="pm-voucher">
            <label for="pm-voucher">
              <i class="fa-solid fa-ticket"></i>
              <div class="pm-title">کالابرگ</div>
              <div class="pm-desc">پرداخت از طریق کالابرگ</div>
            </label>
          </div>
        </div>

        <div class="voucher-notice" id="voucherNotice" style="display:none;margin:10px 0 14px;padding:12px 14px;background:#fff3e0;color:#a86200;border-radius:11px;font-size:12.5px;line-height:1.9;border-right:4px solid #d98324">
          <i class="fa-solid fa-circle-info"></i>
          <strong>توجه:</strong> لطفاً قبل از انتخاب از موجودی کالابرگ خود اطمینان حاصل کنید. در صورت فعال نبودن یا نداشتن موجودی کالابرگ شما، پرداخت به صورت نقدی انجام خواهد شد.
        </div>

        <h4 style="margin:18px 0 12px;font-size:15px">کدهای تخفیف</h4>
        <div class="form-group">
          <label><?= e($discount_code_label) ?></label>
          <div class="code-input-row">
            <input type="text" name="discount_code" id="discountCodeInput" class="form-control" placeholder="کد تخفیف">
            <button type="button" id="applyDiscountCode">اعمال</button>
          </div>
          <div class="code-msg" id="discountCodeMsg"></div>
        </div>

        <div style="background:#f8f9fa;border-radius:12px;padding:16px;margin-bottom:14px">
          <div class="summary-line"><span>جمع کالاها:</span><span id="sumSubtotal"><?= toman($cart_total) ?> تومان</span></div>
          <div class="summary-line discount" id="sumDiscountRow" style="display:none"><span>تخفیف کد:</span><span id="sumDiscount">-۰ تومان</span></div>
          <div class="summary-line"><span>هزینه ارسال:</span><span><?= $delivery_fee>0 ? toman($delivery_fee).' تومان':'رایگان' ?></span></div>
          <div class="summary-line total"><span>قابل پرداخت:</span><span id="sumGrand"><?= toman($cart_total+$delivery_fee) ?> تومان</span></div>
        </div>
        <button type="submit" class="btn-submit"><i class="fa-solid fa-check"></i> ثبت نهایی سفارش</button>
      </form>
    </div>
  </div>
</div>

<?php if ($order_success): ?>
<div class="modal show" id="successModal">
  <div class="modal-box">
    <div class="modal-body">
      <div class="success-box">
        <div class="ic"><i class="fa-solid fa-check"></i></div>
        <h3>سفارش شما با موفقیت ثبت شد!</h3>
        <p>کد پیگیری سفارش شما:</p>
        <div class="code"><?= e($order_success['code']) ?></div>
        <?php if($order_success['discount_amount'] > 0): ?>
          <p style="color:var(--green)">سود شما از کد تخفیف: <?= toman($order_success['discount_amount']) ?> تومان</p>
        <?php endif; ?>
        <?php if($order_success['payment_method']==='voucher'): ?>
          <div class="voucher-info" style="margin-top:14px"><i class="fa-solid fa-ticket"></i><div>روش پرداخت: کالابرگ</div></div>
        <?php else: ?>
          <div class="cod-info" style="margin-top:14px"><i class="fa-solid fa-hand-holding-dollar"></i><div><strong>پرداخت درب منزل</strong><br><small>مبلغ <?= toman($order_success['total']) ?> تومان هنگام تحویل</small></div></div>
        <?php endif; ?>
        <a href="index.php" class="btn-submit" style="display:inline-block;text-decoration:none;margin-top:18px;padding:12px 30px;width:auto"><?= e($btn_continue) ?></a>
      </div>
    </div>
  </div>
</div>
<?php endif; ?>

<div class="toast" id="toast"></div>

<script>
const overlay = document.getElementById('overlay');
const cartDrawer = document.getElementById('cartDrawer');
const checkoutModal = document.getElementById('checkoutModal');
const subtotal = <?= (int)$cart_total ?>;
const deliveryFee = <?= (int)$delivery_fee ?>;
let discountAmount = 0;

function openCart(){ cartDrawer.classList.add('show'); overlay.classList.add('show'); }
function closeCartFn(){ cartDrawer.classList.remove('show'); overlay.classList.remove('show'); }

document.getElementById('openCart').onclick = openCart;
document.getElementById('closeCart').onclick = closeCartFn;
overlay.onclick = ()=>{ closeCartFn(); checkoutModal.classList.remove('show'); };

const oc = document.getElementById('openCheckout');
if(oc) oc.onclick = ()=>{ checkoutModal.classList.add('show'); overlay.classList.add('show'); cartDrawer.classList.remove('show'); recalcTotal(); };
document.getElementById('closeCheckout').onclick = ()=>{ checkoutModal.classList.remove('show'); overlay.classList.remove('show'); };

function showToast(msg, isError){
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.classList.remove('error');
  if (isError) t.classList.add('error');
  t.classList.add('show');
  setTimeout(()=>t.classList.remove('show'), 2800);
}

document.querySelectorAll('.btn-add:not(.disabled)').forEach(btn=>{
  btn.onclick = ()=>{
    const id = btn.dataset.id;
    const stock = parseInt(btn.dataset.stock || '0', 10);
    if (stock <= 0) { showToast('این محصول ناموجود است', true); return; }
    fetch('index.php?action=add_to_cart', {
      method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'},
      body:'product_id='+id+'&qty=1'
    }).then(r=>r.json()).then(d=>{
      document.getElementById('cartCount').textContent = d.count;
      if (d.ok) { showToast(d.msg || 'به سبد خرید اضافه شد ✓'); refreshCart(); }
      else showToast(d.error || 'خطا در افزودن به سبد', true);
    });
  };
});

function changeQty(id, qty){
  fetch('index.php?action=update_cart', {
    method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body:'product_id='+id+'&qty='+qty
  }).then(r=>r.json()).then(d=>{
    document.getElementById('cartCount').textContent = d.count;
    refreshCart(true);
  });
}

function refreshCart(keepOpen){
  fetch('index.php?ajax_cart=1').then(r=>r.text()).then(resp=>{
    const parser = new DOMParser();
    const doc = parser.parseFromString('<html><body>'+resp+'</body></html>', 'text/html');
    const nodes = doc.body.childNodes;
    let itemHtml = '';
    let footerHtml = '';
    nodes.forEach(n => {
        if(n.nodeName==='DIV' && n.className.includes('cart-item')) {
            itemHtml += n.outerHTML;
        } else if(n.nodeName==='DIV' && n.className.includes('cart-footer')) {
            footerHtml = n.outerHTML;
        } else if(n.nodeName==='DIV' && n.className.includes('cart-empty')) {
            itemHtml = n.outerHTML;
        }
    });
    document.getElementById('cartBody').innerHTML = itemHtml;
    const oldFooter = document.querySelector('#cartDrawer .cart-footer');
    if(oldFooter) oldFooter.remove();
    if(footerHtml){
        const tmp = document.createElement('div');
        tmp.innerHTML = footerHtml;
        const newFooter = tmp.firstElementChild;
        cartDrawer.appendChild(newFooter);
        const btn = document.getElementById('openCheckout');
        if(btn) btn.onclick = ()=>{ checkoutModal.classList.add('show'); overlay.classList.add('show'); cartDrawer.classList.remove('show'); recalcTotal(); };
    }
  });
}
function bindCartFooter(){
  const oc = document.getElementById('openCheckout');
  if(oc) oc.onclick = ()=>{ checkoutModal.classList.add('show'); overlay.classList.add('show'); cartDrawer.classList.remove('show'); recalcTotal(); };
}

// روش پرداخت - نمایش پیام هشدار کالابرگ
document.querySelectorAll('input[name=payment_method]').forEach(r=>{
  r.onchange = ()=>{
    const notice = document.getElementById('voucherNotice');
    if (!notice) return;
    notice.style.display = (r.value === 'voucher' && r.checked) ? '' : 'none';
  };
});

function numEn(n){ return n.toLocaleString('en-US'); }

function recalcTotal(){
  const afterDiscount = subtotal - discountAmount;
  const grand = afterDiscount + deliveryFee;
  document.getElementById('sumDiscountRow').style.display = discountAmount > 0 ? '' : 'none';
  document.getElementById('sumDiscount').textContent = '- ' + numEn(discountAmount) + ' تومان';
  document.getElementById('sumGrand').textContent = numEn(grand) + ' تومان';
}

document.getElementById('applyDiscountCode')?.addEventListener('click', ()=>{
  const code = document.getElementById('discountCodeInput').value.trim();
  const msg = document.getElementById('discountCodeMsg');
  if (!code) { msg.className = 'code-msg show err'; msg.textContent = 'کد را وارد کنید'; return; }
  fetch('index.php?action=validate_discount_code', {
    method:'POST', headers:{'Content-Type':'application/x-www-form-urlencoded'},
    body:'code='+encodeURIComponent(code)+'&subtotal='+subtotal
  }).then(r=>r.json()).then(d=>{
    if (d.ok) {
      discountAmount = d.amount;
      msg.className = 'code-msg show ok';
      msg.textContent = d.message + ' (تخفیف: ' + numEn(d.amount) + ' تومان)';
      recalcTotal();
    } else {
      discountAmount = 0;
      msg.className = 'code-msg show err';
      msg.textContent = d.error;
      recalcTotal();
    }
  });
});

// شمارش معکوس فلش‌سیل
function updateCountdowns(){
  document.querySelectorAll('.flash-timer').forEach(el=>{
    const ends = new Date(el.dataset.ends.replace(' ', 'T')).getTime();
    const now = Date.now();
    const diff = ends - now;
    if (diff <= 0) {
      el.classList.add('expired');
      el.querySelector('.countdown').textContent = 'پایان یافت';
      // بازگرداندن قیمت اصلی
      const card = el.closest('.product-card');
      if (card) {
        const newPrice = card.dataset.originalPrice;
        const priceEl = card.querySelector('.price');
        if (newPrice && priceEl) {
          priceEl.innerHTML = numEn(parseInt(newPrice)) + ' <small>تومان</small>';
          priceEl.classList.remove('price');
          priceEl.classList.add('price', 'old');
        }
      }
      return;
    }
    const h = Math.floor(diff/3600000);
    const m = Math.floor((diff%3600000)/60000);
    const s = Math.floor((diff%60000)/1000);
    el.querySelector('.countdown').textContent =
      (h>0?h+':':'') + String(m).padStart(2,'0') + ':' + String(s).padStart(2,'0');
  });
}
setInterval(updateCountdowns, 1000);
updateCountdowns();

<?php if ($order_error): ?>
window.addEventListener('load', ()=>{ checkoutModal.classList.add('show'); overlay.classList.add('show'); });
<?php endif; ?>
</script>
</body>
</html>