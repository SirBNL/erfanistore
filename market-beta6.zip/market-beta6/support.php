<?php
/**
 * ============================================================
 *  support.php  -  پنل پشتیبان سایت
 *  مدیریت اشتراک، قفل/آزادسازی، تمدید، تیکت‌ها، اطلاعات تماس
 * ============================================================
 */
error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE);
ini_set('display_errors', 0);
date_default_timezone_set('Asia/Tehran');
session_start();

define('DB_FILE', __DIR__ . '/shop_data.sqlite');
if (!file_exists(DB_FILE)) { die('Database not found. ابتدا فروشگاه را اجرا کنید.'); }

$pdo = new PDO('sqlite:' . DB_FILE);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

function e($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
function setting_v($key, $default='') {
    global $pdo;
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        foreach ($pdo->query("SELECT key, value FROM settings")->fetchAll() as $r) {
            $cache[$r['key']] = $r['value'];
        }
    }
    return isset($cache[$key]) ? $cache[$key] : $default;
}
function save_v($key, $value) {
    global $pdo;
    $st = $pdo->prepare("INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=?");
    $st->execute([$key, $value, $value]);
}

// --- Logout ---
if (isset($_GET['logout'])) { unset($_SESSION['support_logged']); header('Location: support.php'); exit; }

// --- Login ---
$login_err = '';
if (isset($_POST['support_login'])) {
    if ($_POST['support_login'] === setting_v('support_password','support123')) {
        $_SESSION['support_logged'] = true;
        header('Location: support.php'); exit;
    } else { $login_err = 'رمز اشتباه است!'; }
}

if (empty($_SESSION['support_logged'])) {
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<title>پنل پشتیبان</title>
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css">
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:'Vazirmatn',sans-serif;}
body{background:linear-gradient(135deg,#0f2027,#203a43,#2c5364);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:16px;}
.login-card{background:#fff;border-radius:20px;padding:40px 32px;width:100%;max-width:400px;box-shadow:0 20px 50px rgba(0,0,0,.4);text-align:center;}
.login-card .ic{width:80px;height:80px;border-radius:50%;background:linear-gradient(135deg,#2c5364,#0f2027);color:#fff;font-size:32px;display:flex;align-items:center;justify-content:center;margin:0 auto 18px;}
.login-card h1{font-size:22px;margin-bottom:6px;color:#0f2027;}
.login-card p{color:#888;font-size:14px;margin-bottom:24px;}
.login-card input{width:100%;padding:14px;border:2px solid #eee;border-radius:12px;font-size:16px;outline:none;text-align:center;font-family:inherit;margin-bottom:16px;}
.login-card input:focus{border-color:#2c5364;}
.login-card button{width:100%;background:linear-gradient(135deg,#2c5364,#0f2027);color:#fff;padding:14px;border-radius:12px;font-size:16px;font-weight:700;border:none;cursor:pointer;}
.err{background:#fde8e8;color:#c0392b;padding:10px;border-radius:10px;font-size:14px;margin-bottom:14px;}
</style>
</head>
<body>
<form class="login-card" method="post">
  <div class="ic"><i class="fa-solid fa-shield-halved"></i></div>
  <h1>پنل پشتیبان سایت</h1>
  <p>مدیریت اشتراک، تیکت و سرویس‌ها</p>
  <?php if($login_err): ?><div class="err"><i class="fa-solid fa-circle-exclamation"></i> <?= e($login_err) ?></div><?php endif; ?>
  <input type="password" name="support_login" placeholder="رمز پشتیبان" required autofocus>
  <button type="submit"><i class="fa-solid fa-right-to-bracket"></i> ورود</button>
</form>
</body>
</html>
<?php exit; }

// ====== کاربر لاگین کرده ======

$now = date('Y-m-d H:i:s');
$msg = ''; $msg_type = 'success';
$page = $_GET['page'] ?? 'dashboard';

function plan_days($plan) {
    return ['monthly'=>30,'quarterly'=>90,'semiannual'=>180,'annual'=>365,'permanent'=>0][$plan] ?? 0;
}

$op = $_POST['op'] ?? ($_GET['op'] ?? '');

if ($op === 'set_plan') {
    $plan = $_POST['plan'] ?? 'permanent';
    $duration_days = (int)($_POST['duration_days'] ?? 0);
    if (!in_array($plan, ['monthly','quarterly','semiannual','annual','permanent'])) {
        $msg = 'پلن نامعتبر'; $msg_type='error';
    } else {
        save_v('license_plan', $plan);
        save_v('license_start', $now);
        save_v('license_locked','0');
        if ($plan === 'permanent') {
            save_v('license_expires','');
        } else {
            $days = $duration_days > 0 ? $duration_days : plan_days($plan);
            save_v('license_expires', date('Y-m-d H:i:s', strtotime("+$days days")));
        }
        $msg = "پلن سرویس روی «" . ['monthly'=>'ماهانه','quarterly'=>'سه‌ماهه','semiannual'=>'شش‌ماهه','annual'=>'سالانه','permanent'=>'دائمی'][$plan] . "» تنظیم شد.";
    }
}
if ($op === 'extend_days') {
    $days = (int)$_POST['days'];
    $cur = setting_v('license_expires');
    $base = ($cur && strtotime($cur) > time()) ? strtotime($cur) : time();
    $new = date('Y-m-d H:i:s', $base + $days * 86400);
    save_v('license_expires', $new);
    save_v('license_locked','0');
    if (setting_v('license_plan') === 'permanent') save_v('license_plan','monthly');
    $msg = "$days روز به اعتبار اضافه شد.";
}
if ($op === 'lock_service') {
    save_v('license_locked','1');
    $msg = 'سرویس قفل شد. کاربر تا تمدید نمی‌تواند به پنل دسترسی داشته باشد.';
}
if ($op === 'unlock_service') {
    save_v('license_locked','0');
    $msg = 'قفل سرویس برداشته شد.';
}
if ($op === 'mark_permanent') {
    save_v('license_plan','permanent');
    save_v('license_expires','');
    save_v('license_locked','0');
    $msg = 'سرویس به حالت دائمی تبدیل شد.';
}
if ($op === 'handle_request') {
    $rid = (int)$_POST['rid'];
    $action = $_POST['action'];
    if ($action === 'approve') {
        $r = $pdo->prepare("SELECT * FROM renewal_requests WHERE id=?"); $r->execute([$rid]); $req = $r->fetch();
        if ($req) {
            save_v('license_plan', $req['plan_type']);
            save_v('license_start', $now);
            save_v('license_locked','0');
            if ($req['plan_type'] === 'permanent') {
                save_v('license_expires','');
            } else {
                $d = plan_days($req['plan_type']);
                save_v('license_expires', date('Y-m-d H:i:s', time() + $d*86400));
            }
            $pdo->prepare("UPDATE renewal_requests SET status='approved', handled_at=? WHERE id=?")->execute([$now,$rid]);
            $msg = 'درخواست تأیید و پلن فعال شد.';
        }
    } elseif ($action === 'reject') {
        $pdo->prepare("UPDATE renewal_requests SET status='rejected', handled_at=? WHERE id=?")->execute([$now,$rid]);
        $msg = 'درخواست رد شد.';
    }
}
if ($op === 'change_support_password') {
    $new = $_POST['new_pass'] ?? '';
    if (strlen($new) < 4) { $msg='رمز جدید حداقل ۴ کاراکتر باشد.'; $msg_type='error'; }
    else { save_v('support_password', $new); $msg='رمز پشتیبان تغییر کرد.'; }
}
if ($op === 'save_contact_info') {
    // فقط پشتیبان حق ویرایش اطلاعات تماس و کارت بانکی را دارد
    $keys = ['support_name','support_phone','support_telegram','support_soroush','support_card_number','support_card_holder','support_bank_name'];
    foreach ($keys as $k) {
        if (isset($_POST[$k])) save_v($k, trim($_POST[$k]));
    }
    $msg = 'اطلاعات تماس و کارت بانکی ذخیره شد.';
}

// --- پاسخ به تیکت ---
if ($op === 'reply_ticket') {
    $tid = (int)$_POST['ticket_id'];
    $message = trim($_POST['message'] ?? '');
    if ($message === '') { $msg='متن پاسخ خالی است.'; $msg_type='error'; }
    else {
        $pdo->prepare("INSERT INTO ticket_messages (ticket_id,sender,message,is_read_by_admin,is_read_by_support,created_at) VALUES (?,?,?,?,?,?)")
            ->execute([$tid,'support',$message,0,1,$now]);
        $pdo->prepare("UPDATE support_tickets SET status='open', last_reply_by='support', updated_at=? WHERE id=?")->execute([$now,$tid]);
        header('Location: support.php?page=ticket&id='.$tid); exit;
    }
}
if ($op === 'close_ticket_support') {
    $tid = (int)$_POST['ticket_id'];
    $pdo->prepare("UPDATE support_tickets SET status='closed', updated_at=? WHERE id=?")->execute([$now,$tid]);
    $msg = 'تیکت بسته شد.';
    header('Location: support.php?page=tickets'); exit;
}
if ($op === 'reopen_ticket') {
    $tid = (int)$_POST['ticket_id'];
    $pdo->prepare("UPDATE support_tickets SET status='open', updated_at=? WHERE id=?")->execute([$now,$tid]);
    $msg = 'تیکت بازگشایی شد.';
    header('Location: support.php?page=ticket&id='.$tid); exit;
}

// ===== Reload settings cache =====
$pdo_q = $pdo->query("SELECT key,value FROM settings")->fetchAll();
$settings = []; foreach($pdo_q as $r) $settings[$r['key']] = $r['value'];

$plan = $settings['license_plan'] ?? 'permanent';
$expires = $settings['license_expires'] ?? '';
$locked = ($settings['license_locked'] ?? '0') === '1';
$is_permanent = $plan === 'permanent';
$days_left = null; $is_expired = false;
if (!$is_permanent && $expires) {
    $ts = strtotime($expires);
    $days_left = (int)ceil(($ts - time()) / 86400);
    if ($ts < time()) $is_expired = true;
}

$plan_labels = ['permanent'=>'دائمی','monthly'=>'۱ ماهه','quarterly'=>'۳ ماهه','semiannual'=>'۶ ماهه','annual'=>'سالانه'];
$prio_lbl = ['low'=>'کم','normal'=>'عادی','high'=>'بالا','urgent'=>'فوری'];
$prio_color = ['low'=>'#7c8893','normal'=>'#457b9d','high'=>'#f4a261','urgent'=>'#e63946'];

// شمارش پیام‌های جدید برای پشتیبان
$new_messages = (int)$pdo->query("SELECT COUNT(*) c FROM ticket_messages WHERE sender='admin' AND is_read_by_support=0")->fetch()['c'];
$pending_requests_count = (int)$pdo->query("SELECT COUNT(*) c FROM renewal_requests WHERE status='pending'")->fetch()['c'];
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width,initial-scale=1">
<title>پنل پشتیبان - <?= e(setting_v('shop_name')) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css">
<style>
*{margin:0;padding:0;box-sizing:border-box;font-family:'Vazirmatn',sans-serif;}
body{background:#eef1f5;color:#222;min-height:100vh;}
.layout{display:flex;min-height:100vh;}
.sidebar{width:250px;background:linear-gradient(180deg,#0f2027,#2c5364);color:#fff;padding:18px;flex-shrink:0;}
.sidebar .brand{font-size:17px;font-weight:700;margin-bottom:20px;padding-bottom:14px;border-bottom:1px solid rgba(255,255,255,.15);display:flex;align-items:center;gap:10px;}
.sidebar .brand i{font-size:22px;color:#2a9d8f;}
.sidebar nav a{display:flex;align-items:center;gap:10px;padding:11px 14px;border-radius:10px;color:#dbe5ec;text-decoration:none;margin-bottom:5px;font-size:13.5px;justify-content:space-between;}
.sidebar nav a:hover{background:rgba(255,255,255,.08);}
.sidebar nav a.active{background:#2a9d8f;color:#fff;font-weight:600;}
.sidebar .label{display:flex;align-items:center;gap:10px;}
.sidebar .badge{background:#e63946;color:#fff;padding:2px 8px;border-radius:10px;font-size:11px;font-weight:700;}
.sidebar .sec-title{font-size:11px;color:#7d8a92;text-transform:uppercase;margin:14px 6px 6px;letter-spacing:1px;}
.main{flex:1;padding:24px;overflow-x:auto;}
.topbar{background:#fff;padding:14px 22px;border-radius:14px;margin-bottom:16px;display:flex;justify-content:space-between;align-items:center;box-shadow:0 2px 8px rgba(0,0,0,.05);}
.topbar h1{font-size:18px;color:#0f2027;}
.topbar a.logout{background:#e63946;color:#fff;padding:8px 16px;border-radius:10px;text-decoration:none;font-size:13px;}
.alert{padding:14px 18px;border-radius:12px;margin-bottom:16px;font-weight:600;}
.alert.success{background:#d4edda;color:#155724;border-right:4px solid #28a745;}
.alert.error{background:#f8d7da;color:#721c24;border-right:4px solid #dc3545;}
.alert.warning{background:#fff3cd;color:#856404;border-right:4px solid #ffc107;}
.grid{display:grid;grid-template-columns:1fr 1fr;gap:18px;}
@media(max-width:768px){.layout{flex-direction:column;}.sidebar{width:100%;}.grid{grid-template-columns:1fr;}}
.panel{background:#fff;border-radius:16px;padding:22px;box-shadow:0 4px 14px rgba(0,0,0,.06);margin-bottom:18px;}
.panel h2{font-size:17px;margin-bottom:16px;color:#0f2027;display:flex;align-items:center;gap:8px;padding-bottom:10px;border-bottom:2px solid #f0f0f0;justify-content:space-between;}
.status-card{background:linear-gradient(135deg,<?= $is_permanent?'#2a9d8f,#1d8478':($is_expired||$locked?'#e63946,#a52030':($days_left!==null&&$days_left<=7?'#f4a261,#d68a4a':'#1d3557,#16334b')) ?>);color:#fff;padding:26px;border-radius:16px;text-align:center;margin-bottom:18px;}
.status-card .ic{font-size:46px;margin-bottom:10px;}
.status-card h2{font-size:24px;margin-bottom:6px;border:none;color:#fff;padding:0;justify-content:center;}
.status-card .info{font-size:16px;opacity:.95;}
.form-group{margin-bottom:14px;}
.form-group label{display:block;font-size:13px;color:#555;margin-bottom:6px;font-weight:600;}
.form-control{width:100%;padding:11px 14px;border:1.5px solid #e0e4e8;border-radius:10px;font-family:inherit;font-size:14px;outline:none;}
.form-control:focus{border-color:#2c5364;}
.form-row{display:grid;grid-template-columns:1fr 1fr;gap:14px;}
@media(max-width:600px){.form-row{grid-template-columns:1fr;}}
.btn{padding:10px 18px;border-radius:10px;border:none;cursor:pointer;font-family:inherit;font-weight:600;font-size:13px;display:inline-flex;align-items:center;gap:6px;text-decoration:none;}
.btn-primary{background:#1d3557;color:#fff;}
.btn-success{background:#2a9d8f;color:#fff;}
.btn-danger{background:#e63946;color:#fff;}
.btn-warning{background:#f4a261;color:#fff;}
.btn-secondary{background:#6c757d;color:#fff;}
.btn:hover{filter:brightness(.92);}
.quick-btns{display:flex;flex-wrap:wrap;gap:6px;margin-top:8px;}
.quick-btns .btn{flex:1;min-width:80px;justify-content:center;font-size:12px;padding:9px 10px;}
.req-card{border:1px solid #e8e8e8;padding:14px;border-radius:12px;margin-bottom:10px;background:#fafbfc;}
.req-card .head{display:flex;justify-content:space-between;align-items:center;margin-bottom:6px;flex-wrap:wrap;gap:6px;}
.req-card .plan-tag{background:#9b59b6;color:#fff;padding:3px 10px;border-radius:10px;font-size:11px;font-weight:600;}
.req-card .note{font-size:13px;color:#555;background:#fff;padding:8px 12px;border-radius:8px;margin:8px 0;}
.req-card .actions{display:flex;gap:6px;margin-top:8px;flex-wrap:wrap;}
.table-wrap{overflow-x:auto;}
table{width:100%;border-collapse:collapse;font-size:13px;}
th,td{padding:10px 8px;text-align:right;border-bottom:1px solid #eee;}
th{background:#f8f9fa;font-weight:700;color:#555;font-size:12px;}
.tag-status-open{background:#2a9d8f;color:#fff;padding:3px 10px;border-radius:10px;font-size:11px;font-weight:600;}
.tag-status-closed{background:#7c8893;color:#fff;padding:3px 10px;border-radius:10px;font-size:11px;font-weight:600;}
.badge{padding:3px 10px;border-radius:10px;color:#fff;font-size:11px;font-weight:600;}
.message-bubble{padding:14px 18px;border-radius:14px;max-width:75%;margin-bottom:12px;line-height:1.9;white-space:pre-wrap;}
.msg-from-admin{background:#1d3557;color:#fff;margin-right:auto;border-top-right-radius:4px;}
.msg-from-support{background:#f0f4f8;border:1.5px solid #e0e8ee;margin-left:auto;border-top-left-radius:4px;}
.msg-meta{font-size:11px;opacity:.75;margin-bottom:6px;font-weight:600;}
.msg-wrap{display:flex;margin-bottom:14px;}
.msg-wrap.admin{flex-direction:row;}
.msg-wrap.support{flex-direction:row-reverse;}
.avatar{width:40px;height:40px;border-radius:50%;display:flex;align-items:center;justify-content:center;color:#fff;flex-shrink:0;margin:0 10px;}
.avatar.admin{background:#1d3557;}
.avatar.support{background:#2a9d8f;}
</style>
</head>
<body>
<div class="layout">
  <aside class="sidebar">
    <div class="brand"><i class="fa-solid fa-shield-halved"></i> پنل پشتیبان</div>
    <div class="sec-title">داشبورد</div>
    <nav>
      <a href="support.php?page=dashboard" class="<?= $page=='dashboard'?'active':'' ?>">
        <span class="label"><i class="fa-solid fa-gauge-high"></i> داشبورد اصلی</span>
      </a>
      <a href="support.php?page=tickets" class="<?= in_array($page,['tickets','ticket'])?'active':'' ?>">
        <span class="label"><i class="fa-solid fa-comments"></i> تیکت‌ها</span>
        <?php if($new_messages>0): ?><span class="badge"><?= $new_messages ?></span><?php endif; ?>
      </a>
      <a href="support.php?page=subscription" class="<?= $page=='subscription'?'active':'' ?>">
        <span class="label"><i class="fa-solid fa-id-card-clip"></i> مدیریت اشتراک</span>
        <?php if($pending_requests_count>0): ?><span class="badge"><?= $pending_requests_count ?></span><?php endif; ?>
      </a>
    </nav>
    <div class="sec-title">تنظیمات</div>
    <nav>
      <a href="support.php?page=contact_info" class="<?= $page=='contact_info'?'active':'' ?>">
        <span class="label"><i class="fa-solid fa-address-card"></i> اطلاعات تماس</span>
      </a>
      <a href="support.php?page=password" class="<?= $page=='password'?'active':'' ?>">
        <span class="label"><i class="fa-solid fa-key"></i> تغییر رمز</span>
      </a>
    </nav>
    <div class="sec-title">دیگر</div>
    <nav>
      <a href="admin.php" target="_blank"><span class="label"><i class="fa-solid fa-store"></i> پنل فروشگاه</span></a>
      <a href="index.php" target="_blank"><span class="label"><i class="fa-solid fa-house"></i> سایت</span></a>
    </nav>
  </aside>

  <main class="main">
    <div class="topbar">
      <h1>
        <?php
        $page_titles = [
          'dashboard'=>'<i class="fa-solid fa-gauge-high"></i> داشبورد پنل پشتیبان',
          'tickets'=>'<i class="fa-solid fa-comments"></i> تیکت‌های پشتیبانی',
          'ticket'=>'<i class="fa-solid fa-ticket"></i> مشاهده تیکت',
          'subscription'=>'<i class="fa-solid fa-id-card-clip"></i> مدیریت اشتراک سرویس',
          'contact_info'=>'<i class="fa-solid fa-address-card"></i> اطلاعات تماس و کارت بانکی',
          'password'=>'<i class="fa-solid fa-key"></i> تغییر رمز پنل',
        ];
        echo $page_titles[$page] ?? 'پنل پشتیبان';
        ?>
      </h1>
      <a href="support.php?logout=1" class="logout"><i class="fa-solid fa-right-from-bracket"></i> خروج</a>
    </div>

    <?php if($msg): ?>
    <div class="alert <?= $msg_type ?>"><i class="fa-solid fa-<?= $msg_type=='success'?'circle-check':'circle-exclamation' ?>"></i> <?= e($msg) ?></div>
    <?php endif; ?>

    <?php if($is_expired && !$is_permanent && $page=='dashboard'): ?>
    <div class="alert error" style="font-size:15px"><i class="fa-solid fa-triangle-exclamation"></i> 
      <strong>توجه:</strong> زمان اشتراک این سرویس به پایان رسیده است. لطفاً اقدام لازم را انجام دهید.
    </div>
    <?php endif; ?>

    <?php if($page === 'dashboard'): ?>
      <!-- ========== داشبورد ========== -->
      <div class="status-card">
        <div class="ic"><i class="fa-solid fa-<?= $is_permanent?'infinity':($is_expired||$locked?'lock':'circle-check') ?>"></i></div>
        <h2>پلن فعلی: <?= e($plan_labels[$plan] ?? $plan) ?></h2>
        <?php if($is_permanent): ?>
          <div class="info">اشتراک دائمی - بدون محدودیت زمانی</div>
        <?php elseif($locked): ?>
          <div class="info">⛔ سرویس توسط پشتیبان قفل شده است</div>
        <?php elseif($is_expired): ?>
          <div class="info">⏰ اشتراک منقضی شده است</div>
        <?php else: ?>
          <div class="info">باقیمانده: <strong style="font-size:28px"><?= max(0,$days_left) ?></strong> روز</div>
        <?php endif; ?>
        <?php if($expires && !$is_permanent): ?>
          <div style="font-size:13px;opacity:.85;margin-top:6px">تاریخ انقضا: <?= e($expires) ?></div>
        <?php endif; ?>
      </div>

      <div class="grid">
        <div class="panel">
          <h2><i class="fa-solid fa-comments" style="color:#2a9d8f"></i> تیکت‌های جدید</h2>
          <?php
          $recent_tickets = $pdo->query("SELECT t.*, (SELECT COUNT(*) FROM ticket_messages WHERE ticket_id=t.id AND sender='admin' AND is_read_by_support=0) unread FROM support_tickets t WHERE status='open' ORDER BY updated_at DESC LIMIT 5")->fetchAll();
          if(!$recent_tickets):
          ?>
            <p style="color:#999;text-align:center;padding:20px">هیچ تیکت باز شده‌ای نیست</p>
          <?php else: foreach($recent_tickets as $t): ?>
            <a href="support.php?page=ticket&id=<?= $t['id'] ?>" style="display:block;padding:10px 12px;background:#fafbfc;border-radius:10px;margin-bottom:8px;text-decoration:none;color:#222">
              <div style="display:flex;justify-content:space-between;align-items:center">
                <div>
                  <strong><?= e($t['subject']) ?></strong>
                  <?php if($t['unread']>0): ?><span class="badge" style="margin-right:6px;background:#e63946"><?= $t['unread'] ?> جدید</span><?php endif; ?>
                </div>
                <span class="badge" style="background:<?= $prio_color[$t['priority']] ?>"><?= e($prio_lbl[$t['priority']]) ?></span>
              </div>
              <small style="color:#888"><?= e($t['updated_at']) ?></small>
            </a>
          <?php endforeach; endif; ?>
          <a href="support.php?page=tickets" class="btn btn-primary" style="width:100%;justify-content:center;margin-top:10px"><i class="fa-solid fa-list"></i> همه تیکت‌ها</a>
        </div>

        <div class="panel">
          <h2><i class="fa-solid fa-bell" style="color:#f4a261"></i> درخواست‌های تمدید</h2>
          <?php
          $pending_requests = $pdo->query("SELECT * FROM renewal_requests WHERE status='pending' ORDER BY id DESC LIMIT 5")->fetchAll();
          if(!$pending_requests):
          ?>
            <p style="color:#999;text-align:center;padding:20px">درخواست در انتظاری نیست</p>
          <?php else: foreach($pending_requests as $r): ?>
            <div class="req-card">
              <div class="head">
                <strong>#<?= $r['id'] ?></strong>
                <span class="plan-tag"><?= e($plan_labels[$r['plan_type']] ?? $r['plan_type']) ?></span>
              </div>
              <?php if($r['note']): ?><div class="note"><?= e($r['note']) ?></div><?php endif; ?>
              <div class="actions">
                <form method="post" style="display:inline">
                  <input type="hidden" name="op" value="handle_request">
                  <input type="hidden" name="rid" value="<?= $r['id'] ?>">
                  <input type="hidden" name="action" value="approve">
                  <button class="btn btn-success" onclick="return confirm('پلن فعال شود؟')"><i class="fa-solid fa-check"></i> تأیید و فعال‌سازی</button>
                </form>
                <form method="post" style="display:inline">
                  <input type="hidden" name="op" value="handle_request">
                  <input type="hidden" name="rid" value="<?= $r['id'] ?>">
                  <input type="hidden" name="action" value="reject">
                  <button class="btn btn-danger" onclick="return confirm('رد شود؟')"><i class="fa-solid fa-xmark"></i> رد درخواست</button>
                </form>
              </div>
            </div>
          <?php endforeach; endif; ?>
          <a href="support.php?page=subscription" class="btn btn-primary" style="width:100%;justify-content:center;margin-top:10px"><i class="fa-solid fa-sliders"></i> مدیریت اشتراک</a>
        </div>
      </div>

    <?php elseif($page === 'tickets'):
      $filter = $_GET['filter'] ?? 'all';
      $where = '';
      if($filter==='open') $where = "WHERE t.status='open'";
      if($filter==='closed') $where = "WHERE t.status='closed'";
      $tickets = $pdo->query("SELECT t.*, (SELECT COUNT(*) FROM ticket_messages WHERE ticket_id=t.id AND sender='admin' AND is_read_by_support=0) unread, (SELECT message FROM ticket_messages WHERE ticket_id=t.id ORDER BY id DESC LIMIT 1) last_msg FROM support_tickets t $where ORDER BY CASE status WHEN 'open' THEN 1 ELSE 2 END, t.updated_at DESC")->fetchAll();
    ?>
      <!-- ========== لیست تیکت‌ها ========== -->
      <div class="panel">
        <h2>
          <span><i class="fa-solid fa-comments"></i> مدیریت تیکت‌ها</span>
          <div style="display:flex;gap:6px">
            <a href="support.php?page=tickets&filter=all" class="btn btn-<?= $filter=='all'?'primary':'secondary' ?>" style="padding:6px 12px;font-size:12px">همه</a>
            <a href="support.php?page=tickets&filter=open" class="btn btn-<?= $filter=='open'?'success':'secondary' ?>" style="padding:6px 12px;font-size:12px">باز</a>
            <a href="support.php?page=tickets&filter=closed" class="btn btn-<?= $filter=='closed'?'warning':'secondary' ?>" style="padding:6px 12px;font-size:12px">بسته</a>
          </div>
        </h2>
        <?php if(!$tickets): ?>
          <p style="color:#999;text-align:center;padding:30px"><i class="fa-solid fa-inbox" style="font-size:40px;display:block;margin-bottom:8px;color:#ddd"></i> هیچ تیکتی یافت نشد</p>
        <?php else: ?>
          <div class="table-wrap">
            <table>
              <thead><tr><th>#</th><th>عنوان</th><th>اولویت</th><th>وضعیت</th><th>آخرین پیام</th><th>آخرین تغییر</th><th>عملیات</th></tr></thead>
              <tbody>
                <?php foreach($tickets as $t): ?>
                <tr>
                  <td><strong>#<?= $t['id'] ?></strong></td>
                  <td>
                    <strong><?= e($t['subject']) ?></strong>
                    <?php if($t['unread']>0): ?><span class="badge" style="margin-right:6px;background:#e63946"><?= $t['unread'] ?> پیام جدید</span><?php endif; ?>
                  </td>
                  <td><span class="badge" style="background:<?= $prio_color[$t['priority']] ?>"><?= e($prio_lbl[$t['priority']]) ?></span></td>
                  <td>
                    <span class="<?= $t['status']=='open'?'tag-status-open':'tag-status-closed' ?>"><?= $t['status']=='open'?'باز':'بسته' ?></span>
                    <?php if($t['last_reply_by']=='admin' && $t['status']=='open'): ?><br><small style="color:#e63946">منتظر پاسخ شما</small><?php endif; ?>
                  </td>
                  <td style="font-size:12px;color:#666;max-width:240px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= e(mb_substr($t['last_msg'] ?? '',0,50,'UTF-8')) ?></td>
                  <td style="font-size:11px;color:#888;white-space:nowrap"><?= e($t['updated_at']) ?></td>
                  <td><a href="support.php?page=ticket&id=<?= $t['id'] ?>" class="btn btn-primary" style="padding:6px 12px;font-size:12px"><i class="fa-solid fa-eye"></i> مشاهده</a></td>
                </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
          </div>
        <?php endif; ?>
      </div>

    <?php elseif($page === 'ticket'):
      $tid = (int)($_GET['id'] ?? 0);
      $st = $pdo->prepare("SELECT * FROM support_tickets WHERE id=?"); $st->execute([$tid]);
      $ticket = $st->fetch();
      if(!$ticket): echo '<div class="alert error">تیکت یافت نشد.</div>';
      else:
        // علامت‌گذاری خوانده شده
        $pdo->prepare("UPDATE ticket_messages SET is_read_by_support=1 WHERE ticket_id=? AND sender='admin'")->execute([$tid]);
        $msgs_q = $pdo->prepare("SELECT * FROM ticket_messages WHERE ticket_id=? ORDER BY id ASC");
        $msgs_q->execute([$tid]);
        $msgs = $msgs_q->fetchAll();
    ?>
      <!-- ========== مشاهده تیکت ========== -->
      <div class="panel">
        <h2>
          <span><i class="fa-solid fa-ticket"></i> تیکت #<?= $ticket['id'] ?>: <?= e($ticket['subject']) ?></span>
          <a href="support.php?page=tickets" class="btn btn-secondary" style="padding:6px 12px;font-size:12px"><i class="fa-solid fa-arrow-right"></i> بازگشت</a>
        </h2>
        <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:18px;font-size:13px;padding:10px;background:#f8f9fa;border-radius:10px">
          <span><strong>وضعیت:</strong> <span class="<?= $ticket['status']=='open'?'tag-status-open':'tag-status-closed' ?>"><?= $ticket['status']=='open'?'باز':'بسته' ?></span></span>
          <span><strong>اولویت:</strong> <span class="badge" style="background:<?= $prio_color[$ticket['priority']] ?>"><?= e($prio_lbl[$ticket['priority']]) ?></span></span>
          <span><strong>تاریخ ثبت:</strong> <?= e($ticket['created_at']) ?></span>
        </div>

        <div style="display:flex;flex-direction:column;gap:10px;margin-bottom:18px">
          <?php foreach($msgs as $m): $is_admin = $m['sender']==='admin'; ?>
            <div class="msg-wrap <?= $is_admin?'admin':'support' ?>">
              <div class="avatar <?= $is_admin?'admin':'support' ?>">
                <i class="fa-solid fa-<?= $is_admin?'user':'headset' ?>"></i>
              </div>
              <div class="message-bubble <?= $is_admin?'msg-from-admin':'msg-from-support' ?>">
                <div class="msg-meta">
                  <strong><?= $is_admin?'ادمین فروشگاه':'شما (پشتیبان)' ?></strong> • <?= e($m['created_at']) ?>
                </div>
                <div><?= nl2br(e($m['message'])) ?></div>
              </div>
            </div>
          <?php endforeach; ?>
        </div>

        <?php if($ticket['status']==='open'): ?>
        <hr style="margin:18px 0;border:none;border-top:1px dashed #ddd">
        <form method="post">
          <input type="hidden" name="ticket_id" value="<?= $ticket['id'] ?>">
          <div class="form-group">
            <label><i class="fa-solid fa-reply"></i> پاسخ شما به ادمین</label>
            <textarea name="message" class="form-control" rows="5" required placeholder="پاسختان را بنویسید..."></textarea>
          </div>
          <div style="display:flex;gap:8px;flex-wrap:wrap">
            <button type="submit" name="op" value="reply_ticket" class="btn btn-success"><i class="fa-solid fa-paper-plane"></i> ارسال پاسخ</button>
            <button type="submit" name="op" value="close_ticket_support" formnovalidate class="btn btn-warning" onclick="return confirm('این تیکت بسته شود؟ ادمین بعد از آن نمی‌تواند پاسخ دهد.')"><i class="fa-solid fa-lock"></i> بستن تیکت</button>
          </div>
        </form>
        <?php else: ?>
          <div style="background:#fff8e1;padding:14px;border-radius:10px;text-align:center;color:#7a5d00">
            <i class="fa-solid fa-lock"></i> این تیکت بسته شده است.
            <form method="post" style="display:inline;margin-right:10px">
              <input type="hidden" name="op" value="reopen_ticket">
              <input type="hidden" name="ticket_id" value="<?= $ticket['id'] ?>">
              <button class="btn btn-primary" style="padding:6px 14px;font-size:12px"><i class="fa-solid fa-rotate-left"></i> بازگشایی تیکت</button>
            </form>
          </div>
        <?php endif; ?>
      </div>
      <?php endif; ?>

    <?php elseif($page === 'subscription'):
      $pending_requests = $pdo->query("SELECT * FROM renewal_requests WHERE status='pending' ORDER BY id DESC")->fetchAll();
      $all_requests = $pdo->query("SELECT * FROM renewal_requests ORDER BY id DESC LIMIT 50")->fetchAll();
    ?>
      <!-- ========== مدیریت اشتراک ========== -->
      <div class="status-card">
        <div class="ic"><i class="fa-solid fa-<?= $is_permanent?'infinity':($is_expired||$locked?'lock':'circle-check') ?>"></i></div>
        <h2>پلن فعلی: <?= e($plan_labels[$plan] ?? $plan) ?></h2>
        <?php if($is_permanent): ?>
          <div class="info">اشتراک دائمی</div>
        <?php elseif($locked): ?>
          <div class="info">⛔ قفل شده</div>
        <?php elseif($is_expired): ?>
          <div class="info">⏰ منقضی شده</div>
        <?php else: ?>
          <div class="info">باقیمانده: <strong style="font-size:26px"><?= max(0,$days_left) ?></strong> روز</div>
        <?php endif; ?>
        <?php if($expires && !$is_permanent): ?>
          <div style="font-size:12px;opacity:.85;margin-top:6px">انقضا: <?= e($expires) ?></div>
        <?php endif; ?>
      </div>

      <?php if(count($pending_requests)): ?>
      <div class="panel">
        <h2><i class="fa-solid fa-bell" style="color:#f4a261"></i> درخواست‌های در انتظار (<?= count($pending_requests) ?>)</h2>
        <?php foreach($pending_requests as $r): ?>
        <div class="req-card">
          <div class="head">
            <div><strong>درخواست #<?= $r['id'] ?></strong> <small style="color:#999"><?= e($r['created_at']) ?></small></div>
            <span class="plan-tag"><?= e($plan_labels[$r['plan_type']] ?? $r['plan_type']) ?></span>
          </div>
          <?php if($r['note']): ?><div class="note"><i class="fa-solid fa-message"></i> <?= e($r['note']) ?></div><?php endif; ?>
          <div class="actions">
            <form method="post" style="display:inline">
              <input type="hidden" name="op" value="handle_request">
              <input type="hidden" name="rid" value="<?= $r['id'] ?>">
              <input type="hidden" name="action" value="approve">
              <button class="btn btn-success" onclick="return confirm('پلن «<?= e($plan_labels[$r['plan_type']]) ?>» فعال شود؟')"><i class="fa-solid fa-check"></i> تأیید و فعال‌سازی</button>
            </form>
            <form method="post" style="display:inline">
              <input type="hidden" name="op" value="handle_request">
              <input type="hidden" name="rid" value="<?= $r['id'] ?>">
              <input type="hidden" name="action" value="reject">
              <button class="btn btn-danger" onclick="return confirm('رد شود؟')"><i class="fa-solid fa-xmark"></i> رد درخواست</button>
            </form>
          </div>
        </div>
        <?php endforeach; ?>
      </div>
      <?php endif; ?>

      <div class="grid">
        <div class="panel">
          <h2><i class="fa-solid fa-sliders"></i> تنظیم پلن سرویس</h2>
          <form method="post">
            <input type="hidden" name="op" value="set_plan">
            <div class="form-group">
              <label>نوع پلن</label>
              <select name="plan" class="form-control" required>
                <option value="permanent" <?= $plan=='permanent'?'selected':'' ?>>دائمی (پیش‌فرض)</option>
                <option value="monthly" <?= $plan=='monthly'?'selected':'' ?>>۱ ماهه (۳۰ روز)</option>
                <option value="quarterly" <?= $plan=='quarterly'?'selected':'' ?>>۳ ماهه (۹۰ روز)</option>
                <option value="semiannual" <?= $plan=='semiannual'?'selected':'' ?>>۶ ماهه (۱۸۰ روز)</option>
                <option value="annual" <?= $plan=='annual'?'selected':'' ?>>سالانه (۳۶۵ روز)</option>
              </select>
            </div>
            <div class="form-group">
              <label>مدت سفارشی (روز) <span style="color:#888;font-size:12px">- اختیاری</span></label>
              <input type="number" name="duration_days" class="form-control" placeholder="در صورت خالی بودن، طبق پلن انتخاب می‌شود" min="0">
            </div>
            <button type="submit" class="btn btn-primary" style="width:100%;padding:12px;justify-content:center"><i class="fa-solid fa-floppy-disk"></i> اعمال پلن</button>
          </form>

          <hr style="margin:18px 0;border:none;border-top:1px dashed #ddd">
          <h4 style="font-size:14px;color:#555;margin-bottom:10px"><i class="fa-solid fa-bolt"></i> عملیات سریع (افزودن روز)</h4>
          <div class="quick-btns">
            <form method="post" style="flex:1"><input type="hidden" name="op" value="extend_days"><input type="hidden" name="days" value="30"><button class="btn btn-success">+۳۰ روز</button></form>
            <form method="post" style="flex:1"><input type="hidden" name="op" value="extend_days"><input type="hidden" name="days" value="90"><button class="btn btn-success">+۹۰ روز</button></form>
            <form method="post" style="flex:1"><input type="hidden" name="op" value="extend_days"><input type="hidden" name="days" value="180"><button class="btn btn-success">+۱۸۰ روز</button></form>
            <form method="post" style="flex:1"><input type="hidden" name="op" value="extend_days"><input type="hidden" name="days" value="365"><button class="btn btn-success">+۳۶۵ روز</button></form>
          </div>
        </div>

        <div class="panel">
          <h2><i class="fa-solid fa-lock"></i> قفل / آزادسازی</h2>
          <p style="color:#666;font-size:13px;margin-bottom:14px;line-height:1.9">
            با قفل کردن سرویس، ادمین فروشگاه فقط می‌تواند به صفحه‌های پشتیبانی، تیکت‌ها و درخواست تمدید دسترسی داشته باشد. سایر بخش‌ها بسته خواهند شد.
          </p>
          <?php if($locked): ?>
            <form method="post" style="margin-bottom:10px">
              <input type="hidden" name="op" value="unlock_service">
              <button class="btn btn-success" style="width:100%;padding:12px;justify-content:center" onclick="return confirm('قفل برداشته شود؟')"><i class="fa-solid fa-lock-open"></i> برداشتن قفل</button>
            </form>
          <?php else: ?>
            <form method="post" style="margin-bottom:10px">
              <input type="hidden" name="op" value="lock_service">
              <button class="btn btn-danger" style="width:100%;padding:12px;justify-content:center" onclick="return confirm('قفل شود؟')"><i class="fa-solid fa-lock"></i> قفل کردن سرویس</button>
            </form>
          <?php endif; ?>
          <form method="post" style="margin-top:10px">
            <input type="hidden" name="op" value="mark_permanent">
            <button class="btn btn-primary" style="width:100%;padding:12px;justify-content:center;background:#2a9d8f" onclick="return confirm('پلن به دائمی تبدیل شود؟')"><i class="fa-solid fa-infinity"></i> تبدیل به دائمی</button>
          </form>
        </div>
      </div>

      <div class="panel">
        <h2><i class="fa-solid fa-clock-rotate-left"></i> تاریخچه درخواست‌ها</h2>
        <?php if(count($all_requests)): ?>
        <div class="table-wrap"><table>
          <thead><tr><th>#</th><th>تاریخ</th><th>پلن</th><th>توضیح</th><th>وضعیت</th><th>پاسخ</th></tr></thead>
          <tbody>
          <?php foreach($all_requests as $r): ?>
            <tr>
              <td><?= $r['id'] ?></td>
              <td style="font-size:12px"><?= e($r['created_at']) ?></td>
              <td><strong><?= e($plan_labels[$r['plan_type']] ?? $r['plan_type']) ?></strong></td>
              <td style="font-size:12px;color:#666;max-width:300px"><?= e($r['note']) ?></td>
              <td><span class="badge" style="background:<?= $r['status']=='approved'?'#2a9d8f':($r['status']=='rejected'?'#e63946':'#f4a261') ?>"><?= $r['status']=='approved'?'تأیید':($r['status']=='rejected'?'رد':'در انتظار') ?></span></td>
              <td style="font-size:11px;color:#999"><?= e($r['handled_at'] ?? '—') ?></td>
            </tr>
          <?php endforeach; ?>
          </tbody>
        </table></div>
        <?php else: ?>
          <p style="color:#999;text-align:center;padding:20px">تاریخچه‌ای وجود ندارد</p>
        <?php endif; ?>
      </div>

    <?php elseif($page === 'contact_info'): ?>
      <!-- ========== اطلاعات تماس (فقط پشتیبان حق ویرایش دارد) ========== -->
      <div class="alert warning">
        <i class="fa-solid fa-circle-info"></i> این اطلاعات در پنل ادمین فروشگاه و در درگاه تمدید نمایش داده می‌شوند. <strong>فقط پشتیبان (شما) می‌توانید آن‌ها را ویرایش کنید.</strong>
      </div>
      <div class="panel">
        <h2><i class="fa-solid fa-address-card"></i> اطلاعات تماس و کارت بانکی</h2>
        <form method="post">
          <input type="hidden" name="op" value="save_contact_info">
          <h3 style="font-size:14px;color:#0f2027;margin-bottom:10px"><i class="fa-solid fa-user"></i> اطلاعات تماس</h3>
          <div class="form-row">
            <div class="form-group"><label>نام پشتیبان</label><input type="text" name="support_name" class="form-control" value="<?= e(setting_v('support_name')) ?>"></div>
            <div class="form-group"><label>شماره تماس</label><input type="text" name="support_phone" class="form-control" value="<?= e(setting_v('support_phone')) ?>" dir="ltr"></div>
          </div>
          <div class="form-row">
            <div class="form-group"><label>آیدی تلگرام</label><input type="text" name="support_telegram" class="form-control" value="<?= e(setting_v('support_telegram')) ?>" dir="ltr" placeholder="@username"></div>
            <div class="form-group"><label>آیدی سروش</label><input type="text" name="support_soroush" class="form-control" value="<?= e(setting_v('support_soroush')) ?>" dir="ltr" placeholder="@username"></div>
          </div>
          <h3 style="font-size:14px;color:#0f2027;margin:18px 0 10px"><i class="fa-solid fa-credit-card"></i> اطلاعات کارت بانکی برای تمدید</h3>
          <div class="form-row">
            <div class="form-group"><label>شماره کارت</label><input type="text" name="support_card_number" class="form-control" value="<?= e(setting_v('support_card_number')) ?>" dir="ltr" placeholder="6037-9912-XXXX-XXXX"></div>
            <div class="form-group"><label>به نام</label><input type="text" name="support_card_holder" class="form-control" value="<?= e(setting_v('support_card_holder')) ?>"></div>
          </div>
          <div class="form-group" style="max-width:50%"><label>بانک</label><input type="text" name="support_bank_name" class="form-control" value="<?= e(setting_v('support_bank_name')) ?>"></div>
          <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> ذخیره تغییرات</button>
        </form>
      </div>

    <?php elseif($page === 'password'): ?>
      <!-- ========== تغییر رمز ========== -->
      <div class="panel">
        <h2><i class="fa-solid fa-key"></i> تغییر رمز پنل پشتیبان</h2>
        <form method="post" style="max-width:400px">
          <input type="hidden" name="op" value="change_support_password">
          <div class="form-group">
            <label>رمز جدید</label>
            <input type="password" name="new_pass" class="form-control" required minlength="4">
          </div>
          <button type="submit" class="btn btn-warning"><i class="fa-solid fa-key"></i> تغییر رمز</button>
        </form>
        <div style="background:#fff8e1;padding:12px;border-radius:10px;margin-top:14px;font-size:12px;color:#7a5d00">
          <i class="fa-solid fa-circle-info"></i> رمز پیش‌فرض پنل پشتیبان: <code>support123</code>. حتماً آن را تغییر دهید.
        </div>
      </div>
    <?php endif; ?>

  </main>
</div>
</body>
</html>
