<?php
/**
 * ============================================================
 *  invoice.php  -  چاپ فاکتور (A4 رسمی + فیش حرارتی)
 *  PHP خالص + SQLite
 * ============================================================
 */
error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE);
ini_set('display_errors', 0);
date_default_timezone_set('Asia/Tehran');
session_start();

define('DB_FILE', __DIR__ . '/shop_data.sqlite');

if (!file_exists(DB_FILE)) { http_response_code(404); echo 'Database not found'; exit; }

$pdo = new PDO('sqlite:' . DB_FILE);
$pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);

// — حداقل احراز هویت: فقط ادمین/مشتری با کد سفارش —
function e($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
function toman($n){ return number_format((int)$n); }
function setting_v($key, $default='') {
    static $cache = null;
    global $pdo;
    if ($cache === null) {
        $cache = [];
        foreach ($pdo->query("SELECT key, value FROM settings")->fetchAll() as $r) {
            $cache[$r['key']] = $r['value'];
        }
    }
    return isset($cache[$key]) ? $cache[$key] : $default;
}

$logged_admin = !empty($_SESSION['admin_logged']);
$id = (int)($_GET['id'] ?? 0);
$type = $_GET['type'] ?? 'a4'; // a4 | thermal
$code = trim($_GET['code'] ?? '');

if ($id > 0) {
    $st = $pdo->prepare("SELECT * FROM orders WHERE id=?");
    $st->execute([$id]);
    $order = $st->fetch();
} elseif ($code !== '') {
    $st = $pdo->prepare("SELECT * FROM orders WHERE order_code=?");
    $st->execute([$code]);
    $order = $st->fetch();
} else { $order = null; }

if (!$order) { http_response_code(404); echo '<div style="font-family:sans-serif;padding:40px;text-align:center">سفارش یافت نشد.</div>'; exit; }

// اجازه چاپ: یا ادمین لاگین است یا کد سفارش با id همخوانی دارد
if (!$logged_admin && $code !== $order['order_code']) {
    http_response_code(403); echo '<div style="font-family:sans-serif;padding:40px;text-align:center">دسترسی غیر مجاز.</div>'; exit;
}

$items = json_decode($order['items'], true) ?: [];
$shop_name = setting_v('shop_name');
$shop_phone = setting_v('shop_phone');
$shop_address = setting_v('shop_address');
$shop_logo = setting_v('site_logo');

// تاریخ شمسی ساده
function fa_date($g_date) {
    $ts = strtotime($g_date);
    if (!$ts) return $g_date;
    // تبدیل ساده میلادی به شمسی
    $gy = (int)date('Y',$ts); $gm = (int)date('m',$ts); $gd = (int)date('d',$ts);
    $g_d_m = [0,31,59,90,120,151,181,212,243,273,304,334];
    $gy2 = ($gm > 2) ? ($gy + 1) : $gy;
    $days = 355666 + (365 * $gy) + ((int)(($gy2 + 3) / 4)) - ((int)(($gy2 + 99) / 100)) + ((int)(($gy2 + 399) / 400)) + $gd + $g_d_m[$gm - 1];
    $jy = -1595 + (33 * ((int)($days / 12053))); $days %= 12053;
    $jy += 4 * ((int)($days / 1461)); $days %= 1461;
    if ($days > 365) { $jy += (int)(($days - 1) / 365); $days = ($days - 1) % 365; }
    if ($days < 186) { $jm = 1 + (int)($days / 31); $jd = 1 + ($days % 31); }
    else { $jm = 7 + (int)(($days - 186) / 30); $jd = 1 + (($days - 186) % 30); }
    return sprintf('%04d/%02d/%02d', $jy, $jm, $jd) . ' ' . date('H:i', $ts);
}

$status_labels = ['pending'=>'در انتظار','confirmed'=>'تأیید شد','preparing'=>'در حال آماده‌سازی','delivering'=>'در حال ارسال','delivered'=>'تحویل شد','cancelled'=>'لغو شد'];
$pay_label = ($order['payment_method']==='voucher') ? setting_v('voucher_payment_label','کالابرگ') : 'نقدی (در محل)';

if ($type === 'thermal') {
    // ============= فیش حرارتی =============
    $width = (int)setting_v('invoice_thermal_width','80');
    $title = setting_v('invoice_thermal_title','فاکتور فروش');
    $header = setting_v('invoice_thermal_header','');
    $footer = setting_v('invoice_thermal_footer','');
    $show_logo = setting_v('invoice_thermal_show_logo','1') === '1';
    $show_barcode = setting_v('invoice_thermal_show_barcode','1') === '1';
    $show_qr = setting_v('invoice_show_tracking_qr','1') === '1';
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<title>فیش - <?= e($order['order_code']) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700&display=swap" rel="stylesheet">
<style>
@page { size: <?= $width ?>mm auto; margin: 0; }
body { font-family: 'Vazirmatn', sans-serif; margin: 0; padding: 6px; width: <?= $width ?>mm; color: #000; font-size: 11px; line-height: 1.5; }
.center { text-align: center; }
.bold { font-weight: 700; }
.divider { border-top: 1px dashed #000; margin: 6px 0; }
.row { display: flex; justify-content: space-between; align-items: flex-start; margin: 2px 0; gap: 6px; }
.row .lbl { color: #444; flex-shrink: 0; }
.row .val { font-weight: 600; text-align: left; word-break: break-word; }
.title { font-size: 14px; font-weight: 800; margin: 4px 0; }
.shop-name { font-size: 13px; font-weight: 700; }
.items-table { width: 100%; border-collapse: collapse; margin-top: 6px; font-size: 10.5px; }
.items-table th { border-bottom: 1px solid #000; padding: 3px 1px; font-weight: 700; }
.items-table td { padding: 3px 1px; vertical-align: top; border-bottom: 1px dotted #999; }
.total-row { font-size: 13px; font-weight: 800; padding: 5px 0; border-top: 2px solid #000; border-bottom: 2px solid #000; margin-top: 4px; }
.logo { max-width: 50%; max-height: 50px; margin: 0 auto 6px; display: block; }
.barcode { font-family: 'Libre Barcode 39', monospace; font-size: 30px; text-align: center; margin: 6px 0 2px; letter-spacing: 1px; direction: ltr; }
.print-btn { position: fixed; top: 10px; left: 10px; background: #2a9d8f; color: #fff; border: none; padding: 8px 16px; border-radius: 8px; cursor: pointer; font-family: inherit; }
@media print { .print-btn, .back-btn { display: none !important; } body { padding: 2mm; } }
.back-btn { position: fixed; top: 10px; right: 10px; background: #6c757d; color: #fff; padding: 8px 14px; border-radius: 8px; text-decoration: none; font-size: 12px; }
</style>
<link href="https://fonts.googleapis.com/css2?family=Libre+Barcode+39&display=swap" rel="stylesheet">
</head>
<body>
<button class="print-btn" onclick="window.print()">🖨 چاپ</button>
<a class="back-btn" href="javascript:window.close();">بستن</a>

<?php if ($show_logo && $shop_logo): ?>
  <img src="<?= e($shop_logo) ?>" class="logo" alt="logo">
<?php endif; ?>

<div class="center shop-name"><?= e($shop_name) ?></div>
<?php if($header): ?><div class="center" style="font-size:10.5px;color:#333;margin-top:3px"><?= e($header) ?></div><?php endif; ?>
<div class="center" style="font-size:10px;color:#444;margin-top:2px">
  <?php if($shop_phone): ?>📞 <span dir="ltr"><?= e($shop_phone) ?></span><?php endif; ?>
  <?php if($shop_address): ?><br>📍 <?= e($shop_address) ?><?php endif; ?>
</div>

<div class="divider"></div>
<div class="title center"><?= e($title) ?></div>
<div class="divider"></div>

<div class="row"><span class="lbl">کد سفارش:</span><span class="val"><?= e($order['order_code']) ?></span></div>
<div class="row"><span class="lbl">تاریخ:</span><span class="val"><?= e(fa_date($order['created_at'])) ?></span></div>
<div class="row"><span class="lbl">مشتری:</span><span class="val"><?= e($order['customer_name']) ?></span></div>
<div class="row"><span class="lbl">تلفن:</span><span class="val" style="direction:ltr"><?= e($order['phone']) ?></span></div>
<?php if($order['address']): ?>
<div class="row"><span class="lbl">آدرس:</span><span class="val" style="font-size:10px"><?= e($order['address']) ?></span></div>
<?php endif; ?>

<table class="items-table">
  <thead>
    <tr>
      <th style="text-align:right;width:50%">شرح</th>
      <th style="width:12%">تعداد</th>
      <th style="text-align:left">قیمت</th>
      <th style="text-align:left">جمع</th>
    </tr>
  </thead>
  <tbody>
    <?php foreach($items as $it): $sub = (int)$it['price']*(int)$it['qty']; ?>
    <tr>
      <td><?= e($it['name']) ?></td>
      <td class="center"><?= (int)$it['qty'] ?></td>
      <td style="text-align:left;font-size:10px"><?= toman($it['price']) ?></td>
      <td style="text-align:left;font-size:10px"><?= toman($sub) ?></td>
    </tr>
    <?php endforeach; ?>
  </tbody>
</table>

<?php if($order['subtotal']>0 && $order['discount_amount']>0): ?>
<div class="row" style="margin-top:6px"><span class="lbl">جمع جزء:</span><span class="val"><?= toman($order['subtotal']) ?> تومان</span></div>
<div class="row"><span class="lbl">تخفیف:</span><span class="val" style="color:#c0392b">-<?= toman($order['discount_amount']) ?> تومان</span></div>
<?php endif; ?>
<?php if(!empty($order['delivery_fee']) && $order['delivery_fee']>0): ?>
<div class="row"><span class="lbl">هزینه ارسال:</span><span class="val"><?= toman($order['delivery_fee']) ?> تومان</span></div>
<?php endif; ?>

<div class="row total-row">
  <span>مبلغ قابل پرداخت:</span>
  <span><?= toman($order['total']) ?> تومان</span>
</div>

<div class="row" style="margin-top:6px"><span class="lbl">نوع پرداخت:</span><span class="val"><?= e($pay_label) ?></span></div>
<div class="row"><span class="lbl">وضعیت:</span><span class="val"><?= e($status_labels[$order['status']]??$order['status']) ?></span></div>

<?php if($show_barcode): ?>
<div class="barcode">*<?= e($order['order_code']) ?>*</div>
<div class="center" style="font-size:10px;letter-spacing:2px;direction:ltr"><?= e($order['order_code']) ?></div>
<?php endif; ?>

<?php if($show_qr):
  $track_url = (isset($_SERVER['HTTPS'])&&$_SERVER['HTTPS']!=='off'?'https':'http').'://'.$_SERVER['HTTP_HOST'].dirname($_SERVER['PHP_SELF']).'/track.php?code='.urlencode($order['order_code']);
?>
<div class="center" style="margin-top:8px">
  <img src="https://api.qrserver.com/v1/create-qr-code/?size=120x120&data=<?= urlencode($track_url) ?>" alt="QR" style="width:80px;height:80px">
  <div style="font-size:9px;color:#555;margin-top:2px">پیگیری آنلاین سفارش</div>
</div>
<?php endif; ?>

<div class="divider"></div>
<?php if($footer): ?>
<div class="center" style="font-size:10.5px;font-weight:600;margin-top:4px"><?= e($footer) ?></div>
<?php endif; ?>
<div class="center" style="font-size:9px;color:#555;margin-top:6px">
  چاپ: <?= date('Y/m/d H:i') ?>
</div>

<script>
// چاپ خودکار اختیاری
window.addEventListener('load', function(){
  if (!window.location.hash.includes('noprint')) {
    setTimeout(()=>window.print(), 500);
  }
});
</script>
</body>
</html>
<?php
} else {
    // ============= فاکتور A4 رسمی =============
    $title = setting_v('invoice_a4_title','فاکتور فروش');
    $footer_text = setting_v('invoice_a4_footer','');
    $notes = setting_v('invoice_a4_notes','');
    $seal_text = setting_v('invoice_a4_seal_text','مهر و امضاء فروشنده');
    $primary = setting_v('invoice_a4_primary_color','#1d3557');
    $show_logo = setting_v('invoice_a4_show_logo','1') === '1';
    $show_sig = setting_v('invoice_a4_show_signature','1') === '1';
    $show_barcode = setting_v('invoice_a4_show_barcode','1') === '1';
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<title>فاکتور <?= e($order['order_code']) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700;800&display=swap" rel="stylesheet">
<link href="https://fonts.googleapis.com/css2?family=Libre+Barcode+39&display=swap" rel="stylesheet">
<style>
@page { size: A4; margin: 12mm; }
* { box-sizing: border-box; margin: 0; padding: 0; }
body { font-family: 'Vazirmatn', sans-serif; color: #222; background: #f0f2f5; padding: 20px; line-height: 1.7; }
.toolbar { max-width: 800px; margin: 0 auto 18px; display: flex; gap: 10px; justify-content: center; }
.btn { background: <?= $primary ?>; color: #fff; border: none; padding: 10px 22px; border-radius: 10px; cursor: pointer; font-family: inherit; font-weight: 600; font-size: 14px; text-decoration: none; display: inline-flex; align-items: center; gap: 6px; }
.btn.sec { background: #6c757d; }
.invoice { max-width: 800px; margin: 0 auto; background: #fff; padding: 28px 34px; box-shadow: 0 8px 30px rgba(0,0,0,.08); border-radius: 6px; min-height: 270mm; position: relative; }
.invoice-header { display: flex; justify-content: space-between; align-items: flex-start; padding-bottom: 18px; border-bottom: 3px solid <?= $primary ?>; }
.invoice-header .logo-area { display: flex; align-items: center; gap: 14px; }
.invoice-header .logo-area img { max-width: 80px; max-height: 80px; }
.invoice-header .shop-info h1 { font-size: 22px; color: <?= $primary ?>; margin-bottom: 4px; }
.invoice-header .shop-info p { font-size: 12px; color: #555; margin: 2px 0; }
.invoice-meta { text-align: left; }
.invoice-meta .title-tag { display: inline-block; background: <?= $primary ?>; color: #fff; padding: 8px 22px; border-radius: 8px; font-size: 18px; font-weight: 700; margin-bottom: 10px; }
.invoice-meta .meta-row { font-size: 12px; margin: 3px 0; }
.invoice-meta .meta-row span { color: #888; }
.invoice-meta .meta-row strong { color: #222; margin-right: 6px; }
.customer-box { display: grid; grid-template-columns: 1fr 1fr; gap: 14px; margin: 20px 0; }
.box { background: #f8f9fa; border-right: 4px solid <?= $primary ?>; padding: 12px 16px; border-radius: 6px; }
.box h3 { font-size: 13px; color: <?= $primary ?>; margin-bottom: 6px; font-weight: 700; }
.box p { font-size: 13px; margin: 3px 0; }
.box .lbl { color: #777; display: inline-block; min-width: 60px; }
.items-table { width: 100%; border-collapse: collapse; margin: 14px 0; font-size: 13px; }
.items-table thead { background: <?= $primary ?>; color: #fff; }
.items-table th { padding: 10px 8px; text-align: center; font-weight: 600; }
.items-table td { padding: 9px 8px; text-align: center; border-bottom: 1px solid #eee; }
.items-table tr:nth-child(even) td { background: #f8f9fa; }
.items-table .name { text-align: right; font-weight: 500; }
.totals { margin-top: 14px; display: flex; justify-content: flex-start; }
.totals table { min-width: 320px; font-size: 13px; }
.totals td { padding: 6px 12px; }
.totals tr.grand td { background: <?= $primary ?>; color: #fff; font-weight: 700; font-size: 16px; padding: 12px; border-radius: 4px; }
.totals .lbl { color: #555; }
.totals .val { font-weight: 700; text-align: left; min-width: 130px; }
.notes-box { background: #fff8e1; border: 1px dashed #c7a800; padding: 12px 16px; border-radius: 6px; margin: 16px 0; font-size: 12.5px; color: #5d4500; }
.signature-box { display: grid; grid-template-columns: 1fr 1fr; gap: 30px; margin-top: 38px; }
.sig-area { text-align: center; padding-top: 14px; border-top: 1px dashed #aaa; font-size: 12px; color: #555; min-height: 80px; }
.sig-area .lbl { display: block; margin-bottom: 60px; color: #888; font-size: 11px; }
.invoice-footer { margin-top: 30px; padding-top: 14px; border-top: 2px dashed #ddd; text-align: center; color: #777; font-size: 11.5px; }
.barcode { font-family: 'Libre Barcode 39', monospace; font-size: 38px; text-align: center; margin: 4px 0; letter-spacing: 1px; direction: ltr; }
.status-tag { display: inline-block; padding: 3px 10px; border-radius: 14px; font-size: 11px; font-weight: 600; }
.watermark { position: absolute; top: 50%; left: 50%; transform: translate(-50%, -50%) rotate(-35deg); font-size: 100px; color: rgba(0,0,0,.04); font-weight: 800; pointer-events: none; z-index: 0; }
.invoice > * { position: relative; z-index: 1; }
@media print {
  body { background: #fff; padding: 0; }
  .toolbar { display: none !important; }
  .invoice { box-shadow: none; max-width: 100%; padding: 0; border-radius: 0; }
}
</style>
</head>
<body>
<div class="toolbar">
  <button class="btn" onclick="window.print()">🖨 چاپ فاکتور</button>
  <a class="btn sec" href="invoice.php?id=<?= $order['id'] ?>&type=thermal" target="_blank">📃 چاپ فیش حرارتی</a>
  <a class="btn sec" href="javascript:window.close();">بستن</a>
</div>

<div class="invoice">
  <div class="watermark"><?= e($shop_name) ?></div>

  <div class="invoice-header">
    <div class="logo-area">
      <?php if($show_logo && $shop_logo): ?>
        <img src="<?= e($shop_logo) ?>" alt="logo">
      <?php endif; ?>
      <div class="shop-info">
        <h1><?= e($shop_name) ?></h1>
        <p>📞 <span dir="ltr"><?= e($shop_phone) ?></span></p>
        <p>📍 <?= e($shop_address) ?></p>
      </div>
    </div>
    <div class="invoice-meta">
      <div class="title-tag"><?= e($title) ?></div>
      <div class="meta-row"><span>شماره فاکتور:</span><strong><?= e($order['order_code']) ?></strong></div>
      <div class="meta-row"><span>تاریخ صدور:</span><strong><?= e(fa_date($order['created_at'])) ?></strong></div>
      <div class="meta-row"><span>وضعیت:</span><strong class="status-tag" style="background:<?= $order['is_paid']?'#d4edda':'#fff3cd' ?>;color:<?= $order['is_paid']?'#155724':'#856404' ?>"><?= $order['is_paid']?'پرداخت شده':'در انتظار پرداخت' ?></strong></div>
    </div>
  </div>

  <div class="customer-box">
    <div class="box">
      <h3>🧑 مشخصات خریدار</h3>
      <p><span class="lbl">نام:</span> <strong><?= e($order['customer_name']) ?></strong></p>
      <p><span class="lbl">تلفن:</span> <span dir="ltr"><?= e($order['phone']) ?></span></p>
      <?php if(!empty($order['city'])): ?><p><span class="lbl">شهر:</span> <?= e($order['city']) ?></p><?php endif; ?>
      <p><span class="lbl">آدرس:</span> <?= e($order['address']) ?></p>
    </div>
    <div class="box">
      <h3>💳 اطلاعات پرداخت</h3>
      <p><span class="lbl">نوع پرداخت:</span> <strong><?= e($pay_label) ?></strong></p>
      <p><span class="lbl">وضعیت سفارش:</span> <strong><?= e($status_labels[$order['status']]??$order['status']) ?></strong></p>
      <?php if(!empty($order['discount_code'])): ?><p><span class="lbl">کد تخفیف:</span> <strong style="color:#9b59b6"><?= e($order['discount_code']) ?></strong></p><?php endif; ?>
      <?php if(!empty($order['voucher_code'])): ?><p><span class="lbl">کالابرگ:</span> <strong style="color:#e67e22"><?= e($order['voucher_code']) ?></strong></p><?php endif; ?>
    </div>
  </div>

  <table class="items-table">
    <thead>
      <tr>
        <th style="width:6%">#</th>
        <th>شرح کالا</th>
        <th style="width:12%">تعداد</th>
        <th style="width:18%">قیمت واحد</th>
        <th style="width:18%">مبلغ کل</th>
      </tr>
    </thead>
    <tbody>
      <?php $i=1; $sum_qty=0; foreach($items as $it): $sub=(int)$it['price']*(int)$it['qty']; $sum_qty+=(int)$it['qty']; ?>
      <tr>
        <td><?= $i++ ?></td>
        <td class="name"><?= e($it['name']) ?></td>
        <td><?= (int)$it['qty'] ?></td>
        <td><?= toman($it['price']) ?></td>
        <td><strong><?= toman($sub) ?></strong></td>
      </tr>
      <?php endforeach; ?>
    </tbody>
    <tfoot>
      <tr style="background:#f0f0f0;font-weight:700">
        <td colspan="2" style="text-align:left;padding-left:14px">جمع کل تعداد:</td>
        <td><?= $sum_qty ?></td>
        <td colspan="2" style="text-align:left;padding-left:14px">جمع کل اقلام: <?= count($items) ?> قلم</td>
      </tr>
    </tfoot>
  </table>

  <div class="totals">
    <table>
      <?php if($order['subtotal']>0): ?>
      <tr>
        <td class="lbl">جمع جزء:</td>
        <td class="val"><?= toman($order['subtotal']) ?> تومان</td>
      </tr>
      <?php endif; ?>
      <?php if($order['discount_amount']>0): ?>
      <tr>
        <td class="lbl">تخفیف:</td>
        <td class="val" style="color:#c0392b">- <?= toman($order['discount_amount']) ?> تومان</td>
      </tr>
      <?php endif; ?>
      <?php if(!empty($order['delivery_fee']) && $order['delivery_fee']>0): ?>
      <tr>
        <td class="lbl">هزینه ارسال:</td>
        <td class="val"><?= toman($order['delivery_fee']) ?> تومان</td>
      </tr>
      <?php endif; ?>
      <tr class="grand">
        <td>مبلغ قابل پرداخت:</td>
        <td style="text-align:left"><?= toman($order['total']) ?> تومان</td>
      </tr>
    </table>
  </div>

  <?php if($notes): ?>
  <div class="notes-box">
    <strong>📝 توضیحات:</strong> <?= e($notes) ?>
  </div>
  <?php endif; ?>

  <?php if($show_sig): ?>
  <div class="signature-box">
    <div class="sig-area">
      <span class="lbl">امضاء خریدار</span>
    </div>
    <div class="sig-area">
      <span class="lbl"><?= e($seal_text) ?></span>
    </div>
  </div>
  <?php endif; ?>

  <?php if($show_barcode): ?>
  <div style="text-align:center;margin-top:20px">
    <div class="barcode">*<?= e($order['order_code']) ?>*</div>
    <div style="font-size:11px;color:#666;letter-spacing:2px;direction:ltr"><?= e($order['order_code']) ?></div>
  </div>
  <?php endif; ?>

  <div class="invoice-footer">
    <?php if($footer_text): ?>
      <p style="margin-bottom:6px"><?= e($footer_text) ?></p>
    <?php endif; ?>
    <p>تاریخ چاپ: <?= date('Y/m/d H:i') ?> | این فاکتور به صورت سیستمی توسط <?= e($shop_name) ?> صادر شده است.</p>
  </div>
</div>

<script>
window.addEventListener('load', function(){
  if (!window.location.hash.includes('noprint')) {
    setTimeout(()=>window.print(), 700);
  }
});
</script>
</body>
</html>
<?php } ?>
