<?php
/**
 * ============================================================
 *  پنل مدیریت فروشگاه  -  admin.php
 *  فروشگاه + انبار چندگانه + حسابداری + آرشیو
 *  تخفیف + کالابرگ + کد تخفیف + تب سفارشی + سفارشی‌سازی
 * ============================================================
 */

error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE);
ini_set('display_errors', 0);
date_default_timezone_set('Asia/Tehran');
session_start();

define('DB_FILE', __DIR__ . '/shop_data.sqlite');
define('UPLOAD_DIR', __DIR__ . '/uploads');
if (!is_dir(UPLOAD_DIR)) @mkdir(UPLOAD_DIR, 0755, true);

// =====================================================
//  دیتابیس
// =====================================================
function db() {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO('sqlite:' . DB_FILE);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
        $pdo->exec('PRAGMA foreign_keys = ON;');
        init_db($pdo);
    }
    return $pdo;
}

function init_db($pdo) {
    $pdo->exec("CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT)");
    $pdo->exec("CREATE TABLE IF NOT EXISTS categories (id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, sort_order INTEGER DEFAULT 0)");
    $pdo->exec("CREATE TABLE IF NOT EXISTS products (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL, description TEXT,
        price INTEGER NOT NULL DEFAULT 0,
        discount_price INTEGER DEFAULT 0,
        discount_percent INTEGER DEFAULT 0,
        cost_price INTEGER DEFAULT 0,
        image TEXT, category_id INTEGER,
        stock INTEGER DEFAULT 0,
        min_stock INTEGER DEFAULT 5,
        is_featured INTEGER DEFAULT 0,
        is_active INTEGER DEFAULT 1,
        created_at TEXT
    )");
    $pdo->exec("CREATE TABLE IF NOT EXISTS orders (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        order_code TEXT, customer_name TEXT NOT NULL, phone TEXT NOT NULL,
        address TEXT NOT NULL, city TEXT DEFAULT '', note TEXT,
        total INTEGER NOT NULL DEFAULT 0,
        subtotal INTEGER DEFAULT 0, discount_amount INTEGER DEFAULT 0,
        cost_total INTEGER DEFAULT 0, profit INTEGER DEFAULT 0,
        items TEXT, status TEXT DEFAULT 'pending',
        payment_method TEXT DEFAULT 'cod', voucher_code TEXT,
        discount_code TEXT, is_paid INTEGER DEFAULT 0,
        is_archived INTEGER DEFAULT 0, closed_at TEXT, created_at TEXT
    )");
    $pdo->exec("CREATE TABLE IF NOT EXISTS warehouses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        name TEXT NOT NULL, is_main INTEGER DEFAULT 0,
        is_active INTEGER DEFAULT 1, sort_order INTEGER DEFAULT 0,
        note TEXT, created_at TEXT
    )");
    $pdo->exec("CREATE TABLE IF NOT EXISTS stock (
        product_id INTEGER NOT NULL, warehouse_id INTEGER NOT NULL,
        quantity INTEGER DEFAULT 0,
        PRIMARY KEY (product_id, warehouse_id)
    )");
    $pdo->exec("CREATE TABLE IF NOT EXISTS stock_movements (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER NOT NULL, warehouse_id INTEGER NOT NULL,
        from_warehouse_id INTEGER, to_warehouse_id INTEGER,
        type TEXT NOT NULL, quantity INTEGER NOT NULL,
        unit_price INTEGER DEFAULT 0, ref_id INTEGER,
        note TEXT, created_at TEXT
    )");
    $pdo->exec("CREATE TABLE IF NOT EXISTS expenses (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL, amount INTEGER NOT NULL,
        category TEXT, expense_date TEXT, note TEXT, created_at TEXT
    )");
    $pdo->exec("CREATE TABLE IF NOT EXISTS flash_sales (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        product_id INTEGER NOT NULL,
        discount_percent INTEGER DEFAULT 0,
        discount_price INTEGER DEFAULT 0,
        starts_at TEXT NOT NULL, ends_at TEXT NOT NULL,
        is_active INTEGER DEFAULT 1, created_at TEXT
    )");
    $pdo->exec("CREATE TABLE IF NOT EXISTS discount_codes (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code TEXT UNIQUE NOT NULL, type TEXT NOT NULL,
        value INTEGER NOT NULL, min_order INTEGER DEFAULT 0,
        max_uses INTEGER DEFAULT 0, current_uses INTEGER DEFAULT 0,
        max_per_customer INTEGER DEFAULT 0,
        starts_at TEXT, ends_at TEXT,
        applies_to TEXT DEFAULT 'all',
        category_id INTEGER, product_id INTEGER,
        first_order_only INTEGER DEFAULT 0,
        is_active INTEGER DEFAULT 1, created_at TEXT
    )");
    $pdo->exec("CREATE TABLE IF NOT EXISTS discount_code_usage (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        code_id INTEGER NOT NULL, order_id INTEGER,
        customer_phone TEXT, discount_amount INTEGER DEFAULT 0,
        used_at TEXT
    )");
    $pdo->exec("CREATE TABLE IF NOT EXISTS custom_tabs (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        title TEXT NOT NULL, tab_type TEXT NOT NULL,
        filter_data TEXT, sort_order INTEGER DEFAULT 0,
        is_active INTEGER DEFAULT 1, icon TEXT, created_at TEXT
    )");

    $cols = $pdo->query("PRAGMA table_info(products)")->fetchAll(PDO::FETCH_COLUMN, 1);
    $int_cols = ['stock','is_featured','is_active','discount_price','cost_price','discount_percent','min_stock'];
    $text_cols = ['barcode','sku'];
    foreach ($int_cols as $c) {
        if (!in_array($c, $cols)) {
            $def = '0';
            if ($c === 'min_stock') $def = '5';
            $pdo->exec("ALTER TABLE products ADD COLUMN $c INTEGER DEFAULT $def");
        }
    }
    foreach ($text_cols as $c) {
        if (!in_array($c, $cols)) {
            $pdo->exec("ALTER TABLE products ADD COLUMN $c TEXT DEFAULT ''");
        }
    }
    $oc = $pdo->query("PRAGMA table_info(orders)")->fetchAll(PDO::FETCH_COLUMN, 1);
    foreach (['is_paid','payment_method','city','cost_total','profit','is_archived','closed_at','subtotal','discount_amount','voucher_code','discount_code'] as $c) {
        if (!in_array($c, $oc)) {
            $def = ($c === 'is_archived' || $c === 'is_paid' || $c === 'cost_total' || $c === 'profit' || $c === 'subtotal' || $c === 'discount_amount') ? '0' : '';
            $pdo->exec("ALTER TABLE orders ADD COLUMN $c $def");
        }
    }

    $defaults = [
        'shop_name'=>'فروشگاه تربت','shop_slogan'=>'خرید آنلاین، تحویل درب منزل',
        'shop_phone'=>'051-00000000','shop_address'=>'تربت حیدریه، خیابان اصلی',
        'shop_about'=>'ما بهترین کالاها را با قیمت مناسب و تحویل درب منزل ارائه می‌دهیم.',
        'shop_instagram'=>'','shop_telegram'=>'','admin_password'=>'admin123',
        'delivery_fee'=>'0','min_order'=>'0','primary_color'=>'#e63946','allowed_city'=>'تربت حیدریه',
        'site_logo'=>'','site_bg_image'=>'','site_bg_text_color'=>'#ffffff','site_bg_overlay'=>'0.4',
        'hero_title'=>'','hero_subtitle'=>'','hero_badge_text'=>'پرداخت درب منزل (نقدی هنگام تحویل)',
        'voucher_payment_label'=>'کالابرگ','voucher_payment_enabled'=>'1',
        'show_voucher_payment'=>'1','show_cod_payment'=>'1',
        'btn_cart_label'=>'سبد خرید','btn_add_to_cart_label'=>'افزودن به سبد',
        'btn_checkout_label'=>'ادامه و ثبت سفارش','btn_continue_label'=>'بازگشت به فروشگاه',
        'btn_phone_label'=>'تماس','btn_address_label'=>'آدرس','btn_search_label'=>'جستجوی محصول...',
        'btn_empty_cart_label'=>'سبد خرید شما خالی است',
        'discount_code_label'=>'کد تخفیف دارید؟','voucher_label'=>'کالابرگ دارید؟',
    ];
    $st = $pdo->prepare("INSERT OR IGNORE INTO settings (key,value) VALUES (?,?)");
    foreach ($defaults as $k=>$v) $st->execute([$k,$v]);

    $whc = $pdo->query("SELECT COUNT(*) c FROM warehouses")->fetch()['c'];
    if ($whc == 0) {
        $now = date('Y-m-d H:i:s');
        $pdo->prepare("INSERT INTO warehouses (name,is_main,sort_order,created_at) VALUES (?,1,1,?)")->execute(['انبار اصلی',$now]);
        $pdo->prepare("INSERT INTO warehouses (name,is_main,sort_order,created_at) VALUES (?,0,2,?)")->execute(['انبار ۲',$now]);
    }

    // ======= جدول درخواست تمدید =======
    $pdo->exec("CREATE TABLE IF NOT EXISTS renewal_requests (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        plan_type TEXT NOT NULL,
        note TEXT,
        status TEXT DEFAULT 'pending',
        created_at TEXT,
        handled_at TEXT
    )");

    // ======= جدول تیکت‌ها =======
    $pdo->exec("CREATE TABLE IF NOT EXISTS support_tickets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        subject TEXT NOT NULL,
        status TEXT DEFAULT 'open',
        priority TEXT DEFAULT 'normal',
        last_reply_by TEXT DEFAULT 'admin',
        created_at TEXT,
        updated_at TEXT
    )");
    $pdo->exec("CREATE TABLE IF NOT EXISTS ticket_messages (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        ticket_id INTEGER NOT NULL,
        sender TEXT NOT NULL,
        message TEXT NOT NULL,
        is_read_by_admin INTEGER DEFAULT 0,
        is_read_by_support INTEGER DEFAULT 0,
        created_at TEXT,
        FOREIGN KEY(ticket_id) REFERENCES support_tickets(id) ON DELETE CASCADE
    )");

    // ======= تنظیمات جدید =======
    $extra_defaults = [
        // پشتیبانی
        'support_name'=>'اسماعیل‌زاده',
        'support_phone'=>'09964349480',
        'support_telegram'=>'@SirBNL',
        'support_soroush'=>'@AreYou',
        'support_card_number'=>'6037-9912-3456-7890',
        'support_card_holder'=>'اسماعیل‌زاده',
        'support_bank_name'=>'بانک ملی',
        // اشتراک / لایسنس
        'license_plan'=>'permanent', // permanent | monthly | quarterly | semiannual | annual
        'license_start'=>'',
        'license_expires'=>'',
        'license_locked'=>'0',
        'license_last_check'=>'',
        // رمز پنل پشتیبان
        'support_password'=>'support123',
        // تنظیمات چاپ فاکتور
        'invoice_a4_title'=>'فاکتور فروش',
        'invoice_a4_show_logo'=>'1',
        'invoice_a4_footer'=>'از خرید شما سپاسگزاریم. در صورت وجود هر گونه ایراد در کالا، لطفاً تا ۲۴ ساعت اطلاع دهید.',
        'invoice_a4_notes'=>'این فاکتور به عنوان سند رسمی فروش صادر شده است.',
        'invoice_a4_seal_text'=>'مهر و امضاء فروشنده',
        'invoice_a4_show_signature'=>'1',
        'invoice_a4_primary_color'=>'#1d3557',
        'invoice_a4_show_barcode'=>'1',
        'invoice_thermal_title'=>'فاکتور فروش',
        'invoice_thermal_header'=>'به فروشگاه ما خوش آمدید',
        'invoice_thermal_footer'=>'مرسی از خرید شما',
        'invoice_thermal_width'=>'80', // mm (58 یا 80)
        'invoice_thermal_show_logo'=>'1',
        'invoice_thermal_show_barcode'=>'1',
        'invoice_show_tracking_qr'=>'1',
    ];
    foreach ($extra_defaults as $k=>$v) $st->execute([$k,$v]);

    // مقداردهی اولیه پلان دائمی و تاریخ شروع
    $lic_start_row = $pdo->query("SELECT value FROM settings WHERE key='license_start'")->fetch();
    if (!$lic_start_row || $lic_start_row['value']==='') {
        $pdo->prepare("UPDATE settings SET value=? WHERE key='license_start'")->execute([date('Y-m-d H:i:s')]);
    }

    $main = main_warehouse_id();
    $prods = $pdo->query("SELECT id, stock FROM products")->fetchAll();
    $chk = $pdo->prepare("SELECT COUNT(*) c FROM stock WHERE product_id=?");
    $ins = $pdo->prepare("INSERT INTO stock (product_id,warehouse_id,quantity) VALUES (?,?,?)");
    foreach ($prods as $p) {
        $chk->execute([$p['id']]);
        if ($chk->fetch()['c'] == 0 && $p['stock'] > 0) {
            $ins->execute([$p['id'], $main, $p['stock']]);
        }
    }
}

function setting($key, $default='') {
    static $cache = null;
    if ($cache === null) {
        $cache = [];
        foreach (db()->query("SELECT key, value FROM settings")->fetchAll() as $r) {
            $cache[$r['key']] = $r['value'];
        }
    }
    return isset($cache[$key]) ? $cache[$key] : $default;
}
function save_setting($key, $value) {
    $st = db()->prepare("INSERT INTO settings (key,value) VALUES (?,?) ON CONFLICT(key) DO UPDATE SET value=?");
    $st->execute([$key, $value, $value]);
}
function e($s){ return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
function toman($n){ return number_format((int)$n); }
function main_warehouse_id() {
    static $id = null;
    if ($id === null) {
        $r = db()->query("SELECT id FROM warehouses WHERE is_main=1 ORDER BY id ASC LIMIT 1")->fetch();
        $id = $r ? (int)$r['id'] : 1;
    }
    return $id;
}
function get_stock($product_id, $warehouse_id = null) {
    if ($warehouse_id === null) $warehouse_id = main_warehouse_id();
    $st = db()->prepare("SELECT quantity FROM stock WHERE product_id=? AND warehouse_id=?");
    $st->execute([$product_id, $warehouse_id]);
    $r = $st->fetch();
    return $r ? (int)$r['quantity'] : 0;
}

// =====================================================
//  سیستم لایسنس / اشتراک
// =====================================================
function license_info() {
    static $cache = null;
    if ($cache !== null) return $cache;
    $plan = setting('license_plan','permanent');
    $expires = setting('license_expires','');
    $locked = setting('license_locked','0') === '1';
    $days_left = null;
    $is_expired = false;
    if ($plan !== 'permanent') {
        if ($expires) {
            $ts = strtotime($expires);
            $now = time();
            $days_left = (int)ceil(($ts - $now) / 86400);
            if ($ts < $now) $is_expired = true;
        } else {
            $is_expired = true;
            $days_left = 0;
        }
    }
    $plan_labels = [
        'permanent'=>'دائمی',
        'monthly'=>'۱ ماهه',
        'quarterly'=>'۳ ماهه',
        'semiannual'=>'۶ ماهه',
        'annual'=>'۱۲ ماهه (سالانه)'
    ];
    $cache = [
        'plan'=>$plan,
        'plan_label'=>$plan_labels[$plan] ?? $plan,
        'expires'=>$expires,
        'is_locked'=>$locked,
        'is_expired'=>$is_expired,
        'days_left'=>$days_left,
        'is_permanent'=>$plan==='permanent'
    ];
    return $cache;
}

function plan_to_days($plan) {
    return [
        'monthly'=>30,'quarterly'=>90,'semiannual'=>180,'annual'=>365,'permanent'=>0
    ][$plan] ?? 0;
}

function enforce_license_lock() {
    $lic = license_info();
    // اگر دائمی بود همیشه آزاد
    if ($lic['is_permanent']) return;
    // اگر توسط پشتیبان قفل شده یا منقضی شده
    if ($lic['is_locked'] || $lic['is_expired']) {
        // اجازه دسترسی فقط به صفحات پشتیبانی، تیکت و تمدید
        $allowed = ['renew','support','ticket_new','ticket_view','subscription'];
        $cur = $_GET['page'] ?? 'dashboard';
        if (!in_array($cur, $allowed)) {
            header('Location: admin.php?page=renew');
            exit;
        }
    }
}

// =====================================================
//  احراز هویت
// =====================================================
$msg = ''; $msg_type = 'success';
if (isset($_GET['logout'])) { unset($_SESSION['admin_logged']); header('Location: admin.php'); exit; }
if (isset($_POST['login_password'])) {
    if ($_POST['login_password'] === setting('admin_password')) {
        $_SESSION['admin_logged'] = true;
        header('Location: admin.php'); exit;
    } else { $login_error = 'رمز عبور اشتباه است!'; }
}
$logged = !empty($_SESSION['admin_logged']);

if (!$logged) {
    ?>
    <!DOCTYPE html><html lang="fa" dir="rtl"><head>
    <meta charset="UTF-8"><meta name="viewport" content="width=device-width,initial-scale=1">
    <title>ورود به پنل مدیریت</title>
    <link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css">
    <style>
    *{margin:0;padding:0;box-sizing:border-box;font-family:'Vazirmatn',sans-serif;}
    body{background:linear-gradient(135deg,#1d3557,#457b9d);min-height:100vh;display:flex;align-items:center;justify-content:center;padding:16px;}
    .login-card{background:#fff;border-radius:20px;padding:42px 34px;width:100%;max-width:400px;box-shadow:0 20px 50px rgba(0,0,0,.3);text-align:center;}
    .login-card .ic{width:80px;height:80px;border-radius:50%;background:#e63946;color:#fff;font-size:36px;display:flex;align-items:center;justify-content:center;margin:0 auto 20px;}
    .login-card h1{font-size:22px;margin-bottom:6px;}
    .login-card p{color:#888;font-size:14px;margin-bottom:24px;}
    .login-card input{width:100%;padding:14px;border:2px solid #eee;border-radius:12px;font-size:16px;outline:none;text-align:center;font-family:inherit;margin-bottom:16px;}
    .login-card input:focus{border-color:#e63946;}
    .login-card button{width:100%;background:#e63946;color:#fff;padding:14px;border-radius:12px;font-size:16px;font-weight:700;border:none;cursor:pointer;}
    .err{background:#fde8e8;color:#c0392b;padding:10px;border-radius:10px;font-size:14px;margin-bottom:16px;}
    .back{display:block;margin-top:18px;color:#888;font-size:13px;text-decoration:none;}
    </style></head><body>
    <form class="login-card" method="post">
      <div class="ic"><i class="fa-solid fa-lock"></i></div>
      <h1>پنل مدیریت</h1>
      <p><?= e(setting('shop_name')) ?></p>
      <?php if(!empty($login_error)): ?><div class="err"><i class="fa-solid fa-circle-exclamation"></i> <?= e($login_error) ?></div><?php endif; ?>
      <input type="password" name="login_password" placeholder="رمز عبور" required autofocus>
      <button type="submit"><i class="fa-solid fa-right-to-bracket"></i> ورود</button>
      <a class="back" href="index.php"><i class="fa-solid fa-arrow-right"></i> بازگشت به فروشگاه</a>
    </form>
    </body></html>
    <?php exit;
}

// =====================================================
//  پردازش عملیات
// =====================================================
$pdo = db();
$op = $_POST['op'] ?? ($_GET['op'] ?? '');
$now = date('Y-m-d H:i:s');

function handle_upload($field, $prefix = 'file') {
    if (!empty($_FILES[$field]['name']) && $_FILES[$field]['error'] === UPLOAD_ERR_OK) {
        $ext = strtolower(pathinfo($_FILES[$field]['name'], PATHINFO_EXTENSION));
        if (in_array($ext, ['jpg','jpeg','png','gif','webp','svg'])) {
            $name = $prefix . '_' . time() . '_' . rand(1000,9999) . '.' . $ext;
            $dest = UPLOAD_DIR . '/' . $name;
            if (move_uploaded_file($_FILES[$field]['tmp_name'], $dest)) {
                return 'uploads/' . $name;
            }
        }
    }
    return null;
}

// --- محصول ---
if ($op === 'save_product') {
    $id = (int)($_POST['id'] ?? 0);
    $name = trim($_POST['name'] ?? '');
    $desc = trim($_POST['description'] ?? '');
    $price = (int)($_POST['price'] ?? 0);
    $discount_price = (int)($_POST['discount_price'] ?? 0);
    $discount_percent = (int)($_POST['discount_percent'] ?? 0);
    $cost_price = (int)($_POST['cost_price'] ?? 0);
    $cat = (int)($_POST['category_id'] ?? 0) ?: null;
    $stock = (int)($_POST['stock'] ?? 0);
    $min_stock = (int)($_POST['min_stock'] ?? 5);
    $featured = isset($_POST['is_featured']) ? 1 : 0;
    $active = isset($_POST['is_active']) ? 1 : 0;
        $img_url = trim($_POST['image_url'] ?? '');
        $uploaded = handle_upload('image_file', 'p');
        $image = $uploaded ?: ($img_url ?: ($_POST['existing_image'] ?? ''));
        $barcode = trim($_POST['barcode'] ?? '');
        $sku = trim($_POST['sku'] ?? '');
    if ($name === '' || $price <= 0) {
        $msg = 'نام محصول و قیمت فروش الزامی است.'; $msg_type='error';
    } else {
        if ($discount_percent > 0 && $discount_percent < 100 && $discount_price <= 0) {
            $discount_price = (int)round($price * (1 - $discount_percent / 100));
        }
        $main_wh = main_warehouse_id();
        try {
            $pdo->beginTransaction();
            if ($id > 0) {
                $st = $pdo->prepare("UPDATE products SET name=?,description=?,price=?,discount_price=?,discount_percent=?,cost_price=?,image=?,category_id=?,stock=?,min_stock=?,is_featured=?,is_active=?,barcode=?,sku=? WHERE id=?");
                $st->execute([$name,$desc,$price,$discount_price,$discount_percent,$cost_price,$image,$cat,$stock,$min_stock,$featured,$active,$barcode,$sku,$id]);
            } else {
                $st = $pdo->prepare("INSERT INTO products (name,description,price,discount_price,discount_percent,cost_price,image,category_id,stock,min_stock,is_featured,is_active,barcode,sku,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
                $st->execute([$name,$desc,$price,$discount_price,$discount_percent,$cost_price,$image,$cat,$stock,$min_stock,$featured,$active,$barcode,$sku,$now]);
                $id = $pdo->lastInsertId();
            }
            $ex = $pdo->prepare("SELECT quantity FROM stock WHERE product_id=? AND warehouse_id=?");
            $ex->execute([$id, $main_wh]);
            $cur = $ex->fetch();
            if ($cur) $pdo->prepare("UPDATE stock SET quantity=? WHERE product_id=? AND warehouse_id=?")->execute([$stock,$id,$main_wh]);
            else $pdo->prepare("INSERT INTO stock (product_id,warehouse_id,quantity) VALUES (?,?,?)")->execute([$id,$main_wh,$stock]);
            if ($stock > 0) {
                $pdo->prepare("INSERT INTO stock_movements (product_id,warehouse_id,type,quantity,unit_price,note,created_at) VALUES (?,?,?,?,?,?,?)")
                    ->execute([$id, $main_wh, 'adjust', $stock, $cost_price, 'تنظیم اولیه / ویرایش محصول', $now]);
            }
            $pdo->commit();
            $msg = $id ? 'محصول با موفقیت ویرایش شد.' : 'محصول جدید اضافه شد.';
        } catch (Exception $e) {
            if ($pdo->inTransaction()) $pdo->rollBack();
            $msg = 'خطا: ' . $e->getMessage(); $msg_type = 'error';
        }
    }
    $op = '';
}
if ($op === 'delete_product') {
    $id = (int)$_GET['id'];
    $pdo->beginTransaction();
    try {
        $pdo->prepare("DELETE FROM stock WHERE product_id=?")->execute([$id]);
        $pdo->prepare("DELETE FROM stock_movements WHERE product_id=?")->execute([$id]);
        $pdo->prepare("DELETE FROM flash_sales WHERE product_id=?")->execute([$id]);
        $pdo->prepare("DELETE FROM products WHERE id=?")->execute([$id]);
        $pdo->commit();
        $msg = 'محصول و تمام رکوردهای مرتبط حذف شدند.';
    } catch (Exception $e) { $pdo->rollBack(); $msg='خطا: '.$e->getMessage(); $msg_type='error'; }
    $op = '';
}

// --- دسته‌بندی ---
if ($op === 'save_category') {
    $cname = trim($_POST['cat_name'] ?? '');
    $cid = (int)($_POST['cat_id'] ?? 0);
    $sort = (int)($_POST['sort_order'] ?? 0);
    if ($cname !== '') {
        if ($cid > 0) { $pdo->prepare("UPDATE categories SET name=?,sort_order=? WHERE id=?")->execute([$cname,$sort,$cid]); $msg='دسته‌بندی ویرایش شد.'; }
        else { $pdo->prepare("INSERT INTO categories (name,sort_order) VALUES (?,?)")->execute([$cname,$sort]); $msg='دسته‌بندی اضافه شد.'; }
    }
    $op='categories';
}
if ($op === 'delete_category') {
    $id=(int)$_GET['id'];
    $pdo->prepare("DELETE FROM categories WHERE id=?")->execute([$id]);
    $pdo->prepare("UPDATE products SET category_id=NULL WHERE category_id=?")->execute([$id]);
    $msg='دسته‌بندی حذف شد.'; $op='categories';
}

// --- سفارش ---
if ($op === 'order_status') {
    $id=(int)($_POST['id'] ?? $_GET['id'] ?? 0);
    $status = $_POST['status'] ?? $_GET['status'] ?? '';
    $valid_statuses = ['pending','confirmed','preparing','ready','delivered','cancelled'];
    if ($id > 0 && in_array($status, $valid_statuses, true)) {
        $pdo->prepare("UPDATE orders SET status=?, closed_at=CASE WHEN ? IN ('delivered','cancelled') THEN ? ELSE closed_at END WHERE id=?")
            ->execute([$status, $status, $now, $id]);
        $msg='وضعیت سفارش به‌روزرسانی شد.';
    }
    $op = $_GET['page'] ?? 'orders';
}
if ($op === 'confirm_payment') {
    $id=(int)$_GET['id'];
    $pdo->prepare("UPDATE orders SET is_paid=1, status='confirmed' WHERE id=?")->execute([$id]);
    $msg='پرداخت تأیید و سفارش تأیید شد ✓'; $op='orders';
}
if ($op === 'archive_order') {
    $id=(int)$_GET['id'];
    $pdo->prepare("UPDATE orders SET is_archived=1, closed_at=COALESCE(closed_at,?) WHERE id=?")->execute([$now,$id]);
    $msg='سفارش به آرشیو منتقل شد.'; $op=$_GET['page'] ?? 'orders';
}
if ($op === 'unarchive_order') {
    $id=(int)$_GET['id'];
    $pdo->prepare("UPDATE orders SET is_archived=0 WHERE id=?")->execute([$id]);
    $msg='سفارش از آرشیو خارج شد.'; $op=$_GET['page'] ?? 'archive';
}
if ($op === 'delete_order') {
    $id=(int)$_GET['id'];
    $pdo->beginTransaction();
    try {
        $order = $pdo->prepare("SELECT * FROM orders WHERE id=?");
        $order->execute([$id]);
        $o = $order->fetch();
        if ($o) {
            $items = json_decode($o['items'], true) ?: [];
            $main_wh = main_warehouse_id();
            if ($o['status'] === 'pending' || $o['status'] === 'cancelled') {
                foreach ($items as $it) {
                    $pdo->prepare("UPDATE stock SET quantity = quantity + ? WHERE product_id=? AND warehouse_id=?")
                        ->execute([(int)$it['qty'], (int)$it['id'], $main_wh]);
                }
            }
            $pdo->prepare("DELETE FROM orders WHERE id=?")->execute([$id]);
        }
        $pdo->commit();
        $msg='سفارش حذف شد.';
    } catch (Exception $e) { $pdo->rollBack(); $msg='خطا: '.$e->getMessage(); $msg_type='error'; }
    $op = $_GET['page'] ?? 'orders';
}
if ($op === 'export_orders') {
    $filter = $_GET['status'] ?? 'all';
    $archived = isset($_GET['archived']);
    $sql = "SELECT * FROM orders WHERE is_archived=" . ($archived ? "1" : "0");
    $params = [];
    if (!$archived && $filter !== 'all') { $sql .= " AND status=?"; $params[] = $filter; }
    if ($archived && $filter !== 'all') { $sql .= " AND status=?"; $params[] = $filter; }
    $sql .= " ORDER BY id DESC";
    $st = $pdo->prepare($sql); $st->execute($params);
    $rows = $st->fetchAll();
    header('Content-Type: text/csv; charset=utf-8');
    header('Content-Disposition: attachment; filename=orders_' . ($archived?'archive_':'') . date('Y-m-d') . '.csv');
    $out = fopen('php://output', 'w');
    fputs($out, "\xEF\xBB\xBF");
    fputcsv($out, ['کد','مشتری','موبایل','آدرس','اقلام','مبلغ کل','تخفیف','پرداخت','وضعیت','روش پرداخت','تاریخ']);
    foreach ($rows as $o) {
        $items = json_decode($o['items'], true) ?: [];
        $item_names = [];
        foreach ($items as $it) $item_names[] = $it['name'] . ' × ' . $it['qty'];
        fputcsv($out, [
            $o['order_code'], $o['customer_name'], $o['phone'],
            $o['address'], implode(' | ', $item_names),
            $o['total'], $o['discount_amount'],
            $o['is_paid']?'پرداخت شده':'پرداخت نشده',
            $status_labels[$o['status']] ?? $o['status'],
            $o['payment_method']==='voucher'?'کالابرگ':'نقدی',
            $o['created_at']
        ]);
    }
    fclose($out);
    exit;
}

// --- انبارها ---
if ($op === 'save_warehouse') {
    $wname = trim($_POST['wh_name'] ?? '');
    $wid = (int)($_POST['wh_id'] ?? 0);
    $sort = (int)($_POST['sort_order'] ?? 0);
    $note = trim($_POST['note'] ?? '');
    $is_main = isset($_POST['is_main']) ? 1 : 0;
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    if ($wname !== '') {
        if ($is_main) $pdo->exec("UPDATE warehouses SET is_main=0");
        if ($wid > 0) {
            $pdo->prepare("UPDATE warehouses SET name=?,is_main=?,is_active=?,sort_order=?,note=? WHERE id=?")
                ->execute([$wname,$is_main,$is_active,$sort,$note,$wid]);
            $msg='انبار ویرایش شد.';
        } else {
            $pdo->prepare("INSERT INTO warehouses (name,is_main,is_active,sort_order,note,created_at) VALUES (?,?,?,?,?,?)")
                ->execute([$wname,$is_main,$is_active,$sort,$note,$now]);
            $msg='انبار جدید اضافه شد.';
        }
    }
    $op='warehouses';
}
if ($op === 'delete_warehouse') {
    $wid = (int)$_GET['id'];
    $r = $pdo->prepare("SELECT is_main FROM warehouses WHERE id=?");
    $r->execute([$wid]);
    $rr = $r->fetch();
    if ($rr && $rr['is_main']) { $msg='انبار اصلی قابل حذف نیست.'; $msg_type='error'; }
    else {
        $pdo->beginTransaction();
        try {
            $pdo->prepare("DELETE FROM stock WHERE warehouse_id=?")->execute([$wid]);
            $pdo->prepare("DELETE FROM stock_movements WHERE warehouse_id=? OR from_warehouse_id=? OR to_warehouse_id=?")->execute([$wid,$wid,$wid]);
            $pdo->prepare("DELETE FROM warehouses WHERE id=?")->execute([$wid]);
            $pdo->commit();
            $msg='انبار حذف شد.';
        } catch (Exception $e) { $pdo->rollBack(); $msg='خطا: '.$e->getMessage(); $msg_type='error'; }
    }
    $op='warehouses';
}

if ($op === 'add_stock') {
    $pid = (int)$_POST['product_id'];
    $wid = (int)$_POST['warehouse_id'];
    $qty = (int)$_POST['quantity'];
    $unit_price = (int)$_POST['unit_price'];
    $note = trim($_POST['note'] ?? '');
    if ($pid > 0 && $wid > 0 && $qty > 0) {
        $pdo->beginTransaction();
        try {
            $ex = $pdo->prepare("SELECT quantity FROM stock WHERE product_id=? AND warehouse_id=?");
            $ex->execute([$pid, $wid]);
            $cur = $ex->fetch();
            if ($cur) $pdo->prepare("UPDATE stock SET quantity=quantity+? WHERE product_id=? AND warehouse_id=?")->execute([$qty, $pid, $wid]);
            else $pdo->prepare("INSERT INTO stock (product_id,warehouse_id,quantity) VALUES (?,?,?)")->execute([$pid, $wid, $qty]);
            $pdo->prepare("INSERT INTO stock_movements (product_id,warehouse_id,type,quantity,unit_price,note,created_at) VALUES (?,?,?,?,?,?,?)")
                ->execute([$pid, $wid, 'purchase', $qty, $unit_price, $note ?: 'خرید / افزایش موجودی', $now]);
            if ($wid == main_warehouse_id()) {
                $pdo->prepare("UPDATE products SET stock=stock+? WHERE id=?")->execute([$qty, $pid]);
            }
            $pdo->commit();
            $msg = "$qty عدد به انبار اضافه شد.";
        } catch (Exception $e) { $pdo->rollBack(); $msg='خطا: '.$e->getMessage(); $msg_type='error'; }
    }
    $op = 'stock';
}
if ($op === 'adjust_stock') {
    $pid = (int)$_POST['product_id'];
    $wid = (int)$_POST['warehouse_id'];
    $new_qty = (int)$_POST['new_quantity'];
    $note = trim($_POST['note'] ?? '');
    $pdo->beginTransaction();
    try {
        $ex = $pdo->prepare("SELECT quantity FROM stock WHERE product_id=? AND warehouse_id=?");
        $ex->execute([$pid, $wid]);
        $cur = $ex->fetch();
        $old = $cur ? (int)$cur['quantity'] : 0;
        $diff = $new_qty - $old;
        if ($cur) $pdo->prepare("UPDATE stock SET quantity=? WHERE product_id=? AND warehouse_id=?")->execute([$new_qty, $pid, $wid]);
        else $pdo->prepare("INSERT INTO stock (product_id,warehouse_id,quantity) VALUES (?,?,?)")->execute([$pid, $wid, $new_qty]);
        if ($diff != 0) {
            $pdo->prepare("INSERT INTO stock_movements (product_id,warehouse_id,type,quantity,note,created_at) VALUES (?,?,?,?,?,?)")
                ->execute([$pid, $wid, 'adjust', $diff, $note ?: 'تعدیل دستی موجودی', $now]);
        }
        if ($wid == main_warehouse_id()) {
            $pdo->prepare("UPDATE products SET stock=? WHERE id=?")->execute([$new_qty, $pid]);
        }
        $pdo->commit();
        $msg = 'موجودی به '.$new_qty.' عدد تنظیم شد.';
    } catch (Exception $e) { $pdo->rollBack(); $msg='خطا: '.$e->getMessage(); $msg_type='error'; }
    $op = 'stock';
}

if ($op === 'create_transfer') {
    $from = (int)$_POST['from_warehouse_id'];
    $to = (int)$_POST['to_warehouse_id'];
    $items = $_POST['items'] ?? [];
    $note = trim($_POST['note'] ?? '');
    if ($from === $to) { $msg='انبار مبدأ و مقصد نمی‌توانند یکسان باشند.'; $msg_type='error'; }
    elseif (empty($items)) { $msg='حداقل یک قلم کالا انتخاب کنید.'; $msg_type='error'; }
    else {
        $pdo->beginTransaction();
        try {
            foreach ($items as $it) {
                $pid = (int)$it['product_id'];
                $qty = (int)$it['quantity'];
                if ($qty <= 0) continue;
                $avail = get_stock($pid, $from);
                if ($avail < $qty) {
                    $pname = $pdo->prepare("SELECT name FROM products WHERE id=?");
                    $pname->execute([$pid]);
                    $pn = $pname->fetch();
                    throw new Exception("موجودی «{$pn['name']}» در انبار مبدأ فقط $avail عدد است.");
                }
            }
            foreach ($items as $it) {
                $pid = (int)$it['product_id'];
                $qty = (int)$it['quantity'];
                if ($qty <= 0) continue;
                $pdo->prepare("UPDATE stock SET quantity=quantity-? WHERE product_id=? AND warehouse_id=?")->execute([$qty, $pid, $from]);
                $ex = $pdo->prepare("SELECT quantity FROM stock WHERE product_id=? AND warehouse_id=?");
                $ex->execute([$pid, $to]);
                if ($ex->fetch()) $pdo->prepare("UPDATE stock SET quantity=quantity+? WHERE product_id=? AND warehouse_id=?")->execute([$qty, $pid, $to]);
                else $pdo->prepare("INSERT INTO stock (product_id,warehouse_id,quantity) VALUES (?,?,?)")->execute([$pid, $to, $qty]);
                $pdo->prepare("INSERT INTO stock_movements (product_id,warehouse_id,from_warehouse_id,to_warehouse_id,type,quantity,note,created_at) VALUES (?,?,?,?,?,?,?,?)")
                    ->execute([$pid, $from, $from, $to, 'transfer_out', $qty, $note ?: 'حواله به انبار دیگر', $now]);
                $pdo->prepare("INSERT INTO stock_movements (product_id,warehouse_id,from_warehouse_id,to_warehouse_id,type,quantity,note,created_at) VALUES (?,?,?,?,?,?,?,?)")
                    ->execute([$pid, $to, $from, $to, 'transfer_in', $qty, $note ?: 'حواله از انبار دیگر', $now]);
            }
            $pdo->commit();
            $msg='حواله با موفقیت ثبت شد.'; $op='transfers';
        } catch (Exception $e) { $pdo->rollBack(); $msg='خطا: '.$e->getMessage(); $msg_type='error'; $op='transfer_new'; }
    }
}

// --- هزینه‌ها ---
if ($op === 'save_expense') {
    $title = trim($_POST['title'] ?? '');
    $amount = (int)($_POST['amount'] ?? 0);
    $category = trim($_POST['category'] ?? '');
    $expense_date = $_POST['expense_date'] ?? date('Y-m-d');
    $note = trim($_POST['note'] ?? '');
    $eid = (int)($_POST['expense_id'] ?? 0);
    if ($title !== '' && $amount > 0) {
        if ($eid > 0) {
            $pdo->prepare("UPDATE expenses SET title=?,amount=?,category=?,expense_date=?,note=? WHERE id=?")->execute([$title,$amount,$category,$expense_date,$note,$eid]);
            $msg='هزینه ویرایش شد.';
        } else {
            $pdo->prepare("INSERT INTO expenses (title,amount,category,expense_date,note,created_at) VALUES (?,?,?,?,?,?)")->execute([$title,$amount,$category,$expense_date,$note,$now]);
            $msg='هزینه ثبت شد.';
        }
    }
    $op='accounting';
}
if ($op === 'delete_expense') {
    $id=(int)$_GET['id'];
    $pdo->prepare("DELETE FROM expenses WHERE id=?")->execute([$id]);
    $msg='هزینه حذف شد.'; $op='accounting';
}

// --- Flash Sale ---
if ($op === 'save_flash_sale') {
    $fid = (int)($_POST['fs_id'] ?? 0);
    $pid = (int)$_POST['product_id'];
    $d_pct = (int)($_POST['discount_percent'] ?? 0);
    $d_price = (int)($_POST['discount_price'] ?? 0);
    $starts = $_POST['starts_at'];
    $ends = $_POST['ends_at'];
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    if ($pid > 0 && $starts && $ends) {
        $starts = str_replace('T',' ',$starts);
        $ends = str_replace('T',' ',$ends);
        if ($fid > 0) {
            $pdo->prepare("UPDATE flash_sales SET product_id=?,discount_percent=?,discount_price=?,starts_at=?,ends_at=?,is_active=? WHERE id=?")
                ->execute([$pid,$d_pct,$d_price,$starts,$ends,$is_active,$fid]);
            $msg='تخفیف ویرایش شد.';
        } else {
            $pdo->prepare("INSERT INTO flash_sales (product_id,discount_percent,discount_price,starts_at,ends_at,is_active,created_at) VALUES (?,?,?,?,?,?,?)")
                ->execute([$pid,$d_pct,$d_price,$starts,$ends,$is_active,$now]);
            $msg='تخفیف ایجاد شد.';
        }
    }
    $op='flash_sales';
}
if ($op === 'delete_flash_sale') {
    $id=(int)$_GET['id'];
    $pdo->prepare("DELETE FROM flash_sales WHERE id=?")->execute([$id]);
    $msg='تخفیف حذف شد.'; $op='flash_sales';
}

// --- کد تخفیف ---
if ($op === 'save_discount_code') {
    $did = (int)($_POST['dc_id'] ?? 0);
    $code = trim(strtoupper($_POST['code']));
    $type = $_POST['dc_type'];
    $value = (int)$_POST['dc_value'];
    $min_order = (int)$_POST['min_order'];
    $max_uses = (int)$_POST['max_uses'];
    $max_per_customer = (int)$_POST['max_per_customer'];
    $starts = $_POST['starts_at'] ?: null;
    $ends = $_POST['ends_at'] ?: null;
    $applies_to = $_POST['applies_to'];
    $cat_id = (int)($_POST['category_id'] ?? 0) ?: null;
    $prod_id = (int)($_POST['product_id'] ?? 0) ?: null;
    $first_only = isset($_POST['first_order_only']) ? 1 : 0;
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    if ($starts) $starts = str_replace('T',' ',$starts) . ':00';
    if ($ends) $ends = str_replace('T',' ',$ends) . ':59';
    if ($code !== '' && $value > 0) {
        try {
            if ($did > 0) {
                $pdo->prepare("UPDATE discount_codes SET code=?,type=?,value=?,min_order=?,max_uses=?,max_per_customer=?,starts_at=?,ends_at=?,applies_to=?,category_id=?,product_id=?,first_order_only=?,is_active=? WHERE id=?")
                    ->execute([$code,$type,$value,$min_order,$max_uses,$max_per_customer,$starts,$ends,$applies_to,$cat_id,$prod_id,$first_only,$is_active,$did]);
                $msg='کد تخفیف ویرایش شد.';
            } else {
                $pdo->prepare("INSERT INTO discount_codes (code,type,value,min_order,max_uses,max_per_customer,starts_at,ends_at,applies_to,category_id,product_id,first_order_only,is_active,created_at) VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?)")
                    ->execute([$code,$type,$value,$min_order,$max_uses,$max_per_customer,$starts,$ends,$applies_to,$cat_id,$prod_id,$first_only,$is_active,$now]);
                $msg='کد تخفیف ایجاد شد.';
            }
        } catch (Exception $e) {
            $msg='خطا: '.$e->getMessage(); $msg_type='error';
        }
    }
    $op='discount_codes';
}
if ($op === 'delete_discount_code') {
    $id=(int)$_GET['id'];
    $pdo->prepare("DELETE FROM discount_code_usage WHERE code_id=?")->execute([$id]);
    $pdo->prepare("DELETE FROM discount_codes WHERE id=?")->execute([$id]);
    $msg='کد تخفیف حذف شد.'; $op='discount_codes';
}

// --- تب‌های سفارشی ---
if ($op === 'save_custom_tab') {
    $tid = (int)($_POST['tab_id'] ?? 0);
    $title = trim($_POST['title']);
    $tab_type = $_POST['tab_type'];
    $sort = (int)$_POST['sort_order'];
    $icon = trim($_POST['icon'] ?? '');
    $is_active = isset($_POST['is_active']) ? 1 : 0;
    if ($title !== '' && $tab_type !== '') {
        if ($tid > 0) {
            $pdo->prepare("UPDATE custom_tabs SET title=?,tab_type=?,sort_order=?,icon=?,is_active=? WHERE id=?")
                ->execute([$title,$tab_type,$sort,$icon,$is_active,$tid]);
            $msg='تب ویرایش شد.';
        } else {
            $pdo->prepare("INSERT INTO custom_tabs (title,tab_type,sort_order,icon,is_active,created_at) VALUES (?,?,?,?,?,?)")
                ->execute([$title,$tab_type,$sort,$icon,$is_active,$now]);
            $msg='تب ایجاد شد.';
        }
    }
    $op='custom_tabs';
}
if ($op === 'delete_custom_tab') {
    $id=(int)$_GET['id'];
    $pdo->prepare("DELETE FROM custom_tabs WHERE id=?")->execute([$id]);
    $msg='تب حذف شد.'; $op='custom_tabs';
}

// --- سفارشی‌سازی (لوگو، بک‌گراند، دکمه‌ها) ---
if ($op === 'save_customize') {
    $logo_up = handle_upload('logo_file', 'logo');
    if ($logo_up) save_setting('site_logo', $logo_up);
    elseif (isset($_POST['remove_logo']) && $_POST['remove_logo']==='1') save_setting('site_logo', '');

    $bg_up = handle_upload('bg_file', 'bg');
    if ($bg_up) save_setting('site_bg_image', $bg_up);
    elseif (isset($_POST['remove_bg']) && $_POST['remove_bg']==='1') save_setting('site_bg_image', '');

    $keys = [
        'site_bg_text_color','site_bg_overlay',
        'hero_title','hero_subtitle','hero_badge_text',
        'show_cod_payment',
        'btn_cart_label','btn_add_to_cart_label','btn_checkout_label',
        'btn_continue_label','btn_empty_cart_label','btn_search_label',
        'discount_code_label',
    ];
    foreach ($keys as $k) {
        if (isset($_POST[$k])) save_setting($k, trim($_POST[$k]));
    }
    $msg='سفارشی‌سازی ذخیره شد ✓'; $op='customize';
}
if ($op === 'reset_labels') {
    $defaults = [
        'btn_cart_label'=>'سبد خرید','btn_add_to_cart_label'=>'افزودن به سبد',
        'btn_checkout_label'=>'ادامه و ثبت سفارش','btn_continue_label'=>'بازگشت به فروشگاه',
        'btn_empty_cart_label'=>'سبد خرید شما خالی است','btn_search_label'=>'جستجوی محصول...',
        'discount_code_label'=>'کد تخفیف دارید؟',
        'hero_badge_text'=>'پرداخت درب منزل (نقدی هنگام تحویل)',
    ];
    foreach ($defaults as $k=>$v) save_setting($k, $v);
    $msg='لیبل‌ها به حالت پیش‌فرض بازنشانی شدند.'; $op='customize';
}

// --- تنظیمات اصلی ---
if ($op === 'save_settings') {
    $keys = ['shop_name','shop_slogan','shop_phone','shop_address','shop_about','shop_instagram','shop_telegram','delivery_fee','min_order','primary_color','allowed_city'];
    foreach ($keys as $k) {
        if (isset($_POST[$k])) save_setting($k, trim($_POST[$k]));
    }
    $msg='تنظیمات فروشگاه ذخیره شد.'; $op='settings';
}
if ($op === 'change_password') {
    $cur = $_POST['current_password'] ?? '';
    $new = $_POST['new_password'] ?? '';
    $conf = $_POST['confirm_password'] ?? '';
    if ($cur !== setting('admin_password')) { $msg='رمز فعلی اشتباه است.'; $msg_type='error'; }
    elseif (strlen($new) < 4) { $msg='رمز جدید باید حداقل ۴ کاراکتر باشد.'; $msg_type='error'; }
    elseif ($new !== $conf) { $msg='رمز جدید و تکرار آن یکسان نیستند.'; $msg_type='error'; }
    else { save_setting('admin_password', $new); $msg='رمز عبور با موفقیت تغییر کرد.'; }
    $op='settings';
}

// --- تیکت جدید (فقط ادمین فروشگاه تیکت جدید باز می‌کند) ---
if ($op === 'open_ticket') {
    $subject = trim($_POST['subject'] ?? '');
    $message = trim($_POST['message'] ?? '');
    $priority = $_POST['priority'] ?? 'normal';
    if (!in_array($priority, ['low','normal','high','urgent'])) $priority = 'normal';
    if ($subject === '' || $message === '') {
        $msg = 'عنوان و متن تیکت الزامی است.'; $msg_type='error';
    } else {
        $pdo->prepare("INSERT INTO support_tickets (subject,status,priority,last_reply_by,created_at,updated_at) VALUES (?,?,?,?,?,?)")
            ->execute([$subject,'open',$priority,'admin',$now,$now]);
        $tid = $pdo->lastInsertId();
        $pdo->prepare("INSERT INTO ticket_messages (ticket_id,sender,message,is_read_by_admin,is_read_by_support,created_at) VALUES (?,?,?,?,?,?)")
            ->execute([$tid,'admin',$message,1,0,$now]);
        header('Location: admin.php?page=ticket_view&id='.$tid); exit;
    }
}
if ($op === 'reply_ticket') {
    $tid = (int)$_POST['ticket_id'];
    $message = trim($_POST['message'] ?? '');
    if ($message === '') {
        $msg = 'متن پیام خالی است.'; $msg_type='error';
    } else {
        $pdo->prepare("INSERT INTO ticket_messages (ticket_id,sender,message,is_read_by_admin,is_read_by_support,created_at) VALUES (?,?,?,?,?,?)")
            ->execute([$tid,'admin',$message,1,0,$now]);
        $pdo->prepare("UPDATE support_tickets SET status='open', last_reply_by='admin', updated_at=? WHERE id=?")->execute([$now,$tid]);
        header('Location: admin.php?page=ticket_view&id='.$tid); exit;
    }
}
if ($op === 'close_ticket') {
    $tid = (int)$_POST['ticket_id'];
    $pdo->prepare("UPDATE support_tickets SET status='closed', updated_at=? WHERE id=?")->execute([$now,$tid]);
    $msg = 'تیکت بسته شد.'; 
    header('Location: admin.php?page=support'); exit;
}

// --- تنظیمات چاپ فاکتور ---
if ($op === 'save_invoice_settings') {
    $keys = ['invoice_a4_title','invoice_a4_footer','invoice_a4_notes','invoice_a4_seal_text','invoice_a4_primary_color','invoice_thermal_title','invoice_thermal_header','invoice_thermal_footer','invoice_thermal_width'];
    foreach ($keys as $k) { if (isset($_POST[$k])) save_setting($k, trim($_POST[$k])); }
    foreach (['invoice_a4_show_logo','invoice_a4_show_signature','invoice_a4_show_barcode','invoice_thermal_show_logo','invoice_thermal_show_barcode','invoice_show_tracking_qr'] as $k) {
        save_setting($k, isset($_POST[$k]) ? '1' : '0');
    }
    $msg='تنظیمات فاکتور ذخیره شد.'; $op='invoice_settings';
}

// --- درخواست تمدید ---
if ($op === 'submit_renewal') {
    $plan_type = trim($_POST['plan_type'] ?? '');
    $note = trim($_POST['note'] ?? '');
    if (!in_array($plan_type, ['monthly','quarterly','semiannual','annual','permanent'])) {
        $msg = 'پلان انتخابی نامعتبر است.'; $msg_type='error';
    } else {
        $pdo->prepare("INSERT INTO renewal_requests (plan_type,note,status,created_at) VALUES (?,?,?,?)")
           ->execute([$plan_type, $note, 'pending', $now]);
        $msg = 'درخواست تمدید شما با موفقیت ثبت شد. پس از پرداخت، با پشتیبانی تماس بگیرید.';
    }
    $op = 'renew';
}

// =====================================================
//  بارگذاری داده‌ها
// =====================================================
// اعمال قفل لایسنس بعد از لاگین
enforce_license_lock();
$page = $_GET['page'] ?? 'dashboard';

$stats = [
    'products'  => $pdo->query("SELECT COUNT(*) c FROM products")->fetch()['c'],
    'orders'    => $pdo->query("SELECT COUNT(*) c FROM orders WHERE is_archived=0")->fetch()['c'],
    'archived'  => $pdo->query("SELECT COUNT(*) c FROM orders WHERE is_archived=1")->fetch()['c'],
    'pending'   => $pdo->query("SELECT COUNT(*) c FROM orders WHERE status='pending' AND is_archived=0")->fetch()['c'],
    'revenue'   => $pdo->query("SELECT COALESCE(SUM(total),0) s FROM orders WHERE is_paid=1")->fetch()['s'],
    'profit'    => $pdo->query("SELECT COALESCE(SUM(profit),0) s FROM orders WHERE is_paid=1")->fetch()['s'],
    'warehouses'=> $pdo->query("SELECT COUNT(*) c FROM warehouses WHERE is_active=1")->fetch()['c'],
    'low_stock' => $pdo->query("SELECT COUNT(*) c FROM products p JOIN stock s ON s.product_id=p.id AND s.warehouse_id=".main_warehouse_id()." WHERE p.is_active=1 AND s.quantity <= p.min_stock")->fetch()['c'],
    'expenses_month' => $pdo->query("SELECT COALESCE(SUM(amount),0) s FROM expenses WHERE strftime('%Y-%m',expense_date)=strftime('%Y-%m','now')")->fetch()['s'],
    'capital_cost'   => $pdo->query("SELECT COALESCE(SUM(s.quantity * COALESCE(p.cost_price,0)),0) s FROM stock s JOIN products p ON p.id=s.product_id")->fetch()['s'],
    'capital_sell'   => $pdo->query("SELECT COALESCE(SUM(s.quantity * p.price),0) s FROM stock s JOIN products p ON p.id=s.product_id")->fetch()['s'],
    'active_flash'   => (int)$pdo->query("SELECT COUNT(*) c FROM flash_sales WHERE is_active=1 AND starts_at<=datetime('now') AND ends_at>=datetime('now')")->fetch()['c'],
    'discount_codes' => $pdo->query("SELECT COUNT(*) c FROM discount_codes WHERE is_active=1")->fetch()['c'],
    'voucher_orders' => $pdo->query("SELECT COUNT(*) c FROM orders WHERE payment_method='voucher' AND is_archived=0")->fetch()['c'],
];
$categories = $pdo->query("SELECT * FROM categories ORDER BY sort_order,id")->fetchAll();
$warehouses = $pdo->query("SELECT * FROM warehouses ORDER BY is_main DESC, sort_order, id")->fetchAll();

$edit_product = null;
if ($page === 'product_form' && isset($_GET['id'])) {
    $st = $pdo->prepare("SELECT * FROM products WHERE id=?");
    $st->execute([(int)$_GET['id']]);
    $edit_product = $st->fetch();
}

$prod_search = trim($_GET['ps'] ?? '');
if ($prod_search !== '') {
    $st = $pdo->prepare("SELECT p.*, c.name cat_name FROM products p LEFT JOIN categories c ON p.category_id=c.id WHERE p.name LIKE ? OR (p.barcode IS NOT NULL AND p.barcode LIKE ?) OR (p.sku IS NOT NULL AND p.sku LIKE ?) ORDER BY p.id DESC");
    $st->execute(["%$prod_search%","%$prod_search%","%$prod_search%"]);
    $all_products = $st->fetchAll();
} else {
    $all_products = $pdo->query("SELECT p.*, c.name cat_name FROM products p LEFT JOIN categories c ON p.category_id=c.id ORDER BY p.id DESC")->fetchAll();
}

$order_filter = $_GET['status'] ?? 'all';
$sql = "SELECT * FROM orders WHERE is_archived=0";
$params = [];
if ($order_filter !== 'all') { $sql .= " AND status=?"; $params[] = $order_filter; }
$sql .= " ORDER BY id DESC";
$st = $pdo->prepare($sql); $st->execute($params);
$all_orders = $st->fetchAll();

$archive_filter = $_GET['astatus'] ?? 'all';
$sql = "SELECT * FROM orders WHERE is_archived=1";
$params = [];
if ($archive_filter !== 'all') { $sql .= " AND status=?"; $params[] = $archive_filter; }
$sql .= " ORDER BY id DESC";
$st = $pdo->prepare($sql); $st->execute($params);
$archived_orders = $st->fetchAll();

$chart_data = [];
for ($i=6;$i>=0;$i--){
    $d = date('Y-m-d', strtotime("-$i days"));
    $st = $pdo->prepare("SELECT COUNT(*) c, COALESCE(SUM(total),0) s, COALESCE(SUM(profit),0) pr FROM orders WHERE date(created_at)=?");
    $st->execute([$d]);
    $r = $st->fetch();
    $chart_data[] = ['date'=>date('m/d',strtotime($d)),'count'=>(int)$r['c'],'sum'=>(int)$r['s'],'profit'=>(int)$r['pr']];
}

$status_labels = ['pending'=>'در انتظار','confirmed'=>'تأیید شده','preparing'=>'در حال آماده‌سازی','ready'=>'آماده ارسال','delivered'=>'تحویل شده','cancelled'=>'لغو شده'];
$status_colors = ['pending'=>'#f4a261','confirmed'=>'#2a9d8f','preparing'=>'#9b59b6','ready'=>'#457b9d','delivered'=>'#27ae60','cancelled'=>'#e63946'];
$primary = setting('primary_color', '#e63946');
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>پنل مدیریت | <?= e(setting('shop_name')) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css">
<script src="https://cdn.jsdelivr.net/npm/chart.js@4.4.0/dist/chart.umd.min.js"></script>
<style>
:root{--primary:<?= e($primary) ?>;--bg:#f0f2f5;--sidebar:#1d2630;--card:#fff;--text:#2c3e50;--muted:#7f8c8d;--border:#e8eaed;--green:#2a9d8f;--orange:#f4a261;--red:#e63946;--blue:#457b9d;}
*{margin:0;padding:0;box-sizing:border-box;font-family:'Vazirmatn',sans-serif;}
body{background:var(--bg);color:var(--text);}
a{text-decoration:none;color:inherit;}
.layout{display:flex;min-height:100vh;}

.sidebar{width:280px;background:var(--sidebar);color:#cfd6dd;position:fixed;top:0;right:0;height:100vh;overflow-y:auto;transition:.3s;z-index:50;}
.sidebar .brand{padding:18px 20px;font-size:17px;font-weight:800;color:#fff;border-bottom:1px solid rgba(255,255,255,.08);display:flex;align-items:center;gap:10px;}
.sidebar .brand img{max-height:36px;}
.sidebar .brand i{color:var(--primary);font-size:22px;}
.sidebar .section-title{padding:12px 22px 4px;font-size:11px;color:#7c8893;text-transform:uppercase;letter-spacing:.5px;font-weight:600;}
.sidebar nav{padding:4px 0 12px;}
.sidebar nav a{display:flex;align-items:center;gap:11px;padding:10px 22px;font-size:13.5px;color:#aab3bd;transition:.2s;border-right:3px solid transparent;}
.sidebar nav a:hover{background:rgba(255,255,255,.05);color:#fff;}
.sidebar nav a.active{background:rgba(230,57,70,.15);color:#fff;border-right-color:var(--primary);}
.sidebar nav a i{width:18px;text-align:center;font-size:14px;}
.sidebar nav a .b{margin-right:auto;background:var(--primary);color:#fff;border-radius:20px;padding:1px 8px;font-size:11px;}
.sidebar .logout-link{color:#e74c3c;}

.main{margin-right:280px;flex:1;min-width:0;transition:.3s;}
.topbar{background:#fff;padding:14px 26px;display:flex;align-items:center;justify-content:space-between;box-shadow:0 2px 8px rgba(0,0,0,.04);position:sticky;top:0;z-index:40;}
.topbar h1{font-size:20px;font-weight:700;}
.topbar .top-actions{display:flex;gap:10px;align-items:center;}
.topbar a.view-site{background:var(--primary);color:#fff;padding:8px 14px;border-radius:10px;font-size:13px;font-weight:600;}
.menu-toggle{display:none;background:none;font-size:24px;color:var(--text);border:none;cursor:pointer;}
.content{padding:24px;}

.alert{padding:14px 18px;border-radius:12px;font-size:14px;margin-bottom:20px;display:flex;align-items:center;gap:10px;font-weight:500;}
.alert.success{background:#e7f5ee;color:#1b6e57;}
.alert.error{background:#fde8e8;color:#c0392b;}

.stats-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(190px,1fr));gap:14px;margin-bottom:22px;}
.stat-card{background:#fff;border-radius:14px;padding:18px;display:flex;align-items:center;gap:13px;box-shadow:0 4px 14px rgba(0,0,0,.05);}
.stat-card .ic{width:50px;height:50px;border-radius:11px;display:flex;align-items:center;justify-content:center;font-size:20px;color:#fff;flex-shrink:0;}
.stat-card .info .num{font-size:21px;font-weight:800;}
.stat-card .info .num.sm{font-size:15px;}
.stat-card .info .lbl{font-size:12.5px;color:var(--muted);margin-top:2px;}

.panel{background:#fff;border-radius:14px;box-shadow:0 4px 14px rgba(0,0,0,.05);margin-bottom:22px;overflow:hidden;}
.panel-head{padding:16px 22px;border-bottom:1px solid var(--border);display:flex;align-items:center;justify-content:space-between;flex-wrap:wrap;gap:12px;}
.panel-head h2{font-size:17px;font-weight:700;display:flex;align-items:center;gap:8px;}
.panel-body{padding:20px;}

.btn{display:inline-flex;align-items:center;gap:7px;padding:9px 16px;border-radius:9px;font-size:13.5px;font-weight:600;border:none;cursor:pointer;transition:.2s;font-family:inherit;}
.btn-primary{background:var(--primary);color:#fff;}
.btn-primary:hover{filter:brightness(1.1);}
.btn-success{background:var(--green);color:#fff;}
.btn-secondary{background:#eef1f5;color:#555;}
.btn-danger{background:var(--red);color:#fff;}
.btn-warning{background:var(--orange);color:#fff;}
.btn-sm{padding:6px 11px;font-size:12.5px;border-radius:7px;}

.table-wrap{overflow-x:auto;}
table{width:100%;border-collapse:collapse;}
table th{background:#f8f9fb;padding:12px 13px;text-align:right;font-size:12.5px;color:var(--muted);font-weight:600;white-space:nowrap;}
table td{padding:12px 13px;border-top:1px solid var(--border);font-size:13.5px;vertical-align:middle;}
table tr:hover td{background:#fafbfc;}
.t-img{width:42px;height:42px;border-radius:9px;object-fit:cover;background:#f0f1f4;}
.t-noimg{width:42px;height:42px;border-radius:9px;background:#f0f1f4;display:flex;align-items:center;justify-content:center;color:#ccc;}
.badge{display:inline-block;padding:4px 10px;border-radius:18px;font-size:12px;font-weight:600;color:#fff;}
.tag{display:inline-block;padding:3px 9px;border-radius:6px;font-size:11px;font-weight:600;}
.tag-feat{background:#fef3e2;color:#d98324;}
.tag-off{background:#fde8e8;color:#e63946;}
.tag-on{background:#e7f5ee;color:#2a9d8f;}
.tag-off2{background:#f0f1f4;color:#888;}
.tag-main{background:#d4edda;color:#1b6e57;}
.tag-low{background:#fff3cd;color:#856404;}
.tag-voucher{background:#fff3e0;color:#d98324;}

.form-row{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:16px;}
.form-group{margin-bottom:16px;}
.form-group label{display:block;font-size:13.5px;font-weight:600;margin-bottom:6px;}
.form-group label .hint{color:var(--muted);font-weight:400;font-size:12px;}
.form-control{width:100%;padding:10px 13px;border:2px solid var(--border);border-radius:9px;font-size:13.5px;outline:none;font-family:inherit;transition:.2s;}
.form-control:focus{border-color:var(--primary);}
textarea.form-control{resize:vertical;min-height:80px;}
.checkbox-row{display:flex;gap:20px;flex-wrap:wrap;}
.checkbox-row label{display:flex;align-items:center;gap:7px;font-weight:500;cursor:pointer;}
.checkbox-row input{width:17px;height:17px;accent-color:var(--primary);}
.img-preview{width:80px;height:80px;border-radius:10px;object-fit:cover;border:2px solid var(--border);margin-top:8px;}

.filter-tabs{display:flex;gap:6px;flex-wrap:wrap;}
.filter-tabs a{padding:6px 13px;border-radius:8px;font-size:12.5px;font-weight:600;background:#eef1f5;color:#555;}
.filter-tabs a.active{background:var(--primary);color:#fff;}

.search-mini{display:flex;border:2px solid var(--border);border-radius:9px;overflow:hidden;}
.search-mini input{border:none;padding:8px 12px;outline:none;font-family:inherit;font-size:13.5px;}
.search-mini button{background:var(--primary);color:#fff;padding:0 12px;border:none;cursor:pointer;}

.order-items{font-size:12.5px;color:#555;}
.order-items div{padding:2px 0;}

.empty{text-align:center;padding:50px 0;color:var(--muted);}
.empty i{font-size:60px;color:#ddd;margin-bottom:14px;}

.overlay{display:none;position:fixed;inset:0;background:rgba(0,0,0,.4);z-index:45;}

/* ماشین حساب شناور */
.calc-fab{position:fixed;bottom:24px;left:24px;width:60px;height:60px;border-radius:50%;background:linear-gradient(135deg,var(--primary),#1d3557);color:#fff;display:flex;align-items:center;justify-content:center;font-size:26px;cursor:pointer;box-shadow:0 6px 20px rgba(0,0,0,.25);z-index:80;border:none;transition:.2s;}
.calc-fab:hover{transform:scale(1.08);}
.calc-modal{position:fixed;bottom:96px;left:24px;width:300px;background:#fff;border-radius:18px;box-shadow:0 20px 50px rgba(0,0,0,.3);padding:18px;z-index:81;display:none;}
.calc-modal.show{display:block;}
.calc-display{background:#1d2630;color:#fff;padding:16px;border-radius:12px;font-size:24px;font-weight:700;text-align:left;direction:ltr;min-height:60px;display:flex;align-items:center;justify-content:flex-end;word-break:break-all;margin-bottom:12px;font-family:'Courier New',monospace;}
.calc-grid{display:grid;grid-template-columns:repeat(4,1fr);gap:8px;}
.calc-btn{padding:14px;border:none;border-radius:9px;background:#f0f2f5;font-size:18px;font-weight:700;cursor:pointer;font-family:inherit;transition:.15s;}
.calc-btn:hover{background:#e2e6eb;}
.calc-btn.op{background:#ffd6c0;color:#c0392b;}
.calc-btn.eq{background:var(--primary);color:#fff;grid-column:span 2;}
.calc-btn.clr{background:#e63946;color:#fff;}
.calc-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:12px;}
.calc-head h3{font-size:16px;}
.calc-head .calc-close{background:none;border:none;font-size:20px;color:#999;cursor:pointer;}

@media(max-width:900px){
  .sidebar{transform:translateX(100%);}
  .sidebar.open{transform:translateX(0);}
  .main{margin-right:0;}
  .menu-toggle{display:block;}
  .overlay.show{display:block;}
  .calc-modal{width:calc(100vw - 32px);left:16px;right:16px;}
  .calc-fab{width:52px;height:52px;font-size:22px;}
}
</style>
</head>
<body>
<div class="layout">

  <aside class="sidebar" id="sidebar">
    <div class="brand">
      <?php if(setting('site_logo')): ?><img src="<?= e(setting('site_logo')) ?>" alt="logo"><?php else: ?><i class="fa-solid fa-store"></i><?php endif; ?>
      <?= e(setting('shop_name')) ?>
    </div>

    <div class="section-title">فروشگاه</div>
    <nav>
      <a href="admin.php?page=dashboard" class="<?= $page=='dashboard'?'active':'' ?>"><i class="fa-solid fa-chart-line"></i> داشبورد</a>
      <a href="admin.php?page=products" class="<?= in_array($page,['products','product_form'])?'active':'' ?>"><i class="fa-solid fa-box"></i> محصولات</a>
      <a href="admin.php?page=categories" class="<?= $page=='categories'?'active':'' ?>"><i class="fa-solid fa-tags"></i> دسته‌بندی‌ها</a>
      <a href="admin.php?page=orders" class="<?= $page=='orders'?'active':'' ?>"><i class="fa-solid fa-receipt"></i> سفارشات <?php if($stats['pending']>0): ?><span class="b"><?= $stats['pending'] ?></span><?php endif; ?></a>
      <a href="admin.php?page=fulfillment" class="<?= $page=='fulfillment'?'active':'' ?>"><i class="fa-solid fa-bag-shopping"></i> آماده‌سازی و تحویل</a>
      <a href="admin.php?page=archive" class="<?= $page=='archive'?'active':'' ?>"><i class="fa-solid fa-box-archive"></i> بایگانی <?php if($stats['archived']>0): ?><span class="b" style="background:#7c8893"><?= $stats['archived'] ?></span><?php endif; ?></a>
    </nav>

    <div class="section-title">بازاریابی</div>
    <nav>
      <a href="admin.php?page=flash_sales" class="<?= $page=='flash_sales'?'active':'' ?>"><i class="fa-solid fa-bolt"></i> تخفیف لحظه‌ای</a>
      <a href="admin.php?page=discount_codes" class="<?= $page=='discount_codes'?'active':'' ?>"><i class="fa-solid fa-ticket"></i> کدهای تخفیف <?php if($stats['discount_codes']>0): ?><span class="b" style="background:#9b59b6"><?= $stats['discount_codes'] ?></span><?php endif; ?></a>

      <a href="admin.php?page=custom_tabs" class="<?= $page=='custom_tabs'?'active':'' ?>"><i class="fa-solid fa-layer-group"></i> تب‌های سفارشی</a>
    </nav>

    <div class="section-title">انبار</div>
    <nav>
      <a href="admin.php?page=warehouses" class="<?= $page=='warehouses'?'active':'' ?>"><i class="fa-solid fa-warehouse"></i> انبارها</a>
      <a href="admin.php?page=stock" class="<?= $page=='stock'?'active':'' ?>"><i class="fa-solid fa-cubes"></i> موجودی انبار <?php if($stats['low_stock']>0): ?><span class="b" style="background:#f4a261"><?= $stats['low_stock'] ?></span><?php endif; ?></a>
      <a href="admin.php?page=transfer_new" class="<?= in_array($page,['transfer_new','transfers'])?'active':'' ?>"><i class="fa-solid fa-right-left"></i> حواله بین انبار</a>
    </nav>

    <div class="section-title">حسابداری</div>
    <nav>
      <a href="admin.php?page=capital" class="<?= $page=='capital'?'active':'' ?>"><i class="fa-solid fa-vault"></i> سرمایه و دارایی</a>
      <a href="admin.php?page=profit" class="<?= $page=='profit'?'active':'' ?>"><i class="fa-solid fa-chart-pie"></i> سود و زیان</a>
      <a href="admin.php?page=accounting" class="<?= $page=='accounting'?'active':'' ?>"><i class="fa-solid fa-money-bill-trend-up"></i> هزینه‌ها و درآمد</a>
      <a href="admin.php?page=customize" class="<?= $page=='customize'?'active':'' ?>"><i class="fa-solid fa-palette"></i> سفارشی‌سازی</a>
      <a href="admin.php?page=invoice_settings" class="<?= $page=='invoice_settings'?'active':'' ?>"><i class="fa-solid fa-print"></i> چاپ فاکتور</a>
      <a href="admin.php?page=settings" class="<?= $page=='settings'?'active':'' ?>"><i class="fa-solid fa-gear"></i> تنظیمات</a>
    </nav>

    <div class="section-title">سرویس</div>
    <nav>
      <?php 
        $__lic = license_info(); 
        $__unread = (int)$pdo->query("SELECT COUNT(*) c FROM ticket_messages WHERE sender='support' AND is_read_by_admin=0")->fetch()['c'];
      ?>
      <a href="admin.php?page=support" class="<?= in_array($page,['support','ticket_new','ticket_view'])?'active':'' ?>">
        <i class="fa-solid fa-headset"></i> پشتیبانی و تیکت
        <?php if($__unread>0): ?><span class="b" style="background:#e63946"><?= $__unread ?></span><?php endif; ?>
      </a>
      <a href="admin.php?page=subscription" class="<?= in_array($page,['subscription','renew'])?'active':'' ?>">
        <i class="fa-solid fa-id-card-clip"></i> وضعیت اشتراک
        <?php if(!$__lic['is_permanent'] && $__lic['days_left']!==null && $__lic['days_left']<=7): ?>
          <span class="b" style="background:<?= $__lic['days_left']<=0?'#e63946':'#f4a261' ?>"><?= max(0,$__lic['days_left']) ?></span>
        <?php endif; ?>
      </a>
    </nav>

    <nav>
      <a href="index.php" target="_blank"><i class="fa-solid fa-arrow-up-right-from-square"></i> مشاهده فروشگاه</a>
      <a href="admin.php?logout=1" class="logout-link"><i class="fa-solid fa-right-from-bracket"></i> خروج</a>
    </nav>
  </aside>
  <div class="overlay" id="overlay"></div>

  <div class="main">
    <div class="topbar">
      <div style="display:flex;align-items:center;gap:14px">
        <button class="menu-toggle" id="menuToggle"><i class="fa-solid fa-bars"></i></button>
        <h1>
          <?php
          $titles=[
            'dashboard'=>'داشبورد',
            'products'=>'مدیریت محصولات',
            'product_form'=>($edit_product?'ویرایش محصول':'افزودن محصول'),
            'categories'=>'دسته‌بندی‌ها',
            'orders'=>'سفارشات فعال',
            'archive'=>'بایگانی سفارشات',
            'warehouses'=>'مدیریت انبارها',
            'stock'=>'موجودی انبار',
            'transfer_new'=>'حواله جدید بین انبار',
            'transfers'=>'تاریخچه حواله‌ها',
            'profit'=>'گزارش سود و زیان',
            'accounting'=>'هزینه‌ها و درآمد',
            'capital'=>'سرمایه و دارایی',
            'flash_sales'=>'تخفیف‌های لحظه‌ای',
            'flash_sale_form'=>'تعریف تخفیف لحظه‌ای',
            'discount_codes'=>'کدهای تخفیف',
            'discount_code_form'=>'تعریف کد تخفیف',
            'fulfillment'=>'آماده‌سازی و تحویل سفارش',
            'custom_tabs'=>'تب‌های سفارشی',
            'custom_tab_form'=>'تعریف تب سفارشی',
            'customize'=>'سفارشی‌سازی',
            'settings'=>'تنظیمات فروشگاه',
            'support'=>'پشتیبانی سایت و تیکت‌ها',
            'ticket_new'=>'ثبت تیکت جدید',
            'ticket_view'=>'مشاهده تیکت',
            'subscription'=>'وضعیت اشتراک سرویس',
            'renew'=>'درخواست تمدید اشتراک',
            'invoice_settings'=>'تنظیمات چاپ فاکتور',
          ];
          echo $titles[$page] ?? 'پنل مدیریت';
          ?>
        </h1>
      </div>
      <div class="top-actions">
        <a href="index.php" target="_blank" class="view-site"><i class="fa-solid fa-eye"></i> مشاهده سایت</a>
      </div>
    </div>

    <div class="content">
      <?php if ($msg): ?>
        <div class="alert <?= $msg_type ?>"><i class="fa-solid fa-<?= $msg_type=='success'?'circle-check':'circle-exclamation' ?>"></i> <?= e($msg) ?></div>
      <?php endif; ?>

      <?php /* ============== DASHBOARD ============== */ if ($page=='dashboard'): ?>
        <div class="stats-grid">
          <div class="stat-card"><div class="ic" style="background:#e63946"><i class="fa-solid fa-box"></i></div><div class="info"><div class="num"><?= $stats['products'] ?></div><div class="lbl">محصولات</div></div></div>
          <div class="stat-card"><div class="ic" style="background:#457b9d"><i class="fa-solid fa-receipt"></i></div><div class="info"><div class="num"><?= $stats['orders'] ?></div><div class="lbl">سفارشات فعال</div></div></div>
          <div class="stat-card"><div class="ic" style="background:#f4a261"><i class="fa-solid fa-clock"></i></div><div class="info"><div class="num"><?= $stats['pending'] ?></div><div class="lbl">در انتظار</div></div></div>
          <div class="stat-card"><div class="ic" style="background:#2a9d8f"><i class="fa-solid fa-money-bill-wave"></i></div><div class="info"><div class="num sm"><?= toman($stats['revenue']) ?></div><div class="lbl">درآمد (تومان)</div></div></div>
          <div class="stat-card"><div class="ic" style="background:#1b6e57"><i class="fa-solid fa-coins"></i></div><div class="info"><div class="num sm"><?= toman($stats['profit']) ?></div><div class="lbl">سود خالص فروش</div></div></div>
          <div class="stat-card"><div class="ic" style="background:#9b59b6"><i class="fa-solid fa-vault"></i></div><div class="info"><div class="num sm"><?= toman($stats['capital_cost']) ?></div><div class="lbl">سرمایه در کالا</div></div></div>
          <div class="stat-card"><div class="ic" style="background:#d98324"><i class="fa-solid fa-ticket"></i></div><div class="info"><div class="num"><?= $stats['voucher_orders'] ?></div><div class="lbl">سفارش با کالابرگ</div></div></div>
          <div class="stat-card"><div class="ic" style="background:#e67e22"><i class="fa-solid fa-triangle-exclamation"></i></div><div class="info"><div class="num"><?= $stats['low_stock'] ?></div><div class="lbl">موجودی کم</div></div></div>
        </div>

        <div class="panel">
          <div class="panel-head"><h2><i class="fa-solid fa-chart-column"></i> آمار ۷ روز اخیر</h2></div>
          <div class="panel-body"><div style="height:320px"><canvas id="ordersChart"></canvas></div></div>
        </div>

        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(380px,1fr));gap:20px">
          <div class="panel">
            <div class="panel-head"><h2><i class="fa-solid fa-clock-rotate-left"></i> آخرین سفارشات</h2><a href="admin.php?page=orders" class="btn btn-secondary btn-sm">مشاهده همه</a></div>
            <div class="panel-body table-wrap">
              <table>
                <thead><tr><th>کد</th><th>مشتری</th><th>مبلغ</th><th>سود</th><th>پرداخت</th></tr></thead>
                <tbody>
                  <?php $recent=$pdo->query("SELECT * FROM orders ORDER BY id DESC LIMIT 5")->fetchAll(); ?>
                  <?php if($recent): foreach($recent as $o): ?>
                  <tr>
                    <td><strong><?= e($o['order_code']) ?></strong></td>
                    <td><?= e($o['customer_name']) ?></td>
                    <td><?= toman($o['total']) ?></td>
                    <td style="color:var(--green);font-weight:600"><?= toman($o['profit']) ?></td>
                    <td>
                      <?php if($o['payment_method']==='voucher'): ?>
                        <span class="tag tag-voucher"><i class="fa-solid fa-ticket"></i> کالابرگ</span>
                      <?php else: ?>
                        <span class="tag tag-on">نقدی</span>
                      <?php endif; ?>
                    </td>
                  </tr>
                  <?php endforeach; else: ?>
                  <tr><td colspan="5" style="text-align:center;color:#999;padding:30px">سفارشی ثبت نشده.</td></tr>
                  <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>

          <div class="panel">
            <div class="panel-head"><h2><i class="fa-solid fa-triangle-exclamation" style="color:#f4a261"></i> هشدار موجودی کم</h2><a href="admin.php?page=stock" class="btn btn-secondary btn-sm">موجودی</a></div>
            <div class="panel-body table-wrap">
              <table>
                <thead><tr><th>محصول</th><th>موجودی</th><th>حداقل</th><th>وضعیت</th></tr></thead>
                <tbody>
                <?php
                $main = main_warehouse_id();
                $low = $pdo->prepare("SELECT p.id,p.name,p.min_stock,s.quantity FROM products p JOIN stock s ON s.product_id=p.id AND s.warehouse_id=? WHERE p.is_active=1 AND s.quantity <= p.min_stock ORDER BY s.quantity ASC LIMIT 8");
                $low->execute([$main]);
                $rows = $low->fetchAll();
                ?>
                <?php if($rows): foreach($rows as $r): ?>
                  <tr>
                    <td><strong><?= e($r['name']) ?></strong></td>
                    <td><?= (int)$r['quantity'] ?></td>
                    <td><?= (int)$r['min_stock'] ?></td>
                    <td><?php if((int)$r['quantity']==0): ?><span class="tag tag-off">ناموجود</span><?php else: ?><span class="tag tag-low">کمبود</span><?php endif; ?></td>
                  </tr>
                <?php endforeach; else: ?>
                  <tr><td colspan="4" style="text-align:center;color:#999;padding:30px">همه محصولات موجودی کافی دارند ✓</td></tr>
                <?php endif; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>

      <?php /* ============== PRODUCTS ============== */ elseif ($page=='products'): ?>
        <div class="panel">
          <div class="panel-head">
            <h2><i class="fa-solid fa-box"></i> لیست محصولات (<?= count($all_products) ?>)</h2>
            <div style="display:flex;gap:10px;flex-wrap:wrap">
              <form class="search-mini" method="get">
                <input type="hidden" name="page" value="products">
                <input type="text" name="ps" placeholder="جستجو..." value="<?= e($prod_search) ?>">
                <button type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
              </form>
              <a href="admin.php?page=product_form" class="btn btn-primary"><i class="fa-solid fa-plus"></i> محصول جدید</a>
            </div>
          </div>
          <div class="panel-body table-wrap">
            <?php if($all_products): ?>
            <table>
              <thead><tr><th>تصویر</th><th>نام</th><th>دسته</th><th>قیمت فروش</th><th>بارکد/SKU</th><th>قیمت خرید</th><th>سود واحد</th><th>تخفیف</th><th>موجودی</th><th>عملیات</th></tr></thead>
              <tbody>
                <?php foreach($all_products as $p):
                  $eff = (!empty($p['discount_percent']) && $p['discount_percent']>0 && $p['discount_percent']<100)
                        ? (int)round($p['price']*(1-$p['discount_percent']/100))
                        : (($p['discount_price']>0 && $p['discount_price']<$p['price']) ? $p['discount_price'] : $p['price']);
                  $unit_profit = $eff - (int)$p['cost_price'];
                ?>
                <tr>
                  <td><?php if($p['image']): ?><img class="t-img" src="<?= e($p['image']) ?>" alt=""><?php else: ?><div class="t-noimg"><i class="fa-solid fa-image"></i></div><?php endif; ?></td>
                  <td><strong><?= e($p['name']) ?></strong></td>
                  <td><?= e($p['cat_name'] ?? '—') ?></td>
                  <td><?= toman($p['price']) ?></td>
                  <td style="font-size:12px"><?= $p['barcode'] ? e($p['barcode']) : '—' ?><?php if($p['sku']): ?><br><small style="color:#888">SKU: <?= e($p['sku']) ?></small><?php endif; ?></td>
                  <td style="color:#888"><?= $p['cost_price']>0 ? toman($p['cost_price']) : '—' ?></td>
                  <td style="color:<?= $unit_profit>0?'var(--green)':'var(--red)' ?>;font-weight:600"><?= $p['cost_price']>0 ? toman($unit_profit) : '—' ?></td>
                  <td>
                    <?php if(!empty($p['discount_percent']) && $p['discount_percent']>0): ?>
                      <span class="tag tag-off"><?= (int)$p['discount_percent'] ?>٪</span>
                    <?php elseif($p['discount_price']>0): ?>
                      <span class="tag tag-off"><?= toman($p['discount_price']) ?></span>
                    <?php else: ?>—<?php endif; ?>
                  </td>
                  <td>
                    <?php $s = get_stock($p['id']); ?>
                    <?php if($s<=0): ?><span style="color:var(--red)">ناموجود</span>
                    <?php elseif($s<=$p['min_stock']): ?><span class="tag tag-low"><?= $s ?> عدد</span>
                    <?php else: ?><?= $s ?><?php endif; ?>
                  </td>
                  <td style="white-space:nowrap">
                    <a href="admin.php?page=product_form&id=<?= $p['id'] ?>" class="btn btn-secondary btn-sm" title="ویرایش محصول"><i class="fa-solid fa-pen"></i> ویرایش</a>
                    <a href="admin.php?op=delete_product&id=<?= $p['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('محصول حذف شود؟')" title="حذف محصول"><i class="fa-solid fa-trash"></i> حذف</a>
                  </td>
                </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
            <?php else: ?><div class="empty"><i class="fa-solid fa-box-open"></i><p>محصولی یافت نشد.</p></div><?php endif; ?>
          </div>
        </div>

      <?php /* ============== PRODUCT FORM ============== */ elseif ($page=='product_form'): ?>
        <div class="panel">
          <div class="panel-head"><h2><i class="fa-solid fa-<?= $edit_product?'pen':'plus' ?>"></i> <?= $edit_product?'ویرایش محصول':'افزودن محصول جدید' ?></h2><a href="admin.php?page=products" class="btn btn-secondary btn-sm"><i class="fa-solid fa-arrow-right"></i> بازگشت</a></div>
          <div class="panel-body">
            <form method="post" enctype="multipart/form-data" action="admin.php?page=products" id="productForm">
              <input type="hidden" name="op" value="save_product">
              <input type="hidden" name="id" value="<?= $edit_product['id'] ?? 0 ?>">
              <input type="hidden" name="existing_image" value="<?= e($edit_product['image'] ?? '') ?>">

              <div class="form-row">
                <div class="form-group"><label>نام محصول *</label><input type="text" name="name" class="form-control" required value="<?= e($edit_product['name'] ?? '') ?>"></div>
                <div class="form-group"><label>دسته‌بندی</label>
                  <select name="category_id" class="form-control">
                    <option value="">— بدون دسته —</option>
                    <?php foreach($categories as $c): ?>
                    <option value="<?= $c['id'] ?>" <?= ($edit_product && $edit_product['category_id']==$c['id'])?'selected':'' ?>><?= e($c['name']) ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
              </div>

              <div class="form-row">
                <div class="form-group"><label>قیمت فروش (تومان) *</label><input type="number" name="price" id="priceInput" class="form-control" required value="<?= e($edit_product['price'] ?? '') ?>" oninput="calcProfit()"></div>
                <div class="form-group"><label>قیمت خرید (تومان) <span class="hint">برای محاسبه سود</span></label><input type="number" name="cost_price" id="costInput" class="form-control" value="<?= e($edit_product['cost_price'] ?? 0) ?>" oninput="calcProfit()"></div>
                <div class="form-group"><label>سود واحد <span class="hint" id="profitHint">—</span></label><input type="text" id="profitDisplay" class="form-control" readonly style="background:#f8f9fa;font-weight:700;color:var(--green)"></div>
              </div>

              <div class="form-row">
                <div class="form-group"><label>درصد تخفیف (%) <span class="hint">یا قیمت دستی</span></label><input type="number" name="discount_percent" id="discPct" class="form-control" min="0" max="99" value="<?= e($edit_product['discount_percent'] ?? 0) ?>" oninput="calcFinal()"></div>
                <div class="form-group"><label>قیمت تخفیف‌خورده <span class="hint" id="finalHint">—</span></label><input type="number" name="discount_price" id="discPrice" class="form-control" value="<?= e($edit_product['discount_price'] ?? 0) ?>" oninput="calcFromPrice()"></div>
                <div class="form-group"><label>موجودی انبار اصلی</label><input type="number" name="stock" class="form-control" value="<?= e($edit_product['stock'] ?? 0) ?>"></div>
                <div class="form-group"><label>حداقل موجودی <span class="hint">هشدار کمبود</span></label><input type="number" name="min_stock" class="form-control" value="<?= e($edit_product['min_stock'] ?? 5) ?>"></div>
              </div>

              <div class="form-group"><label>توضیحات</label><textarea name="description" class="form-control"><?= e($edit_product['description'] ?? '') ?></textarea></div>

              <div class="form-row">
                <div class="form-group">
                  <label>تصویر محصول (آپلود)</label>
                  <input type="file" name="image_file" class="form-control" accept="image/*">
                  <?php if(!empty($edit_product['image'])): ?><img class="img-preview" src="<?= e($edit_product['image']) ?>" alt=""><?php endif; ?>
                </div>
                <div class="form-group"><label>یا آدرس URL تصویر</label><input type="text" name="image_url" class="form-control" placeholder="https://..."></div>
              </div>

              <div class="form-group">
                <label>وضعیت‌ها</label>
                <div class="checkbox-row">
                  <label><input type="checkbox" name="is_featured" <?= ($edit_product && $edit_product['is_featured'])?'checked':'' ?>> محصول ویژه</label>
                  <label><input type="checkbox" name="is_active" <?= (!$edit_product || $edit_product['is_active'])?'checked':'' ?>> فعال (نمایش در فروشگاه)</label>
                </div>
              </div>

              <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> ذخیره محصول</button>
            </form>
          </div>
        </div>

        <div class="panel">
          <div class="panel-head"><h2><i class="fa-solid fa-calculator"></i> ماشین حساب سریع (محاسبه سود، تخفیف و حاشیه سود)</h2></div>
          <div class="panel-body" style="display:flex;gap:14px;flex-wrap:wrap;align-items:flex-end">
            <div class="form-group" style="margin:0;flex:1;min-width:140px">
              <label>قیمت فروش</label>
              <input type="number" id="qPrice" class="form-control" placeholder="100000" oninput="quickCalc()">
            </div>
            <div class="form-group" style="margin:0;flex:1;min-width:140px">
              <label>درصد تخفیف</label>
              <input type="number" id="qPct" class="form-control" placeholder="10" oninput="quickCalc()">
            </div>
            <div class="form-group" style="margin:0;flex:1;min-width:140px">
              <label>قیمت خرید</label>
              <input type="number" id="qCost" class="form-control" placeholder="70000" oninput="quickCalc()">
            </div>
            <div style="flex:2;min-width:220px;background:#f8f9fa;padding:12px 14px;border-radius:9px">
              <div style="font-size:12.5px;color:var(--muted)">قیمت نهایی: <strong id="qFinal" style="color:var(--primary);font-size:16px;display:block">—</strong></div>
              <div style="font-size:12.5px;color:var(--muted);margin-top:6px">سود هر واحد: <strong id="qProfit" style="color:var(--green);font-size:16px;display:block">—</strong></div>
              <div style="font-size:12.5px;color:var(--muted);margin-top:6px">درصد سود: <strong id="qMargin" style="color:var(--blue);font-size:16px;display:block">—</strong></div>
            </div>
          </div>
        </div>

      <?php /* ============== CATEGORIES ============== */ elseif ($page=='categories'): ?>
        <?php
        $ec=null; if(isset($_GET['edit'])){$st=$pdo->prepare("SELECT * FROM categories WHERE id=?");$st->execute([(int)$_GET['edit']]);$ec=$st->fetch();}
        ?>
        <div class="form-row" style="align-items:start">
          <div class="panel">
            <div class="panel-head"><h2><i class="fa-solid fa-plus"></i> افزودن / ویرایش دسته</h2></div>
            <div class="panel-body">
              <form method="post">
                <input type="hidden" name="op" value="save_category">
                <input type="hidden" name="cat_id" value="<?= $ec['id'] ?? 0 ?>">
                <div class="form-group"><label>نام دسته‌بندی</label><input type="text" name="cat_name" class="form-control" required value="<?= e($ec['name'] ?? '') ?>"></div>
                <div class="form-group"><label>ترتیب نمایش</label><input type="number" name="sort_order" class="form-control" value="<?= e($ec['sort_order'] ?? 0) ?>"></div>
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> ذخیره</button>
                <?php if($ec): ?><a href="admin.php?page=categories" class="btn btn-secondary">انصراف</a><?php endif; ?>
              </form>
            </div>
          </div>
          <div class="panel">
            <div class="panel-head"><h2><i class="fa-solid fa-tags"></i> لیست دسته‌بندی‌ها</h2></div>
            <div class="panel-body table-wrap">
              <?php if($categories): ?>
              <table>
                <thead><tr><th>نام</th><th>ترتیب</th><th>تعداد محصول</th><th>عملیات</th></tr></thead>
                <tbody>
                <?php foreach($categories as $c): $cnt=$pdo->prepare("SELECT COUNT(*) c FROM products WHERE category_id=?");$cnt->execute([$c['id']]);$cn=$cnt->fetch()['c']; ?>
                  <tr>
                    <td><strong><?= e($c['name']) ?></strong></td>
                    <td><?= $c['sort_order'] ?></td>
                    <td><?= $cn ?></td>
                    <td style="white-space:nowrap">
                      <a href="admin.php?page=categories&edit=<?= $c['id'] ?>" class="btn btn-secondary btn-sm"><i class="fa-solid fa-pen"></i> ویرایش</a>
                      <a href="admin.php?op=delete_category&id=<?= $c['id'] ?>&page=categories" class="btn btn-danger btn-sm" onclick="return confirm('حذف؟')"><i class="fa-solid fa-trash"></i> حذف</a>
                    </td>
                  </tr>
                <?php endforeach; ?>
                </tbody>
              </table>
              <?php else: ?><div class="empty"><i class="fa-solid fa-tags"></i><p>دسته‌ای وجود ندارد.</p></div><?php endif; ?>
            </div>
          </div>
        </div>

      <?php /* ============== ORDERS ============== */ elseif ($page=='orders'): ?>
        <div class="panel">
          <div class="panel-head">
            <h2><i class="fa-solid fa-receipt"></i> سفارشات فعال</h2>
            <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
              <div class="filter-tabs">
                <a href="admin.php?page=orders&status=all" class="<?= $order_filter=='all'?'active':'' ?>">همه</a>
                <a href="admin.php?page=orders&status=pending" class="<?= $order_filter=='pending'?'active':'' ?>">در انتظار</a>
                <a href="admin.php?page=orders&status=confirmed" class="<?= $order_filter=='confirmed'?'active':'' ?>">تأیید شده</a>
                <a href="admin.php?page=orders&status=delivered" class="<?= $order_filter=='delivered'?'active':'' ?>">تحویل شده</a>
                <a href="admin.php?page=orders&status=cancelled" class="<?= $order_filter=='cancelled'?'active':'' ?>">لغو شده</a>
              </div>
              <a href="admin.php?op=export_orders&status=<?= e($order_filter) ?>" class="btn btn-secondary btn-sm"><i class="fa-solid fa-file-csv"></i> خروجی CSV</a>
            </div>
          </div>
          <div class="panel-body table-wrap">
            <?php if($all_orders): ?>
            <table>
              <thead><tr><th>کد</th><th>مشتری</th><th>اقلام</th><th>مبلغ</th><th>سود</th><th>پرداخت</th><th>وضعیت</th><th>عملیات</th></tr></thead>
              <tbody>
                <?php foreach($all_orders as $o): $items=json_decode($o['items'],true) ?: []; ?>
                <tr>
                  <td><strong><?= e($o['order_code']) ?></strong><br><small style="color:#999"><?= e($o['created_at']) ?></small></td>
                  <td style="font-size:12.5px">
                    <strong><?= e($o['customer_name']) ?></strong><br>
                    <i class="fa-solid fa-phone" style="color:#999"></i> <?= e($o['phone']) ?><br>
                    <i class="fa-solid fa-location-dot" style="color:#999"></i> <?= e(mb_substr($o['address'],0,30)) ?>
                  </td>
                  <td class="order-items"><?php foreach($items as $it): ?><div>• <?= e($it['name']) ?> × <?= $it['qty'] ?></div><?php endforeach; ?></td>
                  <td style="white-space:nowrap"><strong><?= toman($o['total']) ?></strong>
                    <?php if($o['discount_amount']>0): ?><br><small style="color:var(--green)">تخفیف: -<?= toman($o['discount_amount']) ?></small><?php endif; ?>
                  </td>
                  <td style="color:var(--green);font-weight:700;white-space:nowrap"><?= toman($o['profit']) ?></td>
                  <td>
                    <?php if($o['payment_method']==='voucher'): ?>
                      <span class="tag tag-voucher"><i class="fa-solid fa-ticket"></i> کالابرگ</span>
                    <?php else: ?>
                      <span class="tag tag-on">نقدی</span>
                    <?php endif; ?>
                    <?php if($o['discount_code']): ?><br><small style="color:#9b59b6">کد: <?= e($o['discount_code']) ?></small><?php endif; ?>
                  </td>
                  <td><span class="badge" style="background:<?= $status_colors[$o['status']]??'#777' ?>"><?= $status_labels[$o['status']]??$o['status'] ?></span></td>
                  <td style="white-space:nowrap">
                    <?php if(!$o['is_paid']): ?>
                    <a href="admin.php?op=confirm_payment&id=<?= $o['id'] ?>&page=orders" class="btn btn-success btn-sm" onclick="return confirm('پرداخت تأیید شود؟')" title="تأیید پرداخت"><i class="fa-solid fa-check"></i> تایید پرداخت</a>
                    <?php endif; ?>
                    <form method="post" style="display:inline-block">
                      <input type="hidden" name="op" value="order_status">
                      <input type="hidden" name="id" value="<?= $o['id'] ?>">
                      <select name="status" class="form-control" style="padding:5px;font-size:12px;width:auto;display:inline-block" onchange="this.form.submit()">
                        <?php foreach($status_labels as $k=>$v): ?>
                        <option value="<?= $k ?>" <?= $o['status']==$k?'selected':'' ?>><?= $v ?></option>
                        <?php endforeach; ?>
                      </select>
                    </form>
                    <a href="invoice.php?id=<?= $o['id'] ?>&type=a4" target="_blank" class="btn btn-secondary btn-sm" title="چاپ فاکتور A4 رسمی" style="background:#1d3557;color:#fff"><i class="fa-solid fa-file-invoice"></i> A4</a>
                    <a href="invoice.php?id=<?= $o['id'] ?>&type=thermal" target="_blank" class="btn btn-secondary btn-sm" title="چاپ فیش حرارتی" style="background:#457b9d;color:#fff"><i class="fa-solid fa-receipt"></i> فیش</a>
                    <a href="admin.php?op=archive_order&id=<?= $o['id'] ?>&page=orders" class="btn btn-secondary btn-sm" onclick="return confirm('آرشیو شود؟')" title="انتقال به بایگانی"><i class="fa-solid fa-box-archive"></i> بایگانی</a>
                    <a href="admin.php?op=delete_order&id=<?= $o['id'] ?>&page=orders" class="btn btn-danger btn-sm" onclick="return confirm('حذف شود؟')" title="حذف سفارش"><i class="fa-solid fa-trash"></i> حذف</a>
                  </td>
                </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
            <?php else: ?><div class="empty"><i class="fa-solid fa-receipt"></i><p>سفارشی یافت نشد.</p></div><?php endif; ?>
          </div>
        </div>

      <?php /* ============== ARCHIVE ============== */ elseif ($page=='archive'): ?>
        <div class="panel">
          <div class="panel-head">
            <h2><i class="fa-solid fa-box-archive"></i> بایگانی سفارشات (<?= count($archived_orders) ?>)</h2>
            <div style="display:flex;gap:8px;flex-wrap:wrap;align-items:center">
              <div class="filter-tabs">
                <a href="admin.php?page=archive&astatus=all" class="<?= $archive_filter=='all'?'active':'' ?>">همه</a>
                <a href="admin.php?page=archive&astatus=delivered" class="<?= $archive_filter=='delivered'?'active':'' ?>">تحویل شده</a>
                <a href="admin.php?page=archive&astatus=cancelled" class="<?= $archive_filter=='cancelled'?'active':'' ?>">لغو شده</a>
              </div>
              <a href="admin.php?op=export_orders&archived=1&astatus=<?= e($archive_filter) ?>" class="btn btn-secondary btn-sm"><i class="fa-solid fa-file-csv"></i> خروجی CSV</a>
            </div>
          </div>
          <div class="panel-body">
            <div style="background:#fff3cd;color:#856404;padding:12px 16px;border-radius:10px;font-size:13px;margin-bottom:16px">
              <i class="fa-solid fa-circle-info"></i> سفارشات بسته‌شده برای پیگیری بلندمدت به بایگانی منتقل می‌شوند.
            </div>
            <div class="table-wrap">
              <?php if($archived_orders): ?>
              <table>
                <thead><tr><th>کد</th><th>مشتری</th><th>اقلام</th><th>مبلغ</th><th>سود</th><th>وضعیت</th><th>تاریخ بسته شدن</th><th>عملیات</th></tr></thead>
                <tbody>
                  <?php foreach($archived_orders as $o): $items=json_decode($o['items'],true) ?: []; ?>
                  <tr>
                    <td><strong><?= e($o['order_code']) ?></strong></td>
                    <td><strong><?= e($o['customer_name']) ?></strong><br><small><?= e($o['phone']) ?></small></td>
                    <td class="order-items"><?php foreach($items as $it): ?><div>• <?= e($it['name']) ?> × <?= $it['qty'] ?></div><?php endforeach; ?></td>
                    <td><strong><?= toman($o['total']) ?></strong></td>
                    <td style="color:var(--green)"><?= toman($o['profit']) ?></td>
                    <td><span class="badge" style="background:<?= $status_colors[$o['status']]??'#777' ?>"><?= $status_labels[$o['status']]??$o['status'] ?></span></td>
                    <td style="font-size:12px"><?= e($o['closed_at'] ?? '—') ?></td>
                    <td>
                      <a href="invoice.php?id=<?= $o['id'] ?>&type=a4" target="_blank" class="btn btn-secondary btn-sm" title="چاپ فاکتور A4 رسمی" style="background:#1d3557;color:#fff"><i class="fa-solid fa-file-invoice"></i> A4</a>
                      <a href="invoice.php?id=<?= $o['id'] ?>&type=thermal" target="_blank" class="btn btn-secondary btn-sm" title="چاپ فیش حرارتی" style="background:#457b9d;color:#fff"><i class="fa-solid fa-receipt"></i> فیش</a>
                      <a href="admin.php?op=unarchive_order&id=<?= $o['id'] ?>&page=archive" class="btn btn-success btn-sm" onclick="return confirm('خروج از بایگانی؟')" title="خروج از بایگانی"><i class="fa-solid fa-rotate-left"></i> بازگرداندن</a>
                      <a href="admin.php?op=delete_order&id=<?= $o['id'] ?>&page=archive" class="btn btn-danger btn-sm" onclick="return confirm('حذف برای همیشه؟')" title="حذف دائمی"><i class="fa-solid fa-trash"></i> حذف</a>
                    </td>
                  </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
              <?php else: ?><div class="empty"><i class="fa-solid fa-box-archive"></i><p>هنوز سفارشی بایگانی نشده.</p></div><?php endif; ?>
            </div>
          </div>
        </div>

      <?php /* ============== WAREHOUSES ============== */ elseif ($page=='warehouses'): ?>
        <?php
        $ew=null; if(isset($_GET['edit_wh'])){$st=$pdo->prepare("SELECT * FROM warehouses WHERE id=?");$st->execute([(int)$_GET['edit_wh']]);$ew=$st->fetch();}
        ?>
        <div class="form-row" style="align-items:start">
          <div class="panel">
            <div class="panel-head"><h2><i class="fa-solid fa-<?= $ew?'pen':'plus' ?>"></i> <?= $ew?'ویرایش انبار':'افزودن انبار' ?></h2></div>
            <div class="panel-body">
              <form method="post">
                <input type="hidden" name="op" value="save_warehouse">
                <input type="hidden" name="wh_id" value="<?= $ew['id'] ?? 0 ?>">
                <div class="form-group"><label>نام انبار</label><input type="text" name="wh_name" class="form-control" required value="<?= e($ew['name'] ?? '') ?>" placeholder="مثال: انبار اصلی"></div>
                <div class="form-group"><label>ترتیب نمایش</label><input type="number" name="sort_order" class="form-control" value="<?= e($ew['sort_order'] ?? 0) ?>"></div>
                <div class="form-group"><label>توضیحات</label><textarea name="note" class="form-control"><?= e($ew['note'] ?? '') ?></textarea></div>
                <div class="form-group">
                  <label>تنظیمات</label>
                  <div class="checkbox-row">
                    <label><input type="checkbox" name="is_main" <?= ($ew && $ew['is_main'])?'checked':'' ?>> انبار اصلی فروش (فقط یکی)</label>
                    <label><input type="checkbox" name="is_active" <?= (!$ew || $ew['is_active'])?'checked':'' ?>> فعال</label>
                  </div>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> ذخیره</button>
                <?php if($ew): ?><a href="admin.php?page=warehouses" class="btn btn-secondary">انصراف</a><?php endif; ?>
              </form>
            </div>
          </div>
          <div class="panel">
            <div class="panel-head"><h2><i class="fa-solid fa-warehouse"></i> لیست انبارها</h2></div>
            <div class="panel-body table-wrap">
              <?php if($warehouses): ?>
              <table>
                <thead><tr><th>نام</th><th>نوع</th><th>تعداد محصول</th><th>موجودی کل</th><th>عملیات</th></tr></thead>
                <tbody>
                <?php foreach($warehouses as $w):
                  $cnt = $pdo->prepare("SELECT COUNT(*) c, COALESCE(SUM(quantity),0) s FROM stock WHERE warehouse_id=?");
                  $cnt->execute([$w['id']]);
                  $cc = $cnt->fetch();
                ?>
                  <tr>
                    <td><strong><?= e($w['name']) ?></strong></td>
                    <td>
                      <?php if($w['is_main']): ?><span class="tag tag-main">انبار اصلی</span>
                      <?php else: ?><span class="tag tag-off2">فرعی</span><?php endif; ?>
                    </td>
                    <td><?= (int)$cc['c'] ?></td>
                    <td><?= toman((int)$cc['s']) ?></td>
                    <td style="white-space:nowrap">
                      <a href="admin.php?page=warehouses&edit_wh=<?= $w['id'] ?>" class="btn btn-secondary btn-sm"><i class="fa-solid fa-pen"></i> ویرایش</a>
                      <?php if(!$w['is_main']): ?>
                      <a href="admin.php?op=delete_warehouse&id=<?= $w['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('حذف؟')"><i class="fa-solid fa-trash"></i> حذف</a>
                      <?php endif; ?>
                    </td>
                  </tr>
                <?php endforeach; ?>
                </tbody>
              </table>
              <?php else: ?><div class="empty"><i class="fa-solid fa-warehouse"></i><p>انباری تعریف نشده.</p></div><?php endif; ?>
            </div>
          </div>
        </div>

      <?php /* ============== STOCK ============== */ elseif ($page=='stock'):
        $stock_wh = isset($_GET['wh']) ? (int)$_GET['wh'] : main_warehouse_id();
        $stock_wh_name = '';
        foreach($warehouses as $w) if($w['id']==$stock_wh) $stock_wh_name = $w['name'];
        $search_p = trim($_GET['sp'] ?? '');
        $sql = "SELECT p.*, s.quantity as stock_qty FROM products p LEFT JOIN stock s ON s.product_id=p.id AND s.warehouse_id=?";
        $params = [$stock_wh];
        if ($search_p !== '') { $sql .= " WHERE p.name LIKE ? OR (p.barcode IS NOT NULL AND p.barcode LIKE ?) OR (p.sku IS NOT NULL AND p.sku LIKE ?)"; $params[] = "%$search_p%"; $params[] = "%$search_p%"; $params[] = "%$search_p%"; }
        $sql .= " ORDER BY p.name";
        $st = $pdo->prepare($sql); $st->execute($params);
        $stock_list = $st->fetchAll();
      ?>
        <div class="panel">
          <div class="panel-head">
            <h2><i class="fa-solid fa-cubes"></i> موجودی انبار: <?= e($stock_wh_name) ?></h2>
            <form method="get" style="display:flex;gap:8px">
              <input type="hidden" name="page" value="stock">
              <select name="wh" class="form-control" style="width:auto" onchange="this.form.submit()">
                <?php foreach($warehouses as $w): ?>
                  <option value="<?= $w['id'] ?>" <?= $w['id']==$stock_wh?'selected':'' ?>><?= e($w['name']) ?><?= $w['is_main']?' (اصلی)':'' ?></option>
                <?php endforeach; ?>
              </select>
            </form>
          </div>
          <div class="panel-body">
            <form method="get" class="search-mini" style="margin-bottom:14px;max-width:380px">
              <input type="hidden" name="page" value="stock">
              <input type="hidden" name="wh" value="<?= $stock_wh ?>">
              <input type="text" name="sp" placeholder="جستجوی محصول..." value="<?= e($search_p) ?>">
              <button type="submit"><i class="fa-solid fa-magnifying-glass"></i></button>
            </form>
            <div class="table-wrap">
              <table>
              <thead><tr><th>#</th><th>نام محصول</th><th>بارکد/SKU</th><th>قیمت فروش</th><th>قیمت خرید</th><th>ارزش موجودی</th><th>موجودی فعلی</th><th>حداقل</th><th>وضعیت</th><th>عملیات</th></tr></thead>
              <tbody>
                <?php foreach($stock_list as $p):
                  $sq = (int)($p['stock_qty'] ?? 0);
                  $ms = (int)$p['min_stock'];
                  $value = $sq * (int)$p['price'];
                ?>
                  <tr>
                    <td style="color:#888"><?= $p['id'] ?></td>
                    <td><strong><?= e($p['name']) ?></strong></td>
                    <td style="font-size:12px"><?= $p['barcode'] ? e($p['barcode']) : '—' ?><?php if($p['sku']): ?><br><small style="color:#888">SKU: <?= e($p['sku']) ?></small><?php endif; ?></td>
                    <td><?= toman($p['price']) ?></td>
                    <td style="color:#888"><?= $p['cost_price']>0?toman($p['cost_price']):'—' ?></td>
                    <td style="color:var(--blue)"><?= $sq>0?toman($value):'—' ?></td>
                    <td><strong style="font-size:16px;color:<?= $sq<=0?'var(--red)':($sq<=$ms?'#f4a261':'var(--green)') ?>"><?= $sq ?></strong></td>
                    <td><?= $ms ?></td>
                    <td>
                      <?php if($sq<=0): ?><span class="tag tag-off">ناموجود</span>
                      <?php elseif($sq<=$ms): ?><span class="tag tag-low">کمبود</span>
                      <?php else: ?><span class="tag tag-on">موجود</span><?php endif; ?>
                    </td>
                    <td style="white-space:nowrap">
                      <button type="button" class="btn btn-success btn-sm" onclick="openAddStock(<?= $p['id'] ?>, <?= $stock_wh ?>, <?= htmlspecialchars(json_encode($p['name'], JSON_UNESCAPED_UNICODE|JSON_HEX_APOS|JSON_HEX_QUOT), ENT_QUOTES, 'UTF-8') ?>)" title="افزایش موجودی (خرید)"><i class="fa-solid fa-plus"></i> خرید</button>
                      <button type="button" class="btn btn-warning btn-sm" onclick="openAdjustStock(<?= $p['id'] ?>, <?= $stock_wh ?>, <?= $sq ?>, <?= htmlspecialchars(json_encode($p['name'], JSON_UNESCAPED_UNICODE|JSON_HEX_APOS|JSON_HEX_QUOT), ENT_QUOTES, 'UTF-8') ?>)" title="تعدیل موجودی"><i class="fa-solid fa-pen"></i> تعدیل</button>
                    </td>
                  </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
            </div>

            <h3 style="margin:24px 0 12px;font-size:16px"><i class="fa-solid fa-clock-rotate-left"></i> تاریخچه حرکات (۲۰ مورد اخیر)</h3>
            <div class="table-wrap">
              <table>
                <thead><tr><th>تاریخ</th><th>محصول</th><th>انبار</th><th>نوع</th><th>تعداد</th><th>قیمت واحد</th><th>توضیح</th></tr></thead>
                <tbody>
                <?php
                $mov = $pdo->query("SELECT m.*, p.name pname, w.name wname FROM stock_movements m LEFT JOIN products p ON p.id=m.product_id LEFT JOIN warehouses w ON w.id=m.warehouse_id ORDER BY m.id DESC LIMIT 20")->fetchAll();
                $type_labels = ['sale'=>'فروش','purchase'=>'خرید/افزایش','transfer_in'=>'حواله ورودی','transfer_out'=>'حواله خروجی','adjust'=>'تعدیل'];
                $type_colors = ['sale'=>'#e63946','purchase'=>'#2a9d8f','transfer_in'=>'#457b9d','transfer_out'=>'#9b59b6','adjust'=>'#f4a261'];
                foreach($mov as $m):
                ?>
                  <tr>
                    <td style="font-size:12px;white-space:nowrap"><?= e($m['created_at']) ?></td>
                    <td><?= e($m['pname'] ?? '—') ?></td>
                    <td><?= e($m['wname'] ?? '—') ?></td>
                    <td><span class="badge" style="background:<?= $type_colors[$m['type']]??'#777' ?>"><?= $type_labels[$m['type']]??$m['type'] ?></span></td>
                    <td style="font-weight:700;color:<?= in_array($m['type'],['sale','transfer_out'])?'var(--red)':'var(--green)' ?>"><?= in_array($m['type'],['sale','transfer_out'])?'-':'+' ?><?= (int)$m['quantity'] ?></td>
                    <td><?= $m['unit_price']>0 ? toman($m['unit_price']) : '—' ?></td>
                    <td style="font-size:12px;color:#666"><?= e($m['note']) ?></td>
                  </tr>
                <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>

        <div class="modal-bg" id="addStockModal" style="display:none">
          <div class="modal-box-inner">
            <h3 id="addStockTitle" style="margin-bottom:16px">افزایش موجودی</h3>
            <form method="post" action="admin.php?page=stock">
              <input type="hidden" name="op" value="add_stock">
              <input type="hidden" name="product_id" id="addStockProductId">
              <input type="hidden" name="warehouse_id" id="addStockWhId">
              <div class="form-group"><label>تعداد افزایش</label><input type="number" name="quantity" class="form-control" min="1" required></div>
              <div class="form-group"><label>قیمت خرید واحد (تومان)</label><input type="number" name="unit_price" class="form-control" value="0"></div>
              <div class="form-group"><label>توضیحات</label><input type="text" name="note" class="form-control" placeholder="مثلاً: خرید از تأمین‌کننده"></div>
              <div style="display:flex;gap:8px">
                <button type="submit" class="btn btn-success"><i class="fa-solid fa-check"></i> ثبت</button>
                <button type="button" class="btn btn-secondary" onclick="document.getElementById('addStockModal').style.display='none'">انصراف</button>
              </div>
            </form>
          </div>
        </div>

        <div class="modal-bg" id="adjustStockModal" style="display:none">
          <div class="modal-box-inner">
            <h3 id="adjustStockTitle" style="margin-bottom:16px">تعدیل موجودی</h3>
            <form method="post" action="admin.php?page=stock">
              <input type="hidden" name="op" value="adjust_stock">
              <input type="hidden" name="product_id" id="adjustStockProductId">
              <input type="hidden" name="warehouse_id" id="adjustStockWhId">
              <div class="form-group"><label>موجودی جدید (نه تعداد تغییر)</label><input type="number" name="new_quantity" id="adjustStockNew" class="form-control" min="0" required></div>
              <div class="form-group"><label>توضیحات</label><input type="text" name="note" class="form-control" placeholder="دلیل تعدیل"></div>
              <div style="display:flex;gap:8px">
                <button type="submit" class="btn btn-warning"><i class="fa-solid fa-check"></i> ثبت</button>
                <button type="button" class="btn btn-secondary" onclick="document.getElementById('adjustStockModal').style.display='none'">انصراف</button>
              </div>
            </form>
          </div>
        </div>

        <style>
        .modal-bg{position:fixed;inset:0;background:rgba(0,0,0,.55);z-index:300;align-items:center;justify-content:center;padding:16px;display:flex;}
        .modal-box-inner{background:#fff;border-radius:18px;width:100%;max-width:420px;padding:24px;}
        </style>

        <script>
        function openAddStock(pid, wid, name){
          document.getElementById('addStockProductId').value = pid;
          document.getElementById('addStockWhId').value = wid;
          document.getElementById('addStockTitle').textContent = 'افزایش موجودی: ' + name;
          document.getElementById('addStockModal').style.display = 'flex';
        }
        function openAdjustStock(pid, wid, current, name){
          document.getElementById('adjustStockProductId').value = pid;
          document.getElementById('adjustStockWhId').value = wid;
          document.getElementById('adjustStockNew').value = current;
          document.getElementById('adjustStockTitle').textContent = 'تعدیل موجودی: ' + name;
          document.getElementById('adjustStockModal').style.display = 'flex';
        }
        </script>

      <?php /* ============== TRANSFER ============== */ elseif ($page=='transfer_new'):
        $all_p = $pdo->query("SELECT p.*, s.quantity as stock_qty FROM products p LEFT JOIN stock s ON s.product_id=p.id AND s.warehouse_id=".main_warehouse_id()." ORDER BY p.name")->fetchAll();
      ?>
        <div class="panel">
          <div class="panel-head"><h2><i class="fa-solid fa-right-left"></i> ایجاد حواله جدید</h2><a href="admin.php?page=transfers" class="btn btn-secondary btn-sm"><i class="fa-solid fa-clock-rotate-left"></i> تاریخچه</a></div>
          <div class="panel-body">
            <form method="post" action="admin.php" id="transferForm">
              <input type="hidden" name="op" value="create_transfer">
              <div class="form-row">
                <div class="form-group">
                  <label>از انبار (مبدأ) *</label>
                  <select name="from_warehouse_id" id="fromWh" class="form-control" required onchange="updateTransferOptions()">
                    <option value="">انتخاب...</option>
                    <?php foreach($warehouses as $w): if(!$w['is_active']) continue; ?>
                      <option value="<?= $w['id'] ?>"><?= e($w['name']) ?><?= $w['is_main']?' (اصلی)':'' ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
                <div class="form-group">
                  <label>به انبار (مقصد) *</label>
                  <select name="to_warehouse_id" id="toWh" class="form-control" required>
                    <option value="">انتخاب...</option>
                    <?php foreach($warehouses as $w): if(!$w['is_active']) continue; ?>
                      <option value="<?= $w['id'] ?>"><?= e($w['name']) ?><?= $w['is_main']?' (اصلی)':'' ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
              </div>

              <h3 style="margin:18px 0 10px;font-size:15px">اقلام حواله</h3>
              <div id="transferItems"></div>
              <button type="button" class="btn btn-secondary btn-sm" onclick="addTransferRow()" style="margin-top:8px"><i class="fa-solid fa-plus"></i> افزودن قلم</button>

              <div class="form-group" style="margin-top:18px">
                <label>توضیحات</label>
                <textarea name="note" class="form-control" placeholder="مثلاً: انتقال برای نمایشگاه"></textarea>
              </div>

              <button type="submit" class="btn btn-primary" id="submitTransfer"><i class="fa-solid fa-paper-plane"></i> ثبت حواله</button>
            </form>
          </div>
        </div>
        <script>
        let tIdx = 0;
        const products = <?php
          $pl = [];
          foreach($all_p as $ap) $pl[] = ['id'=>$ap['id'], 'name'=>$ap['name'], 'stock'=>$ap['stock_qty']??0];
          echo json_encode($pl, JSON_UNESCAPED_UNICODE);
        ?>;
        function addTransferRow(){
          const div = document.createElement('div');
          div.className = 'transfer-row form-row';
          div.style = 'grid-template-columns:2fr 1fr auto;align-items:end;margin-bottom:10px';
          div.innerHTML = `
            <div class="form-group" style="margin:0">
              <select name="items[${tIdx}][product_id]" class="form-control" required onchange="updateRowStock(this)">
                <option value="">انتخاب کنید...</option>
                ${products.map(p=>`<option value="${p.id}" data-stock="${p.stock}">${p.name} (موجودی: ${p.stock})</option>`).join('')}
              </select>
            </div>
            <div class="form-group" style="margin:0">
              <input type="number" name="items[${tIdx}][quantity]" class="form-control" min="1" required placeholder="تعداد" oninput="validateRow(this)">
            </div>
            <button type="button" class="btn btn-danger btn-sm" onclick="this.closest('.transfer-row').remove()"><i class="fa-solid fa-trash"></i></button>
          `;
          document.getElementById('transferItems').appendChild(div);
          tIdx++;
        }
        function updateRowStock(sel){
          const opt = sel.options[sel.selectedIndex];
          const stock = opt.dataset.stock || 0;
          const row = sel.closest('.transfer-row');
          const qtyInput = row.querySelector('input[type=number]');
          qtyInput.max = stock;
          qtyInput.placeholder = 'حداکثر ' + stock;
        }
        function validateRow(inp){
          const row = inp.closest('.transfer-row');
          const sel = row.querySelector('select');
          const opt = sel.options[sel.selectedIndex];
          const stock = parseInt(opt.dataset.stock || 0);
          const qty = parseInt(inp.value || 0);
          if (qty > stock) {
            inp.style.borderColor = '#e63946';
            inp.value = stock;
          } else {
            inp.style.borderColor = '';
          }
        }
        function updateTransferOptions(){
          // می‌توان فیلتر کرد ولی ساده می‌گذاریم
        }
        addTransferRow();

        document.getElementById('transferForm').addEventListener('submit', (e)=>{
          const from = document.getElementById('fromWh').value;
          const to = document.getElementById('toWh').value;
          if (from === to && from !== '') {
            e.preventDefault();
            alert('انبار مبدأ و مقصد نمی‌توانند یکسان باشند.');
          }
          let valid = true;
          document.querySelectorAll('.transfer-row').forEach(row => {
            const sel = row.querySelector('select');
            const qty = row.querySelector('input[type=number]');
            const opt = sel.options[sel.selectedIndex];
            const stock = parseInt(opt.dataset.stock || 0);
            if (parseInt(qty.value || 0) > stock) {
              qty.style.borderColor = '#e63946';
              valid = false;
            }
          });
          if (!valid) {
            e.preventDefault();
            alert('تعداد برخی اقلام از موجودی مبدأ بیشتر است.');
          }
        });
        </script>

      <?php elseif ($page=='transfers'):
        $transfers = $pdo->query("
          SELECT m.*, p.name pname, w1.name from_name, w2.name to_name
          FROM stock_movements m
          LEFT JOIN products p ON p.id=m.product_id
          LEFT JOIN warehouses w1 ON w1.id=m.from_warehouse_id
          LEFT JOIN warehouses w2 ON w2.id=m.to_warehouse_id
          WHERE m.type IN ('transfer_in','transfer_out')
          ORDER BY m.id DESC LIMIT 100
        ")->fetchAll();
        $grouped = [];
        foreach($transfers as $t) {
          $key = $t['created_at'].'_'.$t['product_id'].'_'.$t['from_warehouse_id'].'_'.$t['to_warehouse_id'];
          if (!isset($grouped[$key])) $grouped[$key] = $t;
        }
      ?>
        <div class="panel">
          <div class="panel-head"><h2><i class="fa-solid fa-clock-rotate-left"></i> تاریخچه حواله‌ها</h2><a href="admin.php?page=transfer_new" class="btn btn-primary btn-sm"><i class="fa-solid fa-plus"></i> حواله جدید</a></div>
          <div class="panel-body table-wrap">
            <?php if($grouped): ?>
            <table>
              <thead><tr><th>تاریخ</th><th>محصول</th><th>از انبار</th><th>به انبار</th><th>تعداد</th><th>توضیح</th></tr></thead>
              <tbody>
                <?php foreach($grouped as $t): ?>
                <tr>
                  <td style="font-size:12px;white-space:nowrap"><?= e($t['created_at']) ?></td>
                  <td><strong><?= e($t['pname']) ?></strong></td>
                  <td><?= e($t['from_name'] ?? '—') ?></td>
                  <td><?= e($t['to_name'] ?? '—') ?></td>
                  <td style="font-weight:700"><?= (int)$t['quantity'] ?></td>
                  <td style="font-size:12px;color:#666"><?= e($t['note']) ?></td>
                </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
            <?php else: ?><div class="empty"><i class="fa-solid fa-right-left"></i><p>هنوز حواله‌ای ثبت نشده.</p></div><?php endif; ?>
          </div>
        </div>

      <?php /* ============== PROFIT ============== */ elseif ($page=='profit'):
        $date_from = $_GET['from'] ?? date('Y-m-01');
        $date_to = $_GET['to'] ?? date('Y-m-d');
        $paid_only = isset($_GET['paid']) ? 1 : 0;
        $where = "date(created_at) BETWEEN ? AND ?";
        $params = [$date_from, $date_to];
        if ($paid_only) $where .= " AND is_paid=1";
        $sum_row = $pdo->prepare("SELECT COALESCE(SUM(total),0) total, COALESCE(SUM(subtotal),0) subtotal, COALESCE(SUM(discount_amount),0) disc, COALESCE(SUM(cost_total),0) cost, COALESCE(SUM(profit),0) profit, COUNT(*) cnt FROM orders WHERE $where");
        $sum_row->execute($params);
        $sum = $sum_row->fetch();
        $prods = $pdo->query("SELECT id, name, price, cost_price FROM products ORDER BY name")->fetchAll();
        $prod_stats = [];
        foreach($prods as $p) {
          $prod_stats[$p['id']] = ['name'=>$p['name'], 'qty'=>0, 'revenue'=>0, 'cost'=>0, 'profit'=>0];
        }
        $orders_in_range = $pdo->prepare("SELECT items, is_paid FROM orders WHERE $where");
        $orders_in_range->execute($params);
        foreach($orders_in_range->fetchAll() as $o) {
          if (!$paid_only && !$o['is_paid']) continue;
          $items = json_decode($o['items'], true) ?: [];
          foreach($items as $it) {
            $pid = (int)$it['id'];
            if (!isset($prod_stats[$pid])) continue;
            $prod_stats[$pid]['qty'] += (int)$it['qty'];
            $prod_stats[$pid]['revenue'] += (int)$it['price'] * (int)$it['qty'];
            $prod_stats[$pid]['cost'] += (int)($it['cost_price'] ?? 0) * (int)$it['qty'];
          }
        }
        foreach($prod_stats as &$ps) {
          $ps['profit'] = $ps['revenue'] - $ps['cost'];
        }
        unset($ps);
        usort($prod_stats, fn($a,$b) => $b['profit'] <=> $a['profit']);
        $exp = $pdo->prepare("SELECT COALESCE(SUM(amount),0) s FROM expenses WHERE expense_date BETWEEN ? AND ?");
        $exp->execute([$date_from, $date_to]);
        $expense_total = (int)$exp->fetch()['s'];
      ?>
        <div class="panel">
          <div class="panel-head"><h2><i class="fa-solid fa-chart-pie"></i> گزارش سود و زیان</h2></div>
          <div class="panel-body">
            <form method="get" class="form-row" style="align-items:end;margin-bottom:20px">
              <input type="hidden" name="page" value="profit">
              <div class="form-group" style="margin:0"><label>از تاریخ</label><input type="date" name="from" class="form-control" value="<?= e($date_from) ?>"></div>
              <div class="form-group" style="margin:0"><label>تا تاریخ</label><input type="date" name="to" class="form-control" value="<?= e($date_to) ?>"></div>
              <div class="form-group" style="margin:0">
                <label>&nbsp;</label>
                <label style="display:flex;align-items:center;gap:6px"><input type="checkbox" name="paid" value="1" <?= $paid_only?'checked':'' ?>> فقط پرداخت‌شده‌ها</label>
              </div>
              <div class="form-group" style="margin:0"><button class="btn btn-primary"><i class="fa-solid fa-filter"></i> اعمال</button></div>
            </form>

            <div class="stats-grid" style="margin-bottom:20px">
              <div class="stat-card"><div class="ic" style="background:#457b9d"><i class="fa-solid fa-receipt"></i></div><div class="info"><div class="num"><?= (int)$sum['cnt'] ?></div><div class="lbl">تعداد سفارش</div></div></div>
              <div class="stat-card"><div class="ic" style="background:#2a9d8f"><i class="fa-solid fa-money-bill-wave"></i></div><div class="info"><div class="num sm"><?= toman($sum['subtotal']) ?></div><div class="lbl">جمع فروش ناخالص</div></div></div>
              <div class="stat-card"><div class="ic" style="background:#9b59b6"><i class="fa-solid fa-tag"></i></div><div class="info"><div class="num sm"><?= toman($sum['disc']) ?></div><div class="lbl">تخفیف داده‌شده</div></div></div>
              <div class="stat-card"><div class="ic" style="background:#2a9d8f"><i class="fa-solid fa-bag-shopping"></i></div><div class="info"><div class="num sm"><?= toman($sum['total']) ?></div><div class="lbl">درآمد خالص</div></div></div>
              <div class="stat-card"><div class="ic" style="background:#f4a261"><i class="fa-solid fa-box"></i></div><div class="info"><div class="num sm"><?= toman($sum['cost']) ?></div><div class="lbl">بهای تمام‌شده</div></div></div>
              <div class="stat-card"><div class="ic" style="background:#1b6e57"><i class="fa-solid fa-coins"></i></div><div class="info"><div class="num sm"><?= toman($sum['profit']) ?></div><div class="lbl">سود ناخالص فروش</div></div></div>
              <div class="stat-card"><div class="ic" style="background:#e63946"><i class="fa-solid fa-money-bill-trend-down"></i></div><div class="info"><div class="num sm"><?= toman($expense_total) ?></div><div class="lbl">هزینه‌های ثبت‌شده</div></div></div>
              <div class="stat-card" style="background:linear-gradient(135deg,#1b6e57,#2a9d8f);color:#fff">
                <div class="ic" style="background:rgba(255,255,255,.25)"><i class="fa-solid fa-trophy"></i></div>
                <div class="info"><div class="num sm" style="color:#fff"><?= toman($sum['profit'] - $expense_total) ?></div><div class="lbl" style="color:rgba(255,255,255,.85)">سود خالص (پس از هزینه)</div></div>
              </div>
            </div>

            <h3 style="margin-bottom:12px;font-size:16px"><i class="fa-solid fa-list"></i> سود به تفکیک محصول</h3>
            <div class="table-wrap">
              <table>
                <thead><tr><th>محصول</th><th>تعداد فروش</th><th>درآمد</th><th>بهای تمام‌شده</th><th>سود</th><th>حاشیه سود</th></tr></thead>
                <tbody>
                <?php foreach($prod_stats as $ps):
                  if ($ps['qty']==0 && $ps['revenue']==0) continue;
                  $margin = $ps['revenue']>0 ? round($ps['profit']/$ps['revenue']*100,1) : 0;
                ?>
                  <tr>
                    <td><strong><?= e($ps['name']) ?></strong></td>
                    <td><?= $ps['qty'] ?></td>
                    <td><?= toman($ps['revenue']) ?></td>
                    <td style="color:#888"><?= toman($ps['cost']) ?></td>
                    <td style="color:<?= $ps['profit']>=0?'var(--green)':'var(--red)' ?>;font-weight:700"><?= toman($ps['profit']) ?></td>
                    <td><?= $margin ?>٪</td>
                  </tr>
                <?php endforeach; ?>
                </tbody>
              </table>
            </div>
          </div>
        </div>

      <?php /* ============== CAPITAL ============== */ elseif ($page=='capital'):
        $main_wh = main_warehouse_id();
        $warehouses_cap = $pdo->query("SELECT w.*, COALESCE(SUM(s.quantity * p.cost_price),0) cost_value, COALESCE(SUM(s.quantity * p.price),0) sell_value, COALESCE(SUM(s.quantity),0) total_qty FROM warehouses w LEFT JOIN stock s ON s.warehouse_id=w.id LEFT JOIN products p ON p.id=s.product_id GROUP BY w.id ORDER BY w.is_main DESC, w.sort_order")->fetchAll();
        $total_cost = 0; $total_sell = 0; $total_qty = 0;
        foreach($warehouses_cap as $w) { $total_cost += (int)$w['cost_value']; $total_sell += (int)$w['sell_value']; $total_qty += (int)$w['total_qty']; }
        $paid_orders_total = (int)$pdo->query("SELECT COALESCE(SUM(total),0) s FROM orders WHERE is_paid=1")->fetch()['s'];
        $total_expenses = (int)$pdo->query("SELECT COALESCE(SUM(amount),0) s FROM expenses")->fetch()['s'];
        $total_profit = (int)$pdo->query("SELECT COALESCE(SUM(profit),0) s FROM orders WHERE is_paid=1")->fetch()['s'];
        $cash_box = $paid_orders_total - $total_expenses;
      ?>
        <div class="panel">
          <div class="panel-head"><h2><i class="fa-solid fa-vault"></i> سرمایه، دارایی و صندوق</h2></div>
          <div class="panel-body">
            <div class="stats-grid" style="margin-bottom:20px">
              <div class="stat-card"><div class="ic" style="background:#9b59b6"><i class="fa-solid fa-boxes-stacked"></i></div><div class="info"><div class="num sm"><?= toman($total_cost) ?></div><div class="lbl">ارزش موجودی به قیمت خرید</div></div></div>
              <div class="stat-card"><div class="ic" style="background:#2a9d8f"><i class="fa-solid fa-tags"></i></div><div class="info"><div class="num sm"><?= toman($total_sell) ?></div><div class="lbl">ارزش موجودی به قیمت فروش</div></div></div>
              <div class="stat-card" style="background:linear-gradient(135deg,#1b6e57,#2a9d8f);color:#fff">
                <div class="ic" style="background:rgba(255,255,255,.25)"><i class="fa-solid fa-arrow-trend-up"></i></div>
                <div class="info"><div class="num sm" style="color:#fff"><?= toman($total_sell - $total_cost) ?></div><div class="lbl" style="color:rgba(255,255,255,.85)">سود بالقوه فروش موجودی</div></div>
              </div>
              <div class="stat-card"><div class="ic" style="background:#1b6e57"><i class="fa-solid fa-money-bill-wave"></i></div><div class="info"><div class="num sm"><?= toman($paid_orders_total) ?></div><div class="lbl">مجموع فروش نقدی</div></div></div>
              <div class="stat-card"><div class="ic" style="background:#e63946"><i class="fa-solid fa-money-bill-trend-down"></i></div><div class="info"><div class="num sm"><?= toman($total_expenses) ?></div><div class="lbl">مجموع هزینه‌ها</div></div></div>
              <div class="stat-card" style="background:linear-gradient(135deg,#e67e22,#d98324);color:#fff">
                <div class="ic" style="background:rgba(255,255,255,.25)"><i class="fa-solid fa-vault"></i></div>
                <div class="info"><div class="num sm" style="color:#fff"><?= toman($cash_box) ?></div><div class="lbl" style="color:rgba(255,255,255,.85)">صندوق (نقدی - هزینه)</div></div>
              </div>
              <div class="stat-card"><div class="ic" style="background:#d98324"><i class="fa-solid fa-ticket"></i></div><div class="info"><div class="num sm"><?= toman($voucher_balance) ?></div><div class="lbl">مانده کالابرگ‌ها</div></div></div>
              <div class="stat-card"><div class="ic" style="background:#f4a261"><i class="fa-solid fa-coins"></i></div><div class="info"><div class="num sm"><?= toman($total_profit) ?></div><div class="lbl">سود محقق‌شده فروش</div></div></div>
            </div>

            <h3 style="margin-bottom:12px;font-size:16px"><i class="fa-solid fa-warehouse"></i> ارزش موجودی به تفکیک انبار</h3>
            <div class="table-wrap" style="margin-bottom:20px">
              <table>
                <thead><tr><th>انبار</th><th>نوع</th><th>تعداد کل کالا</th><th>ارزش به قیمت خرید</th><th>ارزش به قیمت فروش</th><th>سود بالقوه</th></tr></thead>
                <tbody>
                  <?php foreach($warehouses_cap as $w):
                    $cv = (int)$w['cost_value']; $sv = (int)$w['sell_value']; $tq = (int)$w['total_qty'];
                  ?>
                  <tr>
                    <td><strong><?= e($w['name']) ?></strong></td>
                    <td><?php if($w['is_main']): ?><span class="tag tag-main">اصلی</span><?php else: ?><span class="tag tag-off2">فرعی</span><?php endif; ?></td>
                    <td><?= number_format($tq) ?></td>
                    <td><?= toman($cv) ?></td>
                    <td style="color:var(--green)"><?= toman($sv) ?></td>
                    <td style="color:var(--blue);font-weight:700"><?= toman($sv-$cv) ?></td>
                  </tr>
                  <?php endforeach; ?>
                  <tr style="background:#f8f9fb;font-weight:800">
                    <td colspan="2">جمع کل</td>
                    <td><?= number_format($total_qty) ?></td>
                    <td><?= toman($total_cost) ?></td>
                    <td style="color:var(--green)"><?= toman($total_sell) ?></td>
                    <td style="color:var(--blue)"><?= toman($total_sell-$total_cost) ?></td>
                  </tr>
                </tbody>
              </table>
            </div>

            <h3 style="margin-bottom:12px;font-size:16px"><i class="fa-solid fa-list-check"></i> ترازنامه</h3>
            <div class="form-row" style="grid-template-columns:1fr 1fr">
              <div style="background:#e7f5ee;padding:16px;border-radius:10px">
                <h4 style="color:#1b6e57;margin-bottom:10px"><i class="fa-solid fa-plus-circle"></i> دارایی‌ها</h4>
                <table style="width:100%">
                  <tr><td>ارزش موجودی کالا (به خرید)</td><td style="text-align:left;font-weight:700"><?= toman($total_cost) ?></td></tr>
                  <tr><td>صندوق (نقدینگی)</td><td style="text-align:left;font-weight:700"><?= toman(max(0,$cash_box)) ?></td></tr>
                  <tr><td>مانده کالابرگ‌های صادرشده</td><td style="text-align:left;font-weight:700"><?= toman($voucher_balance) ?></td></tr>
                  <tr style="border-top:2px solid #1b6e57"><td><strong>جمع دارایی</strong></td><td style="text-align:left;font-weight:800"><?= toman($total_cost + max(0,$cash_box) + $voucher_balance) ?></td></tr>
                </table>
              </div>
              <div style="background:#fde8e8;padding:16px;border-radius:10px">
                <h4 style="color:#c0392b;margin-bottom:10px"><i class="fa-solid fa-minus-circle"></i> بدهی‌ها و تعهدات</h4>
                <table style="width:100%">
                  <tr><td>سفارشات معلق (دریافت نشده)</td><td style="text-align:left;font-weight:700"><?= toman((int)$pdo->query("SELECT COALESCE(SUM(total),0) s FROM orders WHERE status NOT IN ('delivered','cancelled') AND is_paid=0")->fetch()['s']) ?></td></tr>
                  <tr><td>مجموع هزینه‌های ثبت‌شده</td><td style="text-align:left;font-weight:700"><?= toman($total_expenses) ?></td></tr>
                  <tr><td>کالابرگ‌های استفاده‌شده (هزینه‌شده)</td><td style="text-align:left;font-weight:700"><?= toman($voucher_used_total) ?></td></tr>
                  <tr style="border-top:2px solid #c0392b"><td><strong>جمع تعهدات</strong></td><td style="text-align:left;font-weight:800"><?= toman($total_expenses + $voucher_used_total) ?></td></tr>
                </table>
              </div>
            </div>
          </div>
        </div>

      <?php /* ============== ACCOUNTING ============== */ elseif ($page=='accounting'):
        $expenses = $pdo->query("SELECT * FROM expenses ORDER BY expense_date DESC, id DESC LIMIT 50")->fetchAll();
        $total_exp = $pdo->query("SELECT COALESCE(SUM(amount),0) s FROM expenses")->fetch()['s'];
        $total_inc = $pdo->query("SELECT COALESCE(SUM(total),0) s FROM orders WHERE is_paid=1")->fetch()['s'];
        $total_profit = $pdo->query("SELECT COALESCE(SUM(profit),0) s FROM orders WHERE is_paid=1")->fetch()['s'];
        // گروه‌بندی هزینه‌ها
        $exp_by_cat = $pdo->query("SELECT category, COALESCE(SUM(amount),0) total FROM expenses GROUP BY category ORDER BY total DESC")->fetchAll();
      ?>
        <div class="stats-grid">
          <div class="stat-card"><div class="ic" style="background:#2a9d8f"><i class="fa-solid fa-arrow-up"></i></div><div class="info"><div class="num sm"><?= toman($total_inc) ?></div><div class="lbl">کل درآمد</div></div></div>
          <div class="stat-card"><div class="ic" style="background:#1b6e57"><i class="fa-solid fa-coins"></i></div><div class="info"><div class="num sm"><?= toman($total_profit) ?></div><div class="lbl">سود خالص فروش</div></div></div>
          <div class="stat-card"><div class="ic" style="background:#e63946"><i class="fa-solid fa-arrow-down"></i></div><div class="info"><div class="num sm"><?= toman($total_exp) ?></div><div class="lbl">کل هزینه‌ها</div></div></div>
          <div class="stat-card" style="background:linear-gradient(135deg,#1b6e57,#2a9d8f);color:#fff">
            <div class="ic" style="background:rgba(255,255,255,.25)"><i class="fa-solid fa-wallet"></i></div>
            <div class="info"><div class="num sm" style="color:#fff"><?= toman($total_profit - $total_exp) ?></div><div class="lbl" style="color:rgba(255,255,255,.85)">تراز کل</div></div>
          </div>
        </div>

        <div class="form-row" style="align-items:start">
          <div class="panel">
            <div class="panel-head"><h2><i class="fa-solid fa-plus"></i> ثبت هزینه</h2></div>
            <div class="panel-body">
              <form method="post">
                <input type="hidden" name="op" value="save_expense">
                <div class="form-group"><label>عنوان *</label><input type="text" name="title" class="form-control" required placeholder="مثال: اجاره، حقوق"></div>
                <div class="form-group"><label>مبلغ (تومان) *</label><input type="number" name="amount" class="form-control" min="1" required></div>
                <div class="form-group"><label>دسته‌بندی</label>
                  <select name="category" class="form-control">
                    <option value="عمومی">عمومی</option>
                    <option value="اجاره">اجاره</option>
                    <option value="حقوق">حقوق</option>
                    <option value="خرید کالا">خرید کالا</option>
                    <option value="حمل و نقل">حمل و نقل</option>
                    <option value="تبلیغات">تبلیغات</option>
                    <option value="قبوض">قبوض</option>
                    <option value="سایر">سایر</option>
                  </select>
                </div>
                <div class="form-group"><label>تاریخ</label><input type="date" name="expense_date" class="form-control" value="<?= date('Y-m-d') ?>"></div>
                <div class="form-group"><label>توضیحات</label><textarea name="note" class="form-control"></textarea></div>
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> ثبت</button>
              </form>
            </div>
          </div>

          <div class="panel" style="grid-column:span 2">
            <div class="panel-head"><h2><i class="fa-solid fa-chart-bar"></i> هزینه بر اساس دسته</h2></div>
            <div class="panel-body">
              <?php if($exp_by_cat): ?>
                <?php $max_exp = max(array_column($exp_by_cat, 'total')); ?>
                <?php foreach($exp_by_cat as $e): ?>
                  <div style="margin-bottom:12px">
                    <div style="display:flex;justify-content:space-between;font-size:13px;margin-bottom:4px">
                      <span><?= e($e['category']) ?></span>
                      <strong><?= toman($e['total']) ?></strong>
                    </div>
                    <div style="background:#f0f2f5;height:10px;border-radius:5px;overflow:hidden">
                      <div style="background:linear-gradient(90deg,var(--primary),#ff7e5f);height:100%;width:<?= $max_exp>0?($e['total']/$max_exp*100):0 ?>%"></div>
                    </div>
                  </div>
                <?php endforeach; ?>
              <?php else: ?>
                <p style="text-align:center;color:#999">هنوز هزینه‌ای ثبت نشده.</p>
              <?php endif; ?>
            </div>
          </div>
        </div>

        <div class="panel">
          <div class="panel-head"><h2><i class="fa-solid fa-list"></i> لیست هزینه‌ها</h2></div>
          <div class="panel-body table-wrap">
            <?php if($expenses): ?>
            <table>
              <thead><tr><th>تاریخ</th><th>عنوان</th><th>دسته</th><th>مبلغ</th><th>توضیحات</th><th>عملیات</th></tr></thead>
              <tbody>
                <?php foreach($expenses as $e): ?>
                <tr>
                  <td style="white-space:nowrap"><?= e($e['expense_date']) ?></td>
                  <td><strong><?= e($e['title']) ?></strong></td>
                  <td><span class="tag tag-off2"><?= e($e['category'] ?? '—') ?></span></td>
                  <td style="color:var(--red);font-weight:700"><?= toman($e['amount']) ?></td>
                  <td style="font-size:12px;color:#666"><?= e($e['note']) ?></td>
                  <td>
                    <a href="admin.php?op=delete_expense&id=<?= $e['id'] ?>&page=accounting" class="btn btn-danger btn-sm" onclick="return confirm('حذف؟')"><i class="fa-solid fa-trash"></i> حذف</a>
                  </td>
                </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
            <?php else: ?><div class="empty"><i class="fa-solid fa-money-bill"></i><p>هزینه‌ای ثبت نشده.</p></div><?php endif; ?>
          </div>
        </div>

      <?php /* ============== FLASH SALES ============== */ elseif ($page=='flash_sales'):
        $fs = $pdo->query("SELECT f.*, p.name pname FROM flash_sales f JOIN products p ON p.id=f.product_id ORDER BY f.id DESC")->fetchAll();
        $now_date = date('Y-m-d H:i:s');
      ?>
        <div class="panel">
          <div class="panel-head">
            <h2><i class="fa-solid fa-bolt"></i> تخفیف‌های لحظه‌ای (<?= count($fs) ?>)</h2>
            <a href="admin.php?page=flash_sale_form" class="btn btn-primary"><i class="fa-solid fa-plus"></i> تخفیف جدید</a>
          </div>
          <div class="panel-body table-wrap">
            <?php if($fs): ?>
            <table>
              <thead><tr><th>محصول</th><th>تخفیف</th><th>شروع</th><th>پایان</th><th>وضعیت</th><th>عملیات</th></tr></thead>
              <tbody>
                <?php foreach($fs as $f):
                  $active = $f['is_active'] && $f['starts_at']<=$now_date && $f['ends_at']>=$now_date;
                  $expired = $f['ends_at'] < $now_date;
                  $upcoming = $f['starts_at'] > $now_date;
                ?>
                <tr>
                  <td><strong><?= e($f['pname']) ?></strong></td>
                  <td>
                    <?php if($f['discount_percent']>0): ?>
                      <span class="tag tag-off"><?= (int)$f['discount_percent'] ?>٪</span>
                    <?php else: ?>
                      <span class="tag tag-off"><?= toman($f['discount_price']) ?></span>
                    <?php endif; ?>
                  </td>
                  <td style="font-size:12px"><?= e($f['starts_at']) ?></td>
                  <td style="font-size:12px"><?= e($f['ends_at']) ?></td>
                  <td>
                    <?php if($active): ?><span class="tag tag-on">فعال</span>
                    <?php elseif($expired): ?><span class="tag tag-off2">منقضی</span>
                    <?php elseif($upcoming): ?><span class="tag tag-low">شروع نشده</span>
                    <?php else: ?><span class="tag tag-off">غیرفعال</span><?php endif; ?>
                  </td>
                  <td style="white-space:nowrap">
                    <a href="admin.php?page=flash_sale_form&id=<?= $f['id'] ?>" class="btn btn-secondary btn-sm"><i class="fa-solid fa-pen"></i> ویرایش</a>
                    <a href="admin.php?op=delete_flash_sale&id=<?= $f['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('حذف؟')"><i class="fa-solid fa-trash"></i> حذف</a>
                  </td>
                </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
            <?php else: ?><div class="empty"><i class="fa-solid fa-bolt"></i><p>هنوز تخفیف لحظه‌ای تعریف نشده.</p></div><?php endif; ?>
          </div>
        </div>

      <?php elseif ($page=='flash_sale_form'):
        $ef = null;
        if (isset($_GET['id'])) {
          $st = $pdo->prepare("SELECT * FROM flash_sales WHERE id=?");
          $st->execute([(int)$_GET['id']]);
          $ef = $st->fetch();
        }
        $all_p = $pdo->query("SELECT id, name, price FROM products WHERE is_active=1 ORDER BY name")->fetchAll();
        $default_start = date('Y-m-d\T00:00');
        $default_end = date('Y-m-d\T23:59', strtotime('+1 day'));
      ?>
        <div class="panel">
          <div class="panel-head"><h2><i class="fa-solid fa-bolt"></i> <?= $ef?'ویرایش':'تعریف' ?> تخفیف لحظه‌ای</h2><a href="admin.php?page=flash_sales" class="btn btn-secondary btn-sm"><i class="fa-solid fa-arrow-right"></i> بازگشت</a></div>
          <div class="panel-body">
            <form method="post" action="admin.php?page=flash_sales">
              <input type="hidden" name="op" value="save_flash_sale">
              <input type="hidden" name="fs_id" value="<?= $ef['id'] ?? 0 ?>">
              <div class="form-row">
                <div class="form-group">
                  <label>محصول *</label>
                  <select name="product_id" class="form-control" required>
                    <option value="">انتخاب...</option>
                    <?php foreach($all_p as $p): ?>
                      <option value="<?= $p['id'] ?>" <?= ($ef && $ef['product_id']==$p['id'])?'selected':'' ?>>
                        <?= e($p['name']) ?> - <?= toman($p['price']) ?>
                      </option>
                    <?php endforeach; ?>
                  </select>
                </div>
                <div class="form-group"><label>درصد تخفیف (%) <span class="hint">یا قیمت دستی</span></label><input type="number" name="discount_percent" class="form-control" min="1" max="99" value="<?= e($ef['discount_percent'] ?? '') ?>"></div>
                <div class="form-group"><label>قیمت تخفیف‌خورده (تومان)</label><input type="number" name="discount_price" class="form-control" value="<?= e($ef['discount_price'] ?? '') ?>"></div>
              </div>
              <div class="form-row">
                <div class="form-group"><label>زمان شروع *</label><input type="datetime-local" name="starts_at" class="form-control" required value="<?= e(str_replace(' ','T',$ef['starts_at'] ?? $default_start)) ?>"></div>
                <div class="form-group"><label>زمان پایان *</label><input type="datetime-local" name="ends_at" class="form-control" required value="<?= e(str_replace(' ','T',$ef['ends_at'] ?? $default_end)) ?>"></div>
              </div>
              <div class="form-group">
                <label><input type="checkbox" name="is_active" <?= (!$ef || $ef['is_active'])?'checked':'' ?>> فعال</label>
              </div>
              <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> ذخیره</button>
            </form>
          </div>
        </div>

      <?php /* ============== DISCOUNT CODES ============== */ elseif ($page=='discount_codes'):
        $codes = $pdo->query("SELECT * FROM discount_codes ORDER BY id DESC")->fetchAll();
      ?>
        <div class="panel">
          <div class="panel-head">
            <h2><i class="fa-solid fa-ticket"></i> کدهای تخفیف (<?= count($codes) ?>)</h2>
            <a href="admin.php?page=discount_code_form" class="btn btn-primary"><i class="fa-solid fa-plus"></i> کد جدید</a>
          </div>
          <div class="panel-body table-wrap">
            <?php if($codes): ?>
            <table>
              <thead><tr><th>کد</th><th>نوع</th><th>مقدار</th><th>حداقل</th><th>استفاده</th><th>شروع</th><th>پایان</th><th>وضعیت</th><th>عملیات</th></tr></thead>
              <tbody>
                <?php foreach($codes as $c):
                  $now_d = date('Y-m-d H:i:s');
                  $expired = $c['ends_at'] && $c['ends_at'] < $now_d;
                  $upcoming = $c['starts_at'] && $c['starts_at'] > $now_d;
                  $used_full = $c['max_uses']>0 && $c['current_uses']>=$c['max_uses'];
                ?>
                <tr>
                  <td><strong style="font-family:monospace;font-size:14px"><?= e($c['code']) ?></strong></td>
                  <td><?php if($c['type']==='percent'): ?><span class="tag tag-on">درصدی</span><?php else: ?><span class="tag tag-feat">مبلغی</span><?php endif; ?></td>
                  <td><strong><?= $c['type']==='percent' ? $c['value'].'٪' : toman($c['value']) ?></strong></td>
                  <td><?= $c['min_order']>0 ? toman($c['min_order']) : '—' ?></td>
                  <td>
                    <?= (int)$c['current_uses'] ?> / <?= $c['max_uses']>0 ? $c['max_uses'] : '∞' ?>
                    <?php if($used_full): ?><br><span class="tag tag-off">تکمیل</span><?php endif; ?>
                  </td>
                  <td style="font-size:11px"><?= e($c['starts_at'] ?? '—') ?></td>
                  <td style="font-size:11px"><?= e($c['ends_at'] ?? '—') ?></td>
                  <td>
                    <?php if(!$c['is_active']): ?><span class="tag tag-off">غیرفعال</span>
                    <?php elseif($expired): ?><span class="tag tag-off2">منقضی</span>
                    <?php elseif($upcoming): ?><span class="tag tag-low">شروع نشده</span>
                    <?php elseif($used_full): ?><span class="tag tag-off">تکمیل</span>
                    <?php else: ?><span class="tag tag-on">فعال</span><?php endif; ?>
                  </td>
                  <td style="white-space:nowrap">
                    <a href="admin.php?page=discount_code_form&id=<?= $c['id'] ?>" class="btn btn-secondary btn-sm"><i class="fa-solid fa-pen"></i> ویرایش</a>
                    <a href="admin.php?op=delete_discount_code&id=<?= $c['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('کد و تمام سوابق استفاده حذف شوند؟')"><i class="fa-solid fa-trash"></i> حذف</a>
                  </td>
                </tr>
                <?php endforeach; ?>
              </tbody>
            </table>
            <?php else: ?><div class="empty"><i class="fa-solid fa-ticket"></i><p>هنوز کدی تعریف نشده.</p></div><?php endif; ?>
          </div>
        </div>

      <?php elseif ($page=='discount_code_form'):
        $ed = null;
        if (isset($_GET['id'])) {
          $st = $pdo->prepare("SELECT * FROM discount_codes WHERE id=?");
          $st->execute([(int)$_GET['id']]);
          $ed = $st->fetch();
        }
        $all_p = $pdo->query("SELECT id, name FROM products WHERE is_active=1 ORDER BY name")->fetchAll();
      ?>
        <div class="panel">
          <div class="panel-head"><h2><i class="fa-solid fa-ticket"></i> <?= $ed?'ویرایش':'تعریف' ?> کد تخفیف</h2><a href="admin.php?page=discount_codes" class="btn btn-secondary btn-sm"><i class="fa-solid fa-arrow-right"></i> بازگشت</a></div>
          <div class="panel-body">
            <form method="post" action="admin.php?page=discount_codes">
              <input type="hidden" name="op" value="save_discount_code">
              <input type="hidden" name="dc_id" value="<?= $ed['id'] ?? 0 ?>">
              <div class="form-row">
                <div class="form-group"><label>کد تخفیف * <span class="hint">(به حروف بزرگ تبدیل می‌شود)</span></label><input type="text" name="code" class="form-control" required value="<?= e($ed['code'] ?? '') ?>" placeholder="مثال: TAVALOD1403"></div>
                <div class="form-group"><label>نوع تخفیف *</label>
                  <select name="dc_type" class="form-control">
                    <option value="percent" <?= ($ed && $ed['type']==='percent')?'selected':'' ?>>درصدی (%)</option>
                    <option value="amount" <?= ($ed && $ed['type']==='amount')?'selected':'' ?>>مبلغ ثابت (تومان)</option>
                  </select>
                </div>
                <div class="form-group"><label>مقدار تخفیف *</label><input type="number" name="dc_value" class="form-control" required min="1" value="<?= e($ed['value'] ?? '') ?>"></div>
              </div>
              <div class="form-row">
                <div class="form-group"><label>حداقل مبلغ سفارش (تومان) <span class="hint">0 = بدون حداقل</span></label><input type="number" name="min_order" class="form-control" min="0" value="<?= e($ed['min_order'] ?? 0) ?>"></div>
                <div class="form-group"><label>سقف استفاده کل <span class="hint">0 = نامحدود</span></label><input type="number" name="max_uses" class="form-control" min="0" value="<?= e($ed['max_uses'] ?? 0) ?>"></div>
                <div class="form-group"><label>سقف استفاده هر مشتری <span class="hint">0 = نامحدود</span></label><input type="number" name="max_per_customer" class="form-control" min="0" value="<?= e($ed['max_per_customer'] ?? 0) ?>"></div>
              </div>
              <div class="form-row">
                <div class="form-group"><label>زمان شروع <span class="hint">خالی = از همین الان</span></label><input type="datetime-local" name="starts_at" class="form-control" value="<?= e($ed['starts_at'] ? str_replace(' ','T',substr($ed['starts_at'],0,16)) : '') ?>"></div>
                <div class="form-group"><label>زمان پایان <span class="hint">خالی = بدون انقضا</span></label><input type="datetime-local" name="ends_at" class="form-control" value="<?= e($ed['ends_at'] ? str_replace(' ','T',substr($ed['ends_at'],0,16)) : '') ?>"></div>
              </div>
              <div class="form-group">
                <label>اعمال بر روی:</label>
                <select name="applies_to" class="form-control" onchange="document.getElementById('catSel').style.display=this.value==='category'?'':'none';document.getElementById('prodSel').style.display=this.value==='product'?'':'none'">
                  <option value="all" <?= (!$ed || $ed['applies_to']==='all')?'selected':'' ?>>همه محصولات</option>
                  <option value="category" <?= ($ed && $ed['applies_to']==='category')?'selected':'' ?>>یک دسته‌بندی خاص</option>
                  <option value="product" <?= ($ed && $ed['applies_to']==='product')?'selected':'' ?>>یک محصول خاص</option>
                </select>
              </div>
              <div class="form-group" id="catSel" style="display:<?= ($ed && $ed['applies_to']==='category')?'':'none' ?>">
                <label>دسته‌بندی</label>
                <select name="category_id" class="form-control">
                  <option value="">انتخاب...</option>
                  <?php foreach($categories as $c): ?>
                    <option value="<?= $c['id'] ?>" <?= ($ed && $ed['category_id']==$c['id'])?'selected':'' ?>><?= e($c['name']) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="form-group" id="prodSel" style="display:<?= ($ed && $ed['applies_to']==='product')?'':'none' ?>">
                <label>محصول</label>
                <select name="product_id" class="form-control">
                  <option value="">انتخاب...</option>
                  <?php foreach($all_p as $p): ?>
                    <option value="<?= $p['id'] ?>" <?= ($ed && $ed['product_id']==$p['id'])?'selected':'' ?>><?= e($p['name']) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="form-group">
                <label><input type="checkbox" name="first_order_only" <?= ($ed && $ed['first_order_only'])?'checked':'' ?>> فقط برای اولین سفارش هر مشتری</label>
              </div>
              <div class="form-group">
                <label><input type="checkbox" name="is_active" <?= (!$ed || $ed['is_active'])?'checked':'' ?>> فعال</label>
              </div>
              <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> ذخیره</button>
            </form>
          </div>
        </div>

      <?php /* ============== FULFILLMENT (آماده‌سازی و تحویل) ============== */ elseif ($page=='fulfillment'):
        // فیلتر وضعیت
        $ff_status = $_GET['status'] ?? 'active'; // active = pending+confirmed+preparing+ready
        $ff_search = trim($_GET['q'] ?? '');
        $ff_payment = $_GET['payment'] ?? '';

        $where = ["o.is_archived=0"];
        $params = [];
        if ($ff_status === 'active') {
            $where[] = "o.status IN ('pending','confirmed','preparing','ready')";
        } elseif ($ff_status !== 'all') {
            $where[] = "o.status=?";
            $params[] = $ff_status;
        }
        if ($ff_search !== '') {
            $where[] = "(o.order_code LIKE ? OR o.customer_name LIKE ? OR o.phone LIKE ? OR o.address LIKE ?)";
            $like = '%' . $ff_search . '%';
            array_push($params, $like, $like, $like, $like);
        }
        if ($ff_payment !== '') {
            $where[] = "o.payment_method=?";
            $params[] = $ff_payment;
        }
        $where_sql = implode(' AND ', $where);

        // شمارنده‌ها برای تب‌ها
        $ff_counts = [];
        $ff_counts['active'] = (int)$pdo->query("SELECT COUNT(*) c FROM orders WHERE is_archived=0 AND status IN ('pending','confirmed','preparing','ready')")->fetch()['c'];
        $ff_counts['pending'] = (int)$pdo->query("SELECT COUNT(*) c FROM orders WHERE is_archived=0 AND status='pending'")->fetch()['c'];
        $ff_counts['confirmed'] = (int)$pdo->query("SELECT COUNT(*) c FROM orders WHERE is_archived=0 AND status='confirmed'")->fetch()['c'];
        $ff_counts['preparing'] = (int)$pdo->query("SELECT COUNT(*) c FROM orders WHERE is_archived=0 AND status='preparing'")->fetch()['c'];
        $ff_counts['ready'] = (int)$pdo->query("SELECT COUNT(*) c FROM orders WHERE is_archived=0 AND status='ready'")->fetch()['c'];
        $ff_counts['delivered'] = (int)$pdo->query("SELECT COUNT(*) c FROM orders WHERE is_archived=0 AND status='delivered'")->fetch()['c'];

        $st = $pdo->prepare("SELECT o.* FROM orders o WHERE $where_sql ORDER BY
            CASE o.status
                WHEN 'pending' THEN 1
                WHEN 'confirmed' THEN 2
                WHEN 'preparing' THEN 3
                WHEN 'ready' THEN 4
                WHEN 'delivered' THEN 5
                WHEN 'cancelled' THEN 6
                ELSE 7
            END, o.id DESC");
        $st->execute($params);
        $ff_orders = $st->fetchAll();
      ?>
        <style>
        .fulfillment-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(420px,1fr));gap:16px;}
        .ff-card{background:#fff;border-radius:14px;box-shadow:0 2px 10px rgba(0,0,0,.05);overflow:hidden;border:1px solid var(--border);transition:all .2s ease;}
        .ff-card:hover{box-shadow:0 6px 18px rgba(0,0,0,.08);}
        .ff-card .ff-head{padding:14px 16px;background:linear-gradient(135deg,#fafbfc,#f0f2f5);border-bottom:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;}
        .ff-card .ff-code{font-family:monospace;font-size:16px;font-weight:700;color:var(--primary);direction:ltr;}
        .ff-card .ff-date{font-size:11.5px;color:var(--muted);}
        .ff-card .ff-status{padding:4px 10px;border-radius:14px;font-size:12px;font-weight:700;color:#fff;}
        .ff-card .ff-customer{padding:12px 16px;border-bottom:1px solid var(--border);background:#fafbfc;}
        .ff-card .ff-customer .name{font-weight:700;font-size:14.5px;margin-bottom:4px;}
        .ff-card .ff-customer .meta{font-size:12.5px;color:var(--muted);line-height:1.9;}
        .ff-card .ff-customer .meta i{width:16px;color:var(--primary);}
        .ff-card .ff-items{padding:6px 16px;background:#fff;}
        .ff-item{display:flex;align-items:center;gap:10px;padding:9px 0;border-bottom:1px solid #f0f0f0;font-size:13.5px;}
        .ff-item:last-child{border-bottom:none;}
        .ff-item .chk{width:22px;height:22px;flex-shrink:0;cursor:pointer;accent-color:var(--green);transform:scale(1.15);}
        .ff-item.checked .name{text-decoration:line-through;color:#aaa;}
        .ff-item .info{flex:1;min-width:0;}
        .ff-item .name{font-weight:600;}
        .ff-item .sub{font-size:11.5px;color:var(--muted);margin-top:2px;display:flex;gap:8px;flex-wrap:wrap;}
        .ff-item .qty{background:#f0f2f5;padding:2px 8px;border-radius:8px;font-weight:600;}
        .ff-item .price{font-weight:700;color:var(--primary);white-space:nowrap;font-size:13px;}
        .ff-card .ff-foot{padding:12px 16px;background:#fafbfc;border-top:1px solid var(--border);display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;}
        .ff-card .ff-total{font-weight:800;color:var(--primary);font-size:15px;}
        .ff-card .ff-actions{display:flex;gap:6px;flex-wrap:wrap;}
        .ff-card .ff-actions .btn{padding:6px 12px;font-size:12px;}
        .ff-progress{height:5px;background:#f0f2f5;border-radius:3px;margin:8px 16px 0;overflow:hidden;}
        .ff-progress .bar{height:100%;background:linear-gradient(90deg,var(--green),#27ae60);transition:width .3s;}
        .ff-card .note{background:#fff3cd;color:#856404;padding:8px 12px;font-size:12.5px;margin:8px 16px;border-radius:8px;line-height:1.6;}
        .ff-card .pm-badge{display:inline-block;padding:3px 9px;border-radius:10px;font-size:11px;font-weight:600;}
        .ff-card .pm-cod{background:#e7f5ee;color:#1b6e57;}
        .ff-card .pm-voucher{background:#fff3e0;color:#a86200;}
        .ff-filter-bar{background:#fff;padding:14px 18px;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.05);margin-bottom:16px;display:flex;gap:10px;flex-wrap:wrap;align-items:center;}
        .ff-filter-bar input,.ff-filter-bar select{padding:8px 12px;border:1px solid var(--border);border-radius:8px;font-size:13px;font-family:inherit;outline:none;}
        .ff-filter-bar input{flex:1;min-width:180px;}
        .ff-filter-bar input:focus,.ff-filter-bar select:focus{border-color:var(--primary);}
        .ff-tab-bar{display:flex;gap:6px;background:#fff;padding:8px;border-radius:12px;box-shadow:0 2px 8px rgba(0,0,0,.05);margin-bottom:14px;overflow-x:auto;flex-wrap:wrap;}
        .ff-tab-bar a{padding:8px 14px;border-radius:8px;text-decoration:none;color:var(--muted);font-weight:600;font-size:13px;display:inline-flex;align-items:center;gap:6px;white-space:nowrap;}
        .ff-tab-bar a.active{background:var(--primary);color:#fff;}
        .ff-tab-bar a:not(.active):hover{background:#f0f2f5;color:var(--text);}
        .ff-tab-bar a .c{background:rgba(255,255,255,.25);padding:1px 8px;border-radius:10px;font-size:11px;}
        .ff-tab-bar a:not(.active) .c{background:#f0f2f5;color:var(--muted);}
        @media(max-width:700px){.fulfillment-grid{grid-template-columns:1fr;}}
        </style>

        <div class="ff-tab-bar">
          <a href="admin.php?page=fulfillment&status=active" class="<?= $ff_status==='active'?'active':'' ?>"><i class="fa-solid fa-bag-shopping"></i> فعال <span class="c"><?= $ff_counts['active'] ?></span></a>
          <a href="admin.php?page=fulfillment&status=pending" class="<?= $ff_status==='pending'?'active':'' ?>"><i class="fa-solid fa-hourglass-half"></i> در انتظار <span class="c"><?= $ff_counts['pending'] ?></span></a>
          <a href="admin.php?page=fulfillment&status=confirmed" class="<?= $ff_status==='confirmed'?'active':'' ?>"><i class="fa-solid fa-circle-check"></i> تأیید شده <span class="c"><?= $ff_counts['confirmed'] ?></span></a>
          <a href="admin.php?page=fulfillment&status=preparing" class="<?= $ff_status==='preparing'?'active':'' ?>"><i class="fa-solid fa-box-open"></i> در حال آماده <span class="c"><?= $ff_counts['preparing'] ?></span></a>
          <a href="admin.php?page=fulfillment&status=ready" class="<?= $ff_status==='ready'?'active':'' ?>"><i class="fa-solid fa-truck"></i> آماده ارسال <span class="c"><?= $ff_counts['ready'] ?></span></a>
          <a href="admin.php?page=fulfillment&status=delivered" class="<?= $ff_status==='delivered'?'active':'' ?>"><i class="fa-solid fa-flag-checkered"></i> تحویل شده <span class="c"><?= $ff_counts['delivered'] ?></span></a>
        </div>

        <form method="get" class="ff-filter-bar">
          <input type="hidden" name="page" value="fulfillment">
          <input type="hidden" name="status" value="<?= e($ff_status) ?>">
          <input type="text" name="q" placeholder="جستجو: کد سفارش، نام، موبایل یا آدرس..." value="<?= e($ff_search) ?>">
          <select name="payment">
            <option value="">همه روش‌های پرداخت</option>
            <option value="cod" <?= $ff_payment==='cod'?'selected':'' ?>>نقدی</option>
            <option value="voucher" <?= $ff_payment==='voucher'?'selected':'' ?>>کالابرگ</option>
          </select>
          <button type="submit" class="btn btn-primary btn-sm"><i class="fa-solid fa-search"></i> جستجو</button>
          <?php if($ff_search || $ff_payment): ?>
            <a href="admin.php?page=fulfillment&status=<?= e($ff_status) ?>" class="btn btn-secondary btn-sm"><i class="fa-solid fa-xmark"></i> حذف فیلتر</a>
          <?php endif; ?>
          <div style="margin-right:auto;font-size:12.5px;color:var(--muted)"><i class="fa-solid fa-circle-info"></i> تعداد: <strong style="color:var(--primary)"><?= count($ff_orders) ?></strong> سفارش</div>
        </form>

        <?php if ($msg && $page==='fulfillment'): ?>
          <div class="alert <?= $msg_type ?>"><i class="fa-solid fa-<?= $msg_type=='success'?'circle-check':'circle-exclamation' ?>"></i> <?= e($msg) ?></div>
        <?php endif; ?>

        <?php if($ff_orders): ?>
        <div class="fulfillment-grid">
          <?php foreach($ff_orders as $o):
            $items = json_decode($o['items'], true) ?: [];
            $items_total = array_sum(array_column($items, 'qty'));
          ?>
          <div class="ff-card" id="ff-<?= (int)$o['id'] ?>">
            <div class="ff-head">
              <div>
                <div class="ff-code"><?= e($o['order_code']) ?></div>
                <div class="ff-date"><i class="fa-regular fa-clock"></i> <?= e($o['created_at']) ?></div>
              </div>
              <div style="display:flex;flex-direction:column;align-items:flex-end;gap:4px">
                <span class="ff-status" style="background:<?= $status_colors[$o['status']]??'#777' ?>"><?= $status_labels[$o['status']]??$o['status'] ?></span>
                <span class="pm-badge <?= $o['payment_method']==='voucher'?'pm-voucher':'pm-cod' ?>"><?= $o['payment_method']==='voucher'?'کالابرگ':'نقدی' ?></span>
              </div>
            </div>

            <div class="ff-customer">
              <div class="name"><?= e($o['customer_name']) ?></div>
              <div class="meta">
                <div><i class="fa-solid fa-phone"></i> <span dir="ltr"><?= e($o['phone']) ?></span> <a href="tel:<?= e($o['phone']) ?>" style="color:var(--green);text-decoration:none"><i class="fa-solid fa-phone-volume"></i></a> <a href="https://wa.me/98<?= e(ltrim($o['phone'],'0')) ?>" target="_blank" style="color:#25d366;text-decoration:none"><i class="fa-brands fa-whatsapp"></i></a></div>
                <div><i class="fa-solid fa-location-dot"></i> <?= e($o['address']) ?><?php if($o['city']): ?> - <?= e($o['city']) ?><?php endif; ?></div>
              </div>
            </div>

            <?php if($o['note']): ?>
              <div class="note"><i class="fa-solid fa-sticky-note"></i> <strong>یادداشت:</strong> <?= e($o['note']) ?></div>
            <?php endif; ?>

            <div class="ff-items">
              <?php foreach($items as $it): ?>
              <div class="ff-item">
                <input type="checkbox" class="chk ff-pick" data-order="<?= (int)$o['id'] ?>" data-pid="<?= (int)($it['id'] ?? 0) ?>" data-name="<?= e($it['name']) ?>">
                <div class="info">
                  <div class="name"><?= e($it['name']) ?></div>
                  <div class="sub">
                    <span class="qty">× <?= (int)$it['qty'] ?></span>
                    <span>قیمت واحد: <?= toman($it['price'] ?? 0) ?></span>
                  </div>
                </div>
                <div class="price"><?= toman($it['line']) ?></div>
              </div>
              <?php endforeach; ?>
            </div>

            <div class="ff-progress"><div class="bar" style="width:0%" id="ff-bar-<?= (int)$o['id'] ?>"></div></div>

            <div class="ff-foot">
              <div>
                <div style="font-size:11.5px;color:var(--muted)"><?= count($items) ?> قلم / <?= $items_total ?> عدد</div>
                <div class="ff-total"><?= toman($o['total']) ?> تومان</div>
              </div>
              <div class="ff-actions">
                <?php if($o['status']==='pending'): ?>
                  <a href="admin.php?op=order_status&id=<?= $o['id'] ?>&status=confirmed&page=fulfillment" class="btn btn-success"><i class="fa-solid fa-check"></i> تأیید</a>
                <?php elseif($o['status']==='confirmed'): ?>
                  <a href="admin.php?op=order_status&id=<?= $o['id'] ?>&status=preparing&page=fulfillment" class="btn btn-primary"><i class="fa-solid fa-box-open"></i> شروع آماده‌سازی</a>
                <?php elseif($o['status']==='preparing'): ?>
                  <a href="admin.php?op=order_status&id=<?= $o['id'] ?>&status=ready&page=fulfillment" class="btn btn-warning"><i class="fa-solid fa-truck"></i> آماده ارسال</a>
                <?php elseif($o['status']==='ready'): ?>
                  <a href="admin.php?op=order_status&id=<?= $o['id'] ?>&status=delivered&page=fulfillment" class="btn btn-success"><i class="fa-solid fa-flag-checkered"></i> تحویل شد</a>
                <?php endif; ?>
                <?php if(in_array($o['status'], ['pending','confirmed','preparing','ready'])): ?>
                  <a href="admin.php?op=order_status&id=<?= $o['id'] ?>&status=cancelled&page=fulfillment" class="btn btn-danger" onclick="return confirm('لغو سفارش؟')"><i class="fa-solid fa-ban"></i></a>
                <?php endif; ?>
              </div>
            </div>
          </div>
          <?php endforeach; ?>
        </div>
        <?php else: ?>
          <div class="panel"><div class="panel-body"><div class="empty"><i class="fa-solid fa-bag-shopping"></i><p>سفارش فعالی برای آماده‌سازی یافت نشد.</p></div></div></div>
        <?php endif; ?>

        <script>
        // ذخیره تیک‌ها در localStorage
        function loadPicks(){
          try {
            const saved = JSON.parse(localStorage.getItem('ff_picks')||'{}');
            document.querySelectorAll('.ff-pick').forEach(c=>{
              const k = c.dataset.order+'_'+c.dataset.pid+'_'+c.dataset.name;
              if (saved[k]) { c.checked = true; c.closest('.ff-item').classList.add('checked'); }
            });
            updateProgress();
          } catch(e){}
        }
        function savePick(c){
          try {
            const saved = JSON.parse(localStorage.getItem('ff_picks')||'{}');
            const k = c.dataset.order+'_'+c.dataset.pid+'_'+c.dataset.name;
            if (c.checked) saved[k] = 1; else delete saved[k];
            localStorage.setItem('ff_picks', JSON.stringify(saved));
            c.closest('.ff-item').classList.toggle('checked', c.checked);
            updateProgress();
          } catch(e){}
        }
        function updateProgress(){
          document.querySelectorAll('.ff-card').forEach(card=>{
            const all = card.querySelectorAll('.ff-pick');
            const checked = card.querySelectorAll('.ff-pick:checked');
            const pct = all.length ? (checked.length / all.length) * 100 : 0;
            const bar = card.querySelector('.ff-progress .bar');
            if (bar) bar.style.width = pct + '%';
          });
        }
        document.addEventListener('change', e=>{
          if (e.target.classList && e.target.classList.contains('ff-pick')) savePick(e.target);
        });
        document.addEventListener('DOMContentLoaded', loadPicks);
        </script>

      <?php /* ============== CUSTOM TABS ============== */ elseif ($page=='custom_tabs'):
        $tabs = $pdo->query("SELECT * FROM custom_tabs ORDER BY sort_order, id")->fetchAll();
        $tab_types = [
          'low_stock'=>'رو به اتمام (کم‌موجود)',
          'out_of_stock'=>'ناموجودها',
          'discounted'=>'تخفیف‌دارها',
          'featured'=>'محصولات ویژه',
          'flash_sale'=>'تخفیف لحظه‌ای',
          'newest'=>'جدیدترین محصولات',
        ];
      ?>
        <div class="form-row" style="align-items:start">
          <div class="panel">
            <div class="panel-head"><h2><i class="fa-solid fa-plus"></i> تب جدید</h2></div>
            <div class="panel-body">
              <form method="post" action="admin.php?page=custom_tabs">
                <input type="hidden" name="op" value="save_custom_tab">
                <input type="hidden" name="tab_id" value="0">
                <div class="form-group"><label>عنوان تب *</label><input type="text" name="title" class="form-control" required placeholder="مثال: پیشنهاد شگفت‌انگیز"></div>
                <div class="form-group"><label>نوع محتوا *</label>
                  <select name="tab_type" class="form-control">
                    <?php foreach($tab_types as $k=>$v): ?>
                      <option value="<?= $k ?>"><?= e($v) ?></option>
                    <?php endforeach; ?>
                  </select>
                </div>
                <div class="form-group"><label>آیکون (FontAwesome)</label><input type="text" name="icon" class="form-control" placeholder="مثال: fa-solid fa-fire"></div>
                <div class="form-group"><label>ترتیب</label><input type="number" name="sort_order" class="form-control" value="0"></div>
                <div class="form-group"><label><input type="checkbox" name="is_active" checked> فعال</label></div>
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> ایجاد</button>
              </form>
            </div>
          </div>
          <div class="panel" style="grid-column:span 2">
            <div class="panel-head"><h2><i class="fa-solid fa-layer-group"></i> تب‌های فعال (<?= count($tabs) ?>)</h2></div>
            <div class="panel-body table-wrap">
              <?php if($tabs): ?>
              <table>
                <thead><tr><th>عنوان</th><th>نوع</th><th>آیکون</th><th>ترتیب</th><th>وضعیت</th><th>عملیات</th></tr></thead>
                <tbody>
                  <?php foreach($tabs as $t): ?>
                  <tr>
                    <td><strong><?= e($t['title']) ?></strong></td>
                    <td><span class="tag tag-on"><?= e($tab_types[$t['tab_type']] ?? $t['tab_type']) ?></span></td>
                    <td><?= $t['icon'] ? '<i class="'.$t['icon'].'"></i> <small>'.e($t['icon']).'</small>' : '—' ?></td>
                    <td><?= $t['sort_order'] ?></td>
                    <td><?= $t['is_active'] ? '<span class="tag tag-on">فعال</span>' : '<span class="tag tag-off2">غیرفعال</span>' ?></td>
                    <td style="white-space:nowrap">
                      <a href="admin.php?page=custom_tab_form&id=<?= $t['id'] ?>" class="btn btn-secondary btn-sm"><i class="fa-solid fa-pen"></i> ویرایش</a>
                      <a href="admin.php?op=delete_custom_tab&id=<?= $t['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('حذف؟')"><i class="fa-solid fa-trash"></i> حذف</a>
                    </td>
                  </tr>
                  <?php endforeach; ?>
                </tbody>
              </table>
              <?php else: ?><div class="empty"><i class="fa-solid fa-layer-group"></i><p>هنوز تبی تعریف نشده.</p></div><?php endif; ?>
            </div>
          </div>
        </div>

      <?php elseif ($page=='custom_tab_form'):
        $et = null;
        if (isset($_GET['id'])) {
          $st = $pdo->prepare("SELECT * FROM custom_tabs WHERE id=?");
          $st->execute([(int)$_GET['id']]);
          $et = $st->fetch();
        }
        $tab_types = [
          'low_stock'=>'رو به اتمام (کم‌موجود)',
          'out_of_stock'=>'ناموجودها',
          'discounted'=>'تخفیف‌دارها',
          'featured'=>'محصولات ویژه',
          'flash_sale'=>'تخفیف لحظه‌ای',
          'newest'=>'جدیدترین محصولات',
        ];
      ?>
        <div class="panel">
          <div class="panel-head"><h2><i class="fa-solid fa-layer-group"></i> ویرایش تب</h2><a href="admin.php?page=custom_tabs" class="btn btn-secondary btn-sm"><i class="fa-solid fa-arrow-right"></i> بازگشت</a></div>
          <div class="panel-body">
            <form method="post" action="admin.php?page=custom_tabs">
              <input type="hidden" name="op" value="save_custom_tab">
              <input type="hidden" name="tab_id" value="<?= $et['id'] ?? 0 ?>">
              <div class="form-group"><label>عنوان *</label><input type="text" name="title" class="form-control" required value="<?= e($et['title'] ?? '') ?>"></div>
              <div class="form-group"><label>نوع محتوا *</label>
                <select name="tab_type" class="form-control">
                  <?php foreach($tab_types as $k=>$v): ?>
                    <option value="<?= $k ?>" <?= ($et && $et['tab_type']==$k)?'selected':'' ?>><?= e($v) ?></option>
                  <?php endforeach; ?>
                </select>
              </div>
              <div class="form-group"><label>آیکون</label><input type="text" name="icon" class="form-control" value="<?= e($et['icon'] ?? '') ?>" placeholder="fa-solid fa-fire"></div>
              <div class="form-group"><label>ترتیب</label><input type="number" name="sort_order" class="form-control" value="<?= e($et['sort_order'] ?? 0) ?>"></div>
              <div class="form-group"><label><input type="checkbox" name="is_active" <?= (!$et || $et['is_active'])?'checked':'' ?>> فعال</label></div>
              <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> ذخیره</button>
            </form>
          </div>
        </div>

      <?php /* ============== CUSTOMIZE ============== */ elseif ($page=='customize'): ?>
        <div class="form-row" style="align-items:start">
          <div class="panel">
            <div class="panel-head"><h2><i class="fa-solid fa-image"></i> لوگو و پس‌زمینه</h2></div>
            <div class="panel-body">
              <form method="post" enctype="multipart/form-data" action="admin.php?page=customize">
                <input type="hidden" name="op" value="save_customize">
                <div class="form-group">
                  <label>لوگو فروشگاه</label>
                  <?php if(setting('site_logo')): ?><img src="<?= e(setting('site_logo')) ?>" style="max-height:80px;background:#f0f1f4;padding:8px;border-radius:10px;margin-bottom:8px"><?php endif; ?>
                  <input type="file" name="logo_file" class="form-control" accept="image/*">
                  <?php if(setting('site_logo')): ?><label style="display:flex;align-items:center;gap:6px;margin-top:6px;font-size:13px"><input type="checkbox" name="remove_logo" value="1"> حذف لوگو</label><?php endif; ?>
                </div>
                <div class="form-group">
                  <label>تصویر پس‌زمینه Hero (هدر اصلی)</label>
                  <?php if(setting('site_bg_image')): ?><img src="<?= e(setting('site_bg_image')) ?>" style="width:100%;max-height:120px;object-fit:cover;background:#f0f1f4;padding:4px;border-radius:10px;margin-bottom:8px"><?php endif; ?>
                  <input type="file" name="bg_file" class="form-control" accept="image/*">
                  <?php if(setting('site_bg_image')): ?><label style="display:flex;align-items:center;gap:6px;margin-top:6px;font-size:13px"><input type="checkbox" name="remove_bg" value="1"> حذف پس‌زمینه</label><?php endif; ?>
                </div>
                <div class="form-row">
                  <div class="form-group"><label>رنگ متن روی پس‌زمینه</label><input type="color" name="site_bg_text_color" class="form-control" value="<?= e(setting('site_bg_text_color')) ?>"></div>
                  <div class="form-group"><label>شفافیت لایه تاریک <span class="hint">0 تا 1</span></label><input type="number" name="site_bg_overlay" class="form-control" min="0" max="1" step="0.05" value="<?= e(setting('site_bg_overlay')) ?>"></div>
                </div>
                <div class="form-group"><label>عنوان Hero</label><input type="text" name="hero_title" class="form-control" value="<?= e(setting('hero_title')) ?>" placeholder="خالی = نام فروشگاه"></div>
                <div class="form-group"><label>زیرعنوان Hero</label><input type="text" name="hero_subtitle" class="form-control" value="<?= e(setting('hero_subtitle')) ?>" placeholder="خالی = شعار فروشگاه"></div>
                <div class="form-group"><label>متن بج Hero</label><input type="text" name="hero_badge_text" class="form-control" value="<?= e(setting('hero_badge_text')) ?>"></div>
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> ذخیره</button>
              </form>
            </div>
          </div>

          <div class="panel" style="grid-column:span 2">
            <div class="panel-head">
              <h2><i class="fa-solid fa-pen-to-square"></i> شخصی‌سازی لیبل دکمه‌ها و متن‌ها</h2>
              <a href="admin.php?op=reset_labels&page=customize" class="btn btn-secondary btn-sm" onclick="return confirm('بازنشانی به حالت پیش‌فرض؟')"><i class="fa-solid fa-rotate-left"></i> بازنشانی</a>
            </div>
            <div class="panel-body">
              <form method="post" action="admin.php?page=customize">
                <input type="hidden" name="op" value="save_customize">
                <h4 style="margin-bottom:10px;font-size:14px"><i class="fa-solid fa-toggle-on"></i> روش‌های پرداخت</h4>
                <div class="form-row">
                  <div class="form-group"><label><input type="checkbox" name="show_cod_payment" value="1" <?= setting('show_cod_payment')==='1'?'checked':'' ?>> نمایش گزینه پرداخت نقدی</label></div>
                </div>
                <p style="font-size:12px;color:var(--muted);margin:-4px 0 14px"><i class="fa-solid fa-circle-info"></i> گزینه کالابرگ به‌صورت ساده (بدون نیاز به کد) در صفحه پرداخت نمایش داده می‌شود.</p>

                <h4 style="margin:18px 0 10px;font-size:14px"><i class="fa-solid fa-font"></i> لیبل دکمه‌ها</h4>
                <div class="form-row">
                  <div class="form-group"><label>دکمه سبد خرید (هدر)</label><input type="text" name="btn_cart_label" class="form-control" value="<?= e(setting('btn_cart_label')) ?>"></div>
                  <div class="form-group"><label>دکمه افزودن به سبد</label><input type="text" name="btn_add_to_cart_label" class="form-control" value="<?= e(setting('btn_add_to_cart_label')) ?>"></div>
                  <div class="form-group"><label>دکمه تسویه / ثبت</label><input type="text" name="btn_checkout_label" class="form-control" value="<?= e(setting('btn_checkout_label')) ?>"></div>
                </div>
                <div class="form-row">
                  <div class="form-group"><label>دکمه بازگشت</label><input type="text" name="btn_continue_label" class="form-control" value="<?= e(setting('btn_continue_label')) ?>"></div>
                  <div class="form-group"><label>متن سبد خالی</label><input type="text" name="btn_empty_cart_label" class="form-control" value="<?= e(setting('btn_empty_cart_label')) ?>"></div>
                  <div class="form-group"><label>متن جستجو</label><input type="text" name="btn_search_label" class="form-control" value="<?= e(setting('btn_search_label')) ?>"></div>
                </div>
                <div class="form-row">
                  <div class="form-group"><label>عنوان بخش کد تخفیف</label><input type="text" name="discount_code_label" class="form-control" value="<?= e(setting('discount_code_label')) ?>"></div>
                </div>
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> ذخیره لیبل‌ها</button>
              </form>
            </div>
          </div>
        </div>

        <div class="panel">
          <div class="panel-head"><h2><i class="fa-solid fa-eye"></i> پیش‌نمایش</h2></div>
          <div class="panel-body" style="background:#f5f6f8;padding:30px;border-radius:10px">
            <div style="
              <?php if(setting('site_bg_image')): ?>
              background-image:linear-gradient(rgba(0,0,0,<?= setting('site_bg_overlay') ?>), rgba(0,0,0,<?= setting('site_bg_overlay') ?>)), url('<?= e(setting('site_bg_image')) ?>');
              background-size:cover;background-position:center;
              <?php else: ?>
              background:linear-gradient(135deg,<?= e($primary) ?>,#1d3557);
              <?php endif; ?>
              color:<?= e(setting('site_bg_text_color')) ?>;
              border-radius:14px;padding:40px;text-align:center;position:relative;overflow:hidden;">
              <h1 style="font-size:32px;margin-bottom:12px"><?= e(setting('hero_title') ?: setting('shop_name')) ?></h1>
              <p style="font-size:16px;opacity:.9;margin-bottom:14px"><?= e(setting('hero_subtitle') ?: setting('shop_slogan')) ?></p>
              <span style="display:inline-block;background:rgba(255,255,255,.2);padding:8px 16px;border-radius:30px;font-size:14px"><?= e(setting('hero_badge_text')) ?></span>
            </div>
            <p style="margin-top:14px;font-size:13px;color:#666;text-align:center">
              <i class="fa-solid fa-circle-info"></i> این پیش‌نمایش همان ظاهری است که مشتری در فروشگاه می‌بیند.
            </p>
          </div>
        </div>

      <?php /* ============== SETTINGS ============== */ elseif ($page=='settings'): ?>
        <div class="panel">
          <div class="panel-head"><h2><i class="fa-solid fa-gear"></i> اطلاعات فروشگاه</h2></div>
          <div class="panel-body">
            <form method="post">
              <input type="hidden" name="op" value="save_settings">
              <div class="form-row">
                <div class="form-group"><label>نام فروشگاه</label><input type="text" name="shop_name" class="form-control" value="<?= e(setting('shop_name')) ?>"></div>
                <div class="form-group"><label>شعار فروشگاه</label><input type="text" name="shop_slogan" class="form-control" value="<?= e(setting('shop_slogan')) ?>"></div>
              </div>
              <div class="form-row">
                <div class="form-group"><label>تلفن تماس</label><input type="text" name="shop_phone" class="form-control" value="<?= e(setting('shop_phone')) ?>"></div>
                <div class="form-group"><label>شهر مجاز برای ارسال</label><input type="text" name="allowed_city" class="form-control" value="<?= e(setting('allowed_city')) ?>"></div>
              </div>
              <div class="form-group"><label>آدرس فروشگاه</label><input type="text" name="shop_address" class="form-control" value="<?= e(setting('shop_address')) ?>"></div>
              <div class="form-group"><label>درباره فروشگاه</label><textarea name="shop_about" class="form-control"><?= e(setting('shop_about')) ?></textarea></div>
              <div class="form-row">
                <div class="form-group"><label>موجودی انبار اصلی</label><input type="number" name="stock" class="form-control" value="<?= e($edit_product['stock'] ?? 0) ?>"></div>
                <div class="form-group"><label>حداقل موجودی <span class="hint">هشدار کمبود</span></label><input type="number" name="min_stock" class="form-control" value="<?= e($edit_product['min_stock'] ?? 5) ?>"></div>
              </div>
              <div class="form-row">
                <div class="form-group"><label>بارکد <span class="hint">اختیاری</span></label><input type="text" name="barcode" class="form-control" value="<?= e($edit_product['barcode'] ?? '') ?>" placeholder="کد بارکد"></div>
                <div class="form-group"><label>SKU <span class="hint">اختیاری</span></label><input type="text" name="sku" class="form-control" value="<?= e($edit_product['sku'] ?? '') ?>" placeholder="SKU محصول"></div>
              </div>
              <div class="form-row">
                <div class="form-group"><label>اینستاگرام</label><input type="text" name="shop_instagram" class="form-control" value="<?= e(setting('shop_instagram')) ?>"></div>
                <div class="form-group"><label>تلگرام</label><input type="text" name="shop_telegram" class="form-control" value="<?= e(setting('shop_telegram')) ?>"></div>
              </div>
              <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> ذخیره</button>
            </form>
          </div>
        </div>

        <div class="panel">
          <div class="panel-head"><h2><i class="fa-solid fa-key"></i> تغییر رمز عبور</h2></div>
          <div class="panel-body">
            <form method="post">
              <input type="hidden" name="op" value="change_password">
              <div class="form-row">
                <div class="form-group"><label>رمز فعلی</label><input type="password" name="current_password" class="form-control" required></div>
                <div class="form-group"><label>رمز جدید</label><input type="password" name="new_password" class="form-control" required></div>
                <div class="form-group"><label>تکرار رمز جدید</label><input type="password" name="confirm_password" class="form-control" required></div>
              </div>
              <button type="submit" class="btn btn-danger"><i class="fa-solid fa-key"></i> تغییر رمز</button>
            </form>
          </div>
        </div>

      <?php /* ============== SUPPORT INFO + TICKETS (فقط نمایش + تیکت) ============== */ elseif ($page=='support'):
        // لیست تیکت‌های ادمین
        $tickets = $pdo->query("SELECT t.*, (SELECT COUNT(*) FROM ticket_messages WHERE ticket_id=t.id AND sender='support' AND is_read_by_admin=0) as unread_count, (SELECT message FROM ticket_messages WHERE ticket_id=t.id ORDER BY id DESC LIMIT 1) as last_msg FROM support_tickets t ORDER BY CASE status WHEN 'open' THEN 1 ELSE 2 END, t.updated_at DESC")->fetchAll();
      ?>
        <div class="panel">
          <div class="panel-head">
            <h2><i class="fa-solid fa-headset"></i> راه‌های ارتباط با پشتیبانی سایت</h2>
          </div>
          <div class="panel-body">
            <div style="background:#eaf6fa;border-right:4px solid #1d3557;padding:12px 16px;border-radius:10px;margin-bottom:16px;font-size:13px;color:#1d3557">
              <i class="fa-solid fa-circle-info"></i> در صورت بروز مشکل، بروز رسانی، سفارش ویژگی جدید یا سوال، از پایین تیکت باز کنید. پاسخ، رو در همین پنل دریافت خواهید کرد.
            </div>

            <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(240px,1fr));gap:14px">
              <a href="tel:<?= e(setting('support_phone')) ?>" class="support-card" style="background:linear-gradient(135deg,#2a9d8f,#1d8478);color:#fff;padding:18px;border-radius:14px;text-decoration:none;display:flex;align-items:center;gap:12px">
                <div style="width:48px;height:48px;border-radius:50%;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0"><i class="fa-solid fa-phone"></i></div>
                <div style="min-width:0"><div style="font-size:12px;opacity:.9">تماس تلفنی</div><div style="font-size:16px;font-weight:700;direction:ltr"><?= e(setting('support_phone')) ?></div><div style="font-size:11px;opacity:.85"><?= e(setting('support_name')) ?></div></div>
              </a>
              <a href="https://t.me/<?= e(ltrim(setting('support_telegram'),'@')) ?>" target="_blank" class="support-card" style="background:linear-gradient(135deg,#0088cc,#006699);color:#fff;padding:18px;border-radius:14px;text-decoration:none;display:flex;align-items:center;gap:12px">
                <div style="width:48px;height:48px;border-radius:50%;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0"><i class="fa-brands fa-telegram"></i></div>
                <div style="min-width:0"><div style="font-size:12px;opacity:.9">تلگرام</div><div style="font-size:16px;font-weight:700;direction:ltr"><?= e(setting('support_telegram')) ?></div></div>
              </a>
              <div class="support-card" style="background:linear-gradient(135deg,#9b59b6,#6b3a82);color:#fff;padding:18px;border-radius:14px;display:flex;align-items:center;gap:12px">
                <div style="width:48px;height:48px;border-radius:50%;background:rgba(255,255,255,.2);display:flex;align-items:center;justify-content:center;font-size:20px;flex-shrink:0"><i class="fa-solid fa-comment-dots"></i></div>
                <div style="min-width:0"><div style="font-size:12px;opacity:.9">پیام‌رسان سروش</div><div style="font-size:16px;font-weight:700;direction:ltr"><?= e(setting('support_soroush')) ?></div></div>
              </div>
            </div>
          </div>
        </div>

        <div class="panel">
          <div class="panel-head">
            <h2><i class="fa-solid fa-ticket"></i> تیکت‌های پشتیبانی <?php $unread_total=array_sum(array_column($tickets,'unread_count')); if($unread_total>0): ?><span style="background:#e63946;color:#fff;padding:2px 10px;border-radius:10px;font-size:12px;margin-right:8px"><?= $unread_total ?> پیام جدید</span><?php endif; ?></h2>
            <a href="admin.php?page=ticket_new" class="btn btn-success"><i class="fa-solid fa-plus"></i> تیکت جدید</a>
          </div>
          <div class="panel-body">
            <?php if(!$tickets): ?>
              <div class="empty" style="text-align:center;padding:40px;color:#999">
                <i class="fa-solid fa-comments" style="font-size:54px;margin-bottom:14px;display:block;color:#ddd"></i>
                <p style="margin-bottom:14px">هنوز تیکتی ثبت نکرده‌اید.</p>
                <a href="admin.php?page=ticket_new" class="btn btn-primary"><i class="fa-solid fa-plus"></i> ثبت اولین تیکت</a>
              </div>
            <?php else: ?>
              <div class="table-wrap">
                <table>
                  <thead><tr><th>#</th><th>عنوان</th><th>اولویت</th><th>وضعیت</th><th>آخرین پیام</th><th>آخرین تغییر</th><th>عملیات</th></tr></thead>
                  <tbody>
                    <?php $prio_lbl=['low'=>'کم','normal'=>'عادی','high'=>'بالا','urgent'=>'فوری']; $prio_color=['low'=>'#7c8893','normal'=>'#457b9d','high'=>'#f4a261','urgent'=>'#e63946']; foreach($tickets as $t): ?>
                    <tr>
                      <td><strong>#<?= $t['id'] ?></strong></td>
                      <td>
                        <strong><?= e($t['subject']) ?></strong>
                        <?php if($t['unread_count']>0): ?><span style="background:#e63946;color:#fff;padding:2px 8px;border-radius:8px;font-size:11px;margin-right:6px"><?= $t['unread_count'] ?> پیام جدید</span><?php endif; ?>
                      </td>
                      <td><span class="badge" style="background:<?= $prio_color[$t['priority']] ?>"><?= e($prio_lbl[$t['priority']]) ?></span></td>
                      <td>
                        <?php if($t['status']=='open'): ?><span class="tag tag-on">باز</span>
                        <?php else: ?><span class="tag tag-off">بسته</span><?php endif; ?>
                        <?php if($t['last_reply_by']=='support' && $t['status']=='open'): ?><br><small style="color:#2a9d8f">پاسخ داده شد</small><?php endif; ?>
                      </td>
                      <td style="font-size:12px;color:#666;max-width:280px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"><?= e(mb_substr($t['last_msg'] ?? '',0,60)) ?></td>
                      <td style="font-size:11px;color:#888;white-space:nowrap"><?= e($t['updated_at']) ?></td>
                      <td><a href="admin.php?page=ticket_view&id=<?= $t['id'] ?>" class="btn btn-primary btn-sm"><i class="fa-solid fa-eye"></i> مشاهده</a></td>
                    </tr>
                    <?php endforeach; ?>
                  </tbody>
                </table>
              </div>
            <?php endif; ?>
          </div>
        </div>

      <?php /* ============== تیکت جدید ============== */ elseif ($page=='ticket_new'): ?>
        <div class="panel">
          <div class="panel-head">
            <h2><i class="fa-solid fa-pen-to-square"></i> ثبت تیکت جدید</h2>
            <a href="admin.php?page=support" class="btn btn-secondary btn-sm"><i class="fa-solid fa-arrow-right"></i> بازگشت</a>
          </div>
          <div class="panel-body">
            <form method="post">
              <input type="hidden" name="op" value="open_ticket">
              <div class="form-row">
                <div class="form-group"><label>عنوان تیکت *</label><input type="text" name="subject" class="form-control" required placeholder="مثلاً: درخواست بروز‌رسانی، مشکل در چاپ فاکتور، ..."></div>
                <div class="form-group"><label>اولویت</label>
                  <select name="priority" class="form-control">
                    <option value="low">کم</option>
                    <option value="normal" selected>عادی</option>
                    <option value="high">بالا</option>
                    <option value="urgent">فوری</option>
                  </select>
                </div>
              </div>
              <div class="form-group">
                <label>متن پیام *</label>
                <textarea name="message" class="form-control" rows="7" required placeholder="توضیحات کامل را بنویسید..."></textarea>
              </div>
              <button type="submit" class="btn btn-success"><i class="fa-solid fa-paper-plane"></i> ارسال تیکت</button>
              <a href="admin.php?page=support" class="btn btn-secondary">انصراف</a>
            </form>
          </div>
        </div>

      <?php /* ============== مشاهده تیکت ============== */ elseif ($page=='ticket_view'):
        $tid = (int)($_GET['id'] ?? 0);
        $st = $pdo->prepare("SELECT * FROM support_tickets WHERE id=?"); $st->execute([$tid]);
        $ticket = $st->fetch();
        if (!$ticket) { echo '<div class="alert error">تیکت یافت نشد.</div>'; }
        else {
          // علامت‌گذاری خوانده شده
          $pdo->prepare("UPDATE ticket_messages SET is_read_by_admin=1 WHERE ticket_id=? AND sender='support'")->execute([$tid]);
          $messages = $pdo->prepare("SELECT * FROM ticket_messages WHERE ticket_id=? ORDER BY id ASC");
          $messages->execute([$tid]);
          $msgs = $messages->fetchAll();
          $prio_lbl=['low'=>'کم','normal'=>'عادی','high'=>'بالا','urgent'=>'فوری'];
          $prio_color=['low'=>'#7c8893','normal'=>'#457b9d','high'=>'#f4a261','urgent'=>'#e63946'];
      ?>
        <div class="panel">
          <div class="panel-head">
            <h2><i class="fa-solid fa-ticket"></i> تیکت #<?= $ticket['id'] ?>: <?= e($ticket['subject']) ?></h2>
            <a href="admin.php?page=support" class="btn btn-secondary btn-sm"><i class="fa-solid fa-arrow-right"></i> بازگشت به لیست</a>
          </div>
          <div class="panel-body">
            <div style="display:flex;gap:10px;flex-wrap:wrap;margin-bottom:16px;font-size:13px">
              <span><strong>وضعیت:</strong> <span class="tag <?= $ticket['status']=='open'?'tag-on':'tag-off' ?>"><?= $ticket['status']=='open'?'باز':'بسته' ?></span></span>
              <span><strong>اولویت:</strong> <span class="badge" style="background:<?= $prio_color[$ticket['priority']] ?>"><?= e($prio_lbl[$ticket['priority']]) ?></span></span>
              <span><strong>تاریخ باز:</strong> <?= e($ticket['created_at']) ?></span>
            </div>

            <div style="display:flex;flex-direction:column;gap:14px;margin-bottom:20px">
              <?php foreach($msgs as $m): $is_admin = $m['sender']==='admin'; ?>
              <div style="display:flex;<?= $is_admin?'flex-direction:row-reverse':'' ?>;align-items:flex-start;gap:10px">
                <div style="width:42px;height:42px;border-radius:50%;background:<?= $is_admin?'#1d3557':'#2a9d8f' ?>;color:#fff;display:flex;align-items:center;justify-content:center;font-size:18px;flex-shrink:0">
                  <i class="fa-solid fa-<?= $is_admin?'user':'headset' ?>"></i>
                </div>
                <div style="max-width:70%;<?= $is_admin?'background:#1d3557;color:#fff':'background:#fff;border:1.5px solid #e8e8e8' ?>;padding:12px 16px;border-radius:14px;<?= $is_admin?'border-top-right-radius:4px':'border-top-left-radius:4px' ?>">
                  <div style="font-size:11px;<?= $is_admin?'opacity:.8':'color:#888' ?>;margin-bottom:6px">
                    <strong><?= $is_admin?'شما (ادمین)':'پشتیبانی سایت' ?></strong> • <?= e($m['created_at']) ?>
                  </div>
                  <div style="line-height:1.9;white-space:pre-wrap;font-size:14px"><?= nl2br(e($m['message'])) ?></div>
                </div>
              </div>
              <?php endforeach; ?>
            </div>

            <?php if($ticket['status']=='open'): ?>
            <hr style="margin:18px 0;border:none;border-top:1px dashed #ddd">
            <form method="post">
              <input type="hidden" name="op" value="reply_ticket">
              <input type="hidden" name="ticket_id" value="<?= $ticket['id'] ?>">
              <div class="form-group">
                <label><i class="fa-solid fa-reply"></i> پاسخ شما</label>
                <textarea name="message" class="form-control" rows="4" required placeholder="پاسختان را بنویسید..."></textarea>
              </div>
              <div style="display:flex;gap:8px;flex-wrap:wrap">
                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-paper-plane"></i> ارسال پاسخ</button>
                <button type="submit" name="op" value="close_ticket" formnovalidate class="btn btn-warning" onclick="return confirm('تیکت بسته شود؟')"><i class="fa-solid fa-lock"></i> بستن تیکت</button>
              </div>
            </form>
            <?php else: ?>
              <div style="background:#f8f9fa;padding:14px;border-radius:10px;text-align:center;color:#666">
                <i class="fa-solid fa-lock"></i> این تیکت بسته شده است. برای پیگیری مجدد، <a href="admin.php?page=ticket_new">تیکت جدید</a> باز کنید.
              </div>
            <?php endif; ?>
          </div>
        </div>
      <?php } /* end ticket_view if */ ?>

      <?php /* ============== SUBSCRIPTION ============== */ elseif ($page=='subscription'):
        $lic = license_info(); ?>
        <div class="panel">
          <div class="panel-head"><h2><i class="fa-solid fa-id-card-clip"></i> وضعیت اشتراک سرویس</h2></div>
          <div class="panel-body">
            <div style="background:linear-gradient(135deg,<?= $lic['is_permanent']?'#2a9d8f,#1d8478':($lic['is_expired']||$lic['is_locked']?'#e63946,#a52030':($lic['days_left']<=7?'#f4a261,#d68a4a':'#1d3557,#16334b')) ?>);color:#fff;padding:28px;border-radius:18px;text-align:center;margin-bottom:20px">
              <div style="font-size:46px;margin-bottom:10px">
                <i class="fa-solid fa-<?= $lic['is_permanent']?'infinity':($lic['is_expired']||$lic['is_locked']?'lock':'clock') ?>"></i>
              </div>
              <h2 style="font-size:24px;margin-bottom:6px">پلان فعلی: <?= e($lic['plan_label']) ?></h2>
              <?php if($lic['is_permanent']): ?>
                <p style="opacity:.9">این سرویس دارای اشتراک دائمی است و هیچ محدودیت زمانی ندارد</p>
              <?php elseif($lic['is_locked']): ?>
                <p style="opacity:.95;font-size:18px">سرویس توسط پشتیبان قفل شده است</p>
              <?php elseif($lic['is_expired']): ?>
                <p style="opacity:.95;font-size:18px">اشتراک شما به پایان رسیده است</p>
              <?php else: ?>
                <p style="opacity:.9;font-size:18px">باقیمانده: <strong style="font-size:24px"><?= max(0,$lic['days_left']) ?></strong> روز</p>
              <?php endif; ?>
              <?php if($lic['expires'] && !$lic['is_permanent']): ?>
                <p style="opacity:.85;font-size:13px;margin-top:8px">تاریخ انقضا: <?= e($lic['expires']) ?></p>
              <?php endif; ?>
            </div>

            <?php if(!$lic['is_permanent']): ?>
              <a href="admin.php?page=renew" class="btn btn-primary" style="display:block;text-align:center;padding:14px"><i class="fa-solid fa-arrows-rotate"></i> درخواست تمدید اشتراک</a>
            <?php endif; ?>

            <div style="background:#f8f9fa;padding:18px;border-radius:14px;margin-top:18px">
              <h4 style="margin-bottom:10px;color:#444"><i class="fa-solid fa-circle-info"></i> تماس با پشتیبانی جهت تمدید</h4>
              <p style="color:#666;line-height:2">
                <i class="fa-solid fa-user"></i> <?= e(setting('support_name')) ?><br>
                <i class="fa-solid fa-phone"></i> <span dir="ltr"><?= e(setting('support_phone')) ?></span><br>
                <i class="fa-brands fa-telegram"></i> <span dir="ltr"><?= e(setting('support_telegram')) ?></span><br>
                <i class="fa-solid fa-comment-dots"></i> سروش: <span dir="ltr"><?= e(setting('support_soroush')) ?></span>
              </p>
            </div>
          </div>
        </div>

      <?php /* ============== RENEW REQUEST ============== */ elseif ($page=='renew'):
        $lic = license_info();
        $reqs = $pdo->query("SELECT * FROM renewal_requests ORDER BY id DESC LIMIT 5")->fetchAll();
        ?>
        <?php if($lic['is_locked'] || $lic['is_expired']): ?>
        <div class="alert error" style="background:#fde8e8;color:#c0392b;padding:18px;border-radius:14px;margin-bottom:16px">
          <i class="fa-solid fa-lock"></i> <strong>سرویس شما قفل شده است.</strong> برای ادامه استفاده، لطفاً درخواست تمدید ثبت کرده و با پشتیبانی تماس بگیرید.
        </div>
        <?php endif; ?>

        <?php if($lic['is_permanent']): ?>
          <div class="panel"><div class="panel-body" style="text-align:center;padding:40px">
            <i class="fa-solid fa-infinity" style="font-size:54px;color:#2a9d8f"></i>
            <h2 style="margin-top:16px">اشتراک شما دائمی است</h2>
            <p style="color:#666;margin-top:8px">نیازی به تمدید ندارید</p>
          </div></div>
        <?php else: ?>
        <div style="display:grid;grid-template-columns:repeat(auto-fit,minmax(300px,1fr));gap:16px">
          <div class="panel">
            <div class="panel-head"><h2><i class="fa-solid fa-arrows-rotate"></i> درخواست تمدید</h2></div>
            <div class="panel-body">
              <form method="post">
                <input type="hidden" name="op" value="submit_renewal">
                <div class="form-group">
                  <label>پلان درخواستی</label>
                  <select name="plan_type" class="form-control" required>
                    <option value="monthly">۱ ماهه</option>
                    <option value="quarterly">۳ ماهه</option>
                    <option value="semiannual">۶ ماهه</option>
                    <option value="annual">۱۲ ماهه (سالانه)</option>
                    <option value="permanent">دائمی</option>
                  </select>
                </div>
                <div class="form-group">
                  <label>توضیحات / کد رهگیری پرداخت</label>
                  <textarea name="note" class="form-control" placeholder="بعد از پرداخت، کد رهگیری را در اینجا وارد کنید"></textarea>
                </div>
                <button type="submit" class="btn btn-success" style="width:100%;padding:12px"><i class="fa-solid fa-paper-plane"></i> ثبت درخواست</button>
              </form>
            </div>
          </div>
          <div class="panel">
            <div class="panel-head"><h2><i class="fa-solid fa-credit-card"></i> پرداخت</h2></div>
            <div class="panel-body">
              <div style="background:linear-gradient(135deg,#1d3557,#457b9d);color:#fff;padding:22px;border-radius:14px">
                <div style="font-size:13px;opacity:.85;margin-bottom:6px"><?= e(setting('support_bank_name')) ?></div>
                <div style="font-size:22px;font-weight:700;letter-spacing:3px;direction:ltr;font-family:monospace;text-align:center;padding:10px 0;cursor:pointer" id="cardNum" onclick="copyCard()">
                  <?= e(setting('support_card_number')) ?>
                </div>
                <div style="font-size:13px;opacity:.9;text-align:center">به نام: <?= e(setting('support_card_holder')) ?></div>
                <button type="button" onclick="copyCard()" class="btn btn-secondary btn-sm" style="width:100%;margin-top:14px;background:rgba(255,255,255,.2);color:#fff;border:none"><i class="fa-solid fa-copy"></i> کپی شماره کارت</button>
              </div>
              <p style="font-size:13px;color:#666;margin-top:14px;line-height:2">
                <i class="fa-solid fa-circle-info" style="color:#457b9d"></i> پس از پرداخت، کد رهگیری را در فرم بالا ثبت کنید و با پشتیبانی تماس بگیرید.
              </p>
            </div>
          </div>
        </div>
        <script>
        function copyCard(){
          const t = document.getElementById('cardNum').textContent.trim().replace(/\s|-/g,'');
          navigator.clipboard.writeText(t).then(()=>{alert('شماره کارت کپی شد: '+t);});
        }
        </script>
        <?php endif; ?>

        <?php if(count($reqs)): ?>
        <div class="panel" style="margin-top:18px">
          <div class="panel-head"><h2><i class="fa-solid fa-clock-rotate-left"></i> تاریخچه درخواست‌ها</h2></div>
          <div class="panel-body">
            <div class="table-wrap"><table>
              <thead><tr><th>تاریخ</th><th>پلان</th><th>توضیح</th><th>وضعیت</th></tr></thead>
              <tbody>
              <?php $plan_lbl=['monthly'=>'۱ماه','quarterly'=>'۳ماه','semiannual'=>'۶ماه','annual'=>'سالانه','permanent'=>'دائمی']; foreach($reqs as $r): ?>
                <tr>
                  <td style="font-size:12px"><?= e($r['created_at']) ?></td>
                  <td><strong><?= e($plan_lbl[$r['plan_type']] ?? $r['plan_type']) ?></strong></td>
                  <td style="font-size:12px;color:#666"><?= e($r['note']) ?></td>
                  <td><span class="badge" style="background:<?= $r['status']=='approved'?'#2a9d8f':($r['status']=='rejected'?'#e63946':'#f4a261') ?>"><?= $r['status']=='approved'?'تأیید شد':($r['status']=='rejected'?'رد شد':'در انتظار') ?></span></td>
                </tr>
              <?php endforeach; ?>
              </tbody></table></div>
          </div>
        </div>
        <?php endif; ?>

      <?php /* ============== INVOICE SETTINGS ============== */ elseif ($page=='invoice_settings'): ?>
        <div class="panel">
          <div class="panel-head"><h2><i class="fa-solid fa-print"></i> تنظیمات چاپ فاکتور</h2></div>
          <div class="panel-body">
            <form method="post">
              <input type="hidden" name="op" value="save_invoice_settings">
              
              <h3 style="margin-bottom:14px;color:#1d3557;border-bottom:2px solid #f0f0f0;padding-bottom:8px"><i class="fa-solid fa-file-invoice"></i> فاکتور رسمی A4</h3>
              <div class="form-row">
                <div class="form-group"><label>عنوان فاکتور</label><input type="text" name="invoice_a4_title" class="form-control" value="<?= e(setting('invoice_a4_title')) ?>"></div>
                <div class="form-group"><label>رنگ اصلی فاکتور</label><input type="color" name="invoice_a4_primary_color" class="form-control" value="<?= e(setting('invoice_a4_primary_color')) ?>" style="height:46px;padding:4px"></div>
              </div>
              <div class="form-group"><label>متن پانویس</label><textarea name="invoice_a4_footer" class="form-control" rows="2"><?= e(setting('invoice_a4_footer')) ?></textarea></div>
              <div class="form-group"><label>توضیحات / توضیح سند</label><textarea name="invoice_a4_notes" class="form-control" rows="2"><?= e(setting('invoice_a4_notes')) ?></textarea></div>
              <div class="form-row">
                <div class="form-group"><label>متن بخش مهر و امضاء</label><input type="text" name="invoice_a4_seal_text" class="form-control" value="<?= e(setting('invoice_a4_seal_text')) ?>"></div>
                <div class="form-group" style="display:flex;flex-direction:column;justify-content:center;gap:8px">
                  <label><input type="checkbox" name="invoice_a4_show_logo" <?= setting('invoice_a4_show_logo')=='1'?'checked':'' ?>> نمایش لوگو</label>
                  <label><input type="checkbox" name="invoice_a4_show_signature" <?= setting('invoice_a4_show_signature')=='1'?'checked':'' ?>> نمایش بخش امضاء</label>
                  <label><input type="checkbox" name="invoice_a4_show_barcode" <?= setting('invoice_a4_show_barcode')=='1'?'checked':'' ?>> نمایش بارکد سفارش</label>
                </div>
              </div>

              <h3 style="margin:22px 0 14px;color:#1d3557;border-bottom:2px solid #f0f0f0;padding-bottom:8px"><i class="fa-solid fa-receipt"></i> فاکتور حرارتی (فیش)</h3>
              <div class="form-row">
                <div class="form-group"><label>عنوان فیش</label><input type="text" name="invoice_thermal_title" class="form-control" value="<?= e(setting('invoice_thermal_title')) ?>"></div>
                <div class="form-group"><label>عرض فیش (میلی‌متر)</label>
                  <select name="invoice_thermal_width" class="form-control">
                    <option value="58" <?= setting('invoice_thermal_width')=='58'?'selected':'' ?>>58mm (تقریباً 6سانتی)</option>
                    <option value="80" <?= setting('invoice_thermal_width')=='80'?'selected':'' ?>>80mm (تقریباً 8سانتی)</option>
                    <option value="70" <?= setting('invoice_thermal_width')=='70'?'selected':'' ?>>70mm (7سانتی)</option>
                  </select>
                </div>
              </div>
              <div class="form-group"><label>متن بالای فیش</label><input type="text" name="invoice_thermal_header" class="form-control" value="<?= e(setting('invoice_thermal_header')) ?>"></div>
              <div class="form-group"><label>متن پایین فیش</label><input type="text" name="invoice_thermal_footer" class="form-control" value="<?= e(setting('invoice_thermal_footer')) ?>"></div>
              <div class="form-row">
                <div class="form-group"><label><input type="checkbox" name="invoice_thermal_show_logo" <?= setting('invoice_thermal_show_logo')=='1'?'checked':'' ?>> نمایش لوگو در فیش</label></div>
                <div class="form-group"><label><input type="checkbox" name="invoice_thermal_show_barcode" <?= setting('invoice_thermal_show_barcode')=='1'?'checked':'' ?>> نمایش بارکد سفارش</label></div>
                <div class="form-group"><label><input type="checkbox" name="invoice_show_tracking_qr" <?= setting('invoice_show_tracking_qr')=='1'?'checked':'' ?>> نمایش QR پیگیری</label></div>
              </div>
              <button type="submit" class="btn btn-primary"><i class="fa-solid fa-floppy-disk"></i> ذخیره تنظیمات</button>
            </form>

            <div style="background:#eaf6fa;padding:14px;border-radius:12px;margin-top:18px;font-size:13px;color:#1d3557">
              <i class="fa-solid fa-lightbulb"></i> در صفحه سفارشات، روی هر سفارش دکمه‌های چاپ A4 و چاپ فیش حرارتی را مشاهده خواهید کرد.
            </div>
          </div>
        </div>
      <?php endif; ?>
    </div>
  </div>
</div>

<button class="calc-fab" id="calcFab" title="ماشین حساب"><i class="fa-solid fa-calculator"></i></button>
<div class="calc-modal" id="calcModal">
  <div class="calc-head">
    <h3><i class="fa-solid fa-calculator"></i> ماشین حساب</h3>
    <button class="calc-close" id="calcClose">×</button>
  </div>
  <div class="calc-display" id="calcDisplay">0</div>
  <div class="calc-grid">
    <button class="calc-btn clr" onclick="calcClear()">C</button>
    <button class="calc-btn op" onclick="calcInput('(')">(</button>
    <button class="calc-btn op" onclick="calcInput(')')">)</button>
    <button class="calc-btn op" onclick="calcInput('/')">÷</button>
    <button class="calc-btn" onclick="calcInput('7')">7</button>
    <button class="calc-btn" onclick="calcInput('8')">8</button>
    <button class="calc-btn" onclick="calcInput('9')">9</button>
    <button class="calc-btn op" onclick="calcInput('*')">×</button>
    <button class="calc-btn" onclick="calcInput('4')">4</button>
    <button class="calc-btn" onclick="calcInput('5')">5</button>
    <button class="calc-btn" onclick="calcInput('6')">6</button>
    <button class="calc-btn op" onclick="calcInput('-')">−</button>
    <button class="calc-btn" onclick="calcInput('1')">1</button>
    <button class="calc-btn" onclick="calcInput('2')">2</button>
    <button class="calc-btn" onclick="calcInput('3')">3</button>
    <button class="calc-btn op" onclick="calcInput('+')">+</button>
    <button class="calc-btn" onclick="calcInput('0')">0</button>
    <button class="calc-btn" onclick="calcInput('00')">00</button>
    <button class="calc-btn" onclick="calcInput('.')">.</button>
    <button class="calc-btn op" onclick="calcInput('%')">%</button>
    <button class="calc-btn eq" onclick="calcEquals()" style="grid-column:span 4">=</button>
  </div>
</div>

<script>
const sidebar=document.getElementById('sidebar');
const overlay=document.getElementById('overlay');
const menuToggle=document.getElementById('menuToggle');
if(menuToggle) menuToggle.onclick=()=>{sidebar.classList.add('open');overlay.classList.add('show');};
if(overlay) overlay.onclick=()=>{sidebar.classList.remove('open');overlay.classList.remove('show');};

function calcProfit(){
  const p = parseInt(document.getElementById('priceInput').value) || 0;
  const c = parseInt(document.getElementById('costInput').value) || 0;
  const profit = p - c;
  const margin = c > 0 ? Math.round(profit / c * 100) : 0;
  const display = document.getElementById('profitDisplay');
  display.value = (profit >= 0 ? '+' : '') + profit.toLocaleString('en-US') + ' تومان (' + margin + '٪)';
  display.style.color = profit >= 0 ? 'var(--green)' : 'var(--red)';
  calcFinal();
}
function calcFinal(){
  const p = parseInt(document.getElementById('priceInput').value) || 0;
  const pct = parseInt(document.getElementById('discPct').value) || 0;
  if (pct > 0 && pct < 100) {
    const final = Math.round(p * (1 - pct/100));
    document.getElementById('discPrice').value = final;
    document.getElementById('finalHint').textContent = 'محاسبه خودکار: ' + final.toLocaleString('en-US') + ' تومان';
  } else {
    document.getElementById('finalHint').textContent = '';
  }
}
function calcFromPrice(){
  document.getElementById('discPct').value = '';
  document.getElementById('finalHint').textContent = '';
}
function quickCalc(){
  const p = parseInt(document.getElementById('qPrice').value) || 0;
  const pct = parseInt(document.getElementById('qPct').value) || 0;
  const c = parseInt(document.getElementById('qCost').value) || 0;
  const final = pct > 0 ? Math.round(p * (1 - pct/100)) : p;
  const profit = final - c;
  const margin = final > 0 ? Math.round(profit / final * 100) : 0;
  document.getElementById('qFinal').textContent = final ? final.toLocaleString('en-US') + ' تومان' : '—';
  document.getElementById('qProfit').textContent = (profit >= 0 ? '+' : '') + profit.toLocaleString('en-US') + ' تومان';
  document.getElementById('qMargin').textContent = margin + '٪';
}
calcProfit();

const calcFab = document.getElementById('calcFab');
const calcModal = document.getElementById('calcModal');
const calcDisplay = document.getElementById('calcDisplay');
let calcExpr = '';
function calcUpdate(){ calcDisplay.textContent = calcExpr || '0'; }
function calcInput(v){
  const last = calcExpr.slice(-1);
  if ('+-*/%'.includes(v) && '+-*/%'.includes(last)) {
    calcExpr = calcExpr.slice(0, -1) + v;
  } else { calcExpr += v; }
  calcUpdate();
}
function calcClear(){ calcExpr = ''; calcUpdate(); }
function calcEquals(){
  try {
    const safe = calcExpr.replace(/[^0-9+\-*/.%()]/g, '');
    const result = Function('"use strict"; return (' + safe + ')')();
    calcExpr = String(result);
    calcUpdate();
  } catch(e) {
    calcDisplay.textContent = 'خطا';
    setTimeout(()=>{ calcExpr=''; calcUpdate(); }, 1200);
  }
}
calcFab.onclick = (e)=>{ e.stopPropagation(); calcModal.classList.toggle('show'); };
document.getElementById('calcClose').onclick = ()=> calcModal.classList.remove('show');
document.addEventListener('keydown', (e)=>{
  if (!calcModal.classList.contains('show')) return;
  if (e.key === 'Escape') calcModal.classList.remove('show');
  if (/^[0-9+\-*/.()%]$/.test(e.key)) { calcInput(e.key); e.preventDefault(); }
  if (e.key === 'Enter') { calcEquals(); e.preventDefault(); }
  if (e.key === 'Backspace') { calcExpr = calcExpr.slice(0,-1); calcUpdate(); }
});

<?php if($page=='dashboard'): ?>
const ctx=document.getElementById('ordersChart');
new Chart(ctx,{
  type:'bar',
  data:{
    labels:<?= json_encode(array_column($chart_data,'date')) ?>,
    datasets:[
      {label:'تعداد سفارش',data:<?= json_encode(array_column($chart_data,'count')) ?>,backgroundColor:'<?= $primary ?>',borderRadius:6,yAxisID:'y'},
      {label:'درآمد',data:<?= json_encode(array_column($chart_data,'sum')) ?>,type:'line',borderColor:'#2a9d8f',backgroundColor:'rgba(42,157,143,.1)',tension:.3,fill:true,yAxisID:'y1'},
      {label:'سود',data:<?= json_encode(array_column($chart_data,'profit')) ?>,type:'line',borderColor:'#f4a261',backgroundColor:'rgba(244,162,97,.1)',tension:.3,fill:false,yAxisID:'y1'}
    ]
  },
  options:{
    responsive:true,maintainAspectRatio:false,
    plugins:{legend:{labels:{font:{family:'Vazirmatn'}}}},
    scales:{
      y:{beginAtZero:true,position:'right',ticks:{font:{family:'Vazirmatn'}},title:{display:true,text:'تعداد',font:{family:'Vazirmatn'}}},
      y1:{beginAtZero:true,position:'left',grid:{drawOnChartArea:false},ticks:{font:{family:'Vazirmatn'}}},
      x:{ticks:{font:{family:'Vazirmatn'}}}
    }
  }
});
<?php endif; ?>
</script>
</body>
</html>