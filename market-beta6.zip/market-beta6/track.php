<?php
/**
 * پیگیری سفارش (با کد پیگیری یا شماره تلفن)
 * - مشتری می‌تواند با کد سفارش (مثل TH250601123) یک سفارش خاص را ببیند
 * - یا با شماره تلفن، همه سفارش‌های خود را مشاهده و پیگیری کند
 */
error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE);
ini_set('display_errors', 0);
date_default_timezone_set('Asia/Tehran');
session_start();

define('DB_FILE', __DIR__ . '/shop_data.sqlite');

function db() {
    static $pdo = null;
    if ($pdo === null) {
        $pdo = new PDO('sqlite:' . DB_FILE);
        $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        $pdo->setAttribute(PDO::ATTR_DEFAULT_FETCH_MODE, PDO::FETCH_ASSOC);
    }
    return $pdo;
}

$track_error = '';
$track_order = null;
$track_orders = null; // لیست سفارش‌ها (حالت جستجو با تلفن)
$search_mode = '';    // 'code' یا 'phone'

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $type = $_POST['search_type'] ?? 'code';

    if ($type === 'phone') {
        $phone = trim($_POST['phone'] ?? '');
        $phone_digits = preg_replace('/\D+/', '', $phone);
        if ($phone_digits === '' || strlen($phone_digits) < 10) {
            $track_error = 'لطفاً یک شماره موبایل معتبر وارد کنید.';
        } else {
            // نرمال‌سازی: اگر با 98 شروع شد، تبدیل به 0
            if (substr($phone_digits, 0, 2) === '98') {
                $phone_digits = '0' . substr($phone_digits, 2);
            }
            // جستجو: دقیق، یا شماره‌هایی که شامل این رقم هستند
            $st = db()->prepare("SELECT * FROM orders WHERE phone=? OR phone LIKE ? ORDER BY id DESC");
            $st->execute([$phone_digits, '%' . $phone_digits . '%']);
            $track_orders = $st->fetchAll();
            if (!$track_orders) {
                $track_error = 'سفارشی با این شماره موبایل یافت نشد.';
            } else {
                $search_mode = 'phone';
            }
        }
    } else {
        $code = trim($_POST['track_code'] ?? '');
        if ($code === '') {
            $track_error = 'کد سفارش را وارد کنید.';
        } else {
            $st = db()->prepare("SELECT * FROM orders WHERE order_code=?");
            $st->execute([$code]);
            $track_order = $st->fetch();
            if (!$track_order) {
                $track_error = 'کد سفارش یافت نشد.';
            } else {
                $search_mode = 'code';
            }
        }
    }
}

function e($s) { return htmlspecialchars($s ?? '', ENT_QUOTES, 'UTF-8'); }
function toman($n) { return number_format((int)$n); }

$status_labels = ['pending'=>'در انتظار تأیید','confirmed'=>'تأیید شده','preparing'=>'در حال آماده‌سازی','ready'=>'آماده ارسال','delivered'=>'تحویل شده','cancelled'=>'لغو شده'];
$status_colors = ['pending'=>'#f4a261','confirmed'=>'#2a9d8f','preparing'=>'#9b59b6','ready'=>'#457b9d','delivered'=>'#27ae60','cancelled'=>'#e63946'];
$shop_name = db()->query("SELECT value FROM settings WHERE key='shop_name'")->fetch()['value'] ?? 'فروشگاه';
?>
<!DOCTYPE html>
<html lang="fa" dir="rtl">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>پیگیری سفارش | <?= e($shop_name) ?></title>
<link href="https://fonts.googleapis.com/css2?family=Vazirmatn:wght@400;500;600;700&display=swap" rel="stylesheet">
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/@fortawesome/fontawesome-free@6.4.0/css/all.min.css">
<style>
:root{--primary:#e63946;--bg:#f5f6f8;--card:#fff;--text:#222;--muted:#777;--border:#eee;--green:#2a9d8f;--purple:#9b59b6;--blue:#457b9d;--shadow:0 4px 18px rgba(0,0,0,.07);}
*{margin:0;padding:0;box-sizing:border-box;font-family:'Vazirmatn',sans-serif;}
body{background:var(--bg);color:var(--text);line-height:1.7;min-height:100vh;display:flex;flex-direction:column;}
.container{max-width:780px;margin:0 auto;padding:0 16px;width:100%;}

header{background:#fff;box-shadow:0 2px 10px rgba(0,0,0,.05);padding:18px 0;text-align:center;}
header h1{font-size:22px;font-weight:700;color:var(--primary);}
header a{display:inline-block;margin-top:8px;color:var(--muted);font-size:13px;text-decoration:none;}

.track-section{margin:32px 0;flex:1;}
.track-card{background:var(--card);border-radius:18px;box-shadow:var(--shadow);padding:32px 28px;margin-bottom:20px;}
.track-card h2{font-size:18px;font-weight:700;margin-bottom:18px;display:flex;align-items:center;gap:10px;}

.tabs{display:flex;gap:6px;background:#f0f2f5;padding:5px;border-radius:12px;margin-bottom:18px;}
.tabs button{flex:1;padding:11px 8px;border:none;background:transparent;border-radius:9px;font-weight:600;font-size:13.5px;cursor:pointer;font-family:inherit;color:var(--muted);transition:all .2s ease;}
.tabs button.active{background:#fff;color:var(--primary);box-shadow:0 2px 6px rgba(0,0,0,.06);}

.search-box{display:flex;gap:8px;margin-bottom:8px;}
.search-box input{flex:1;padding:13px 16px;border:2px solid var(--border);border-radius:12px;font-size:15px;outline:none;font-family:inherit;direction:ltr;text-align:right;}
.search-box input:focus{border-color:var(--primary);}
.search-box button{background:var(--primary);color:#fff;padding:0 22px;border-radius:12px;font-weight:600;font-size:14px;border:none;cursor:pointer;font-family:inherit;}
.search-box button:hover{filter:brightness(1.05);}

.search-hint{font-size:12.5px;color:var(--muted);margin-bottom:16px;}

.alert{padding:12px 16px;border-radius:11px;font-size:14px;margin-bottom:16px;display:flex;align-items:center;gap:8px;}
.alert-error{background:#fde8e8;color:#c0392b;}
.alert-success{background:#e7f5ee;color:#1b6e57;}
.alert-info{background:#e7f0ff;color:#1f4d9c;}

/* کارت سفارش در حالت لیست */
.order-card{background:#fafbfc;border:1px solid var(--border);border-radius:14px;padding:18px;margin-bottom:14px;transition:all .2s ease;}
.order-card:hover{box-shadow:0 4px 14px rgba(0,0,0,.06);transform:translateY(-1px);}
.order-card .head{display:flex;justify-content:space-between;align-items:center;flex-wrap:wrap;gap:8px;margin-bottom:10px;padding-bottom:10px;border-bottom:1px dashed var(--border);}
.order-card .code{font-family:monospace;font-size:15px;font-weight:700;color:var(--primary);direction:ltr;}
.order-card .date{font-size:12px;color:var(--muted);}
.order-card .info-row{display:flex;justify-content:space-between;align-items:center;padding:6px 0;font-size:13.5px;}
.order-card .info-row .lbl{color:var(--muted);}
.order-card .info-row .val{font-weight:600;}
.order-card .footer-row{display:flex;justify-content:space-between;align-items:center;margin-top:10px;padding-top:10px;border-top:1px solid var(--border);flex-wrap:wrap;gap:6px;}
.order-card .total{font-weight:700;color:var(--primary);font-size:16px;}

/* کارت سفارش در حالت نمایش جزئیات */
.order-info{background:#f8f9fa;border-radius:12px;padding:18px;margin-bottom:14px;}
.order-info .row{display:flex;justify-content:space-between;padding:7px 0;border-bottom:1px solid var(--border);font-size:14px;gap:10px;}
.order-info .row:last-child{border-bottom:none;}
.order-info .label{color:var(--muted);flex-shrink:0;}
.order-info .value{font-weight:600;text-align:left;}

.status-badge{display:inline-block;padding:5px 12px;border-radius:20px;font-size:12.5px;font-weight:700;color:#fff;}

.timeline{position:relative;padding-right:24px;margin-top:18px;}
.timeline::before{content:'';position:absolute;right:8px;top:6px;bottom:6px;width:3px;background:var(--border);border-radius:3px;}
.timeline-item{position:relative;padding:11px 0 11px 20px;font-size:13.5px;}
.timeline-item::before{content:'';position:absolute;right:-4px;top:16px;width:12px;height:12px;border-radius:50%;background:var(--border);border:2px solid #fff;box-shadow:0 0 0 2px var(--border);}
.timeline-item.active::before{background:var(--green);box-shadow:0 0 0 2px var(--green);}
.timeline-item.cancelled::before{background:#e63946;box-shadow:0 0 0 2px #e63946;}
.timeline-item .time{color:var(--muted);font-size:12px;margin-top:3px;}

.items-list{margin-top:10px;}
.item-row{display:flex;justify-content:space-between;align-items:center;padding:10px 0;border-bottom:1px solid var(--border);font-size:14px;gap:10px;flex-wrap:wrap;}
.item-row:last-child{border-bottom:none;}
.item-name{flex:1;min-width:120px;}
.item-qty{color:var(--muted);font-size:13px;}
.item-price{font-weight:700;color:var(--primary);white-space:nowrap;}

.summary-row{display:flex;justify-content:space-between;font-size:14px;padding:6px 0;color:#555;}
.summary-row.total{font-size:17px;font-weight:800;color:var(--primary);border-top:2px dashed var(--border);padding-top:10px;margin-top:8px;}

.btn-back{display:inline-block;background:var(--primary);color:#fff;padding:11px 22px;border-radius:10px;text-decoration:none;font-size:14px;font-weight:600;margin-top:8px;border:none;cursor:pointer;font-family:inherit;}
.btn-back:hover{filter:brightness(1.05);}

.empty-result{text-align:center;padding:40px 20px;color:var(--muted);}
.empty-result i{font-size:60px;color:#ddd;margin-bottom:14px;display:block;}
.empty-result p{font-size:15px;}

.list-header{display:flex;justify-content:space-between;align-items:center;margin-bottom:14px;flex-wrap:wrap;gap:6px;}
.list-header .count{background:var(--primary);color:#fff;padding:4px 12px;border-radius:14px;font-size:12.5px;font-weight:600;}
.list-header .phone{color:var(--muted);font-size:13px;direction:ltr;}

footer{background:#1d2630;color:#cfd6dd;text-align:center;padding:18px;font-size:13px;margin-top:40px;}
footer a{color:#8b95a0;text-decoration:none;}

@media(max-width:480px){
  .track-card{padding:22px 16px;}
  .item-row{flex-direction:column;align-items:flex-start;gap:4px;}
  .order-card .info-row{flex-direction:column;align-items:flex-start;gap:2px;}
  .order-info .row{flex-direction:column;align-items:flex-start;gap:2px;}
  .order-info .value{text-align:right;}
}
</style>
</head>
<body>

<header>
  <div class="container">
    <h1><i class="fa-solid fa-magnifying-glass-location"></i> پیگیری سفارش</h1>
    <a href="index.php"><i class="fa-solid fa-arrow-right"></i> بازگشت به فروشگاه</a>
  </div>
</header>

<div class="container track-section">
  <div class="track-card">
    <h2><i class="fa-solid fa-truck-fast"></i> سفارش خود را پیگیری کنید</h2>

    <div class="tabs">
      <button type="button" class="active" data-tab="code"><i class="fa-solid fa-hashtag"></i> کد سفارش</button>
      <button type="button" data-tab="phone"><i class="fa-solid fa-mobile-screen"></i> شماره موبایل</button>
    </div>

    <form method="post" action="track.php" id="trackForm">
      <input type="hidden" name="search_type" id="searchType" value="code">

      <div class="search-box" id="codeBox">
        <input type="text" name="track_code" id="codeInput" placeholder="کد پیگیری سفارش (مثال: TH250601123)" value="<?= e($_POST['track_code'] ?? '') ?>">
        <button type="submit"><i class="fa-solid fa-search"></i> پیگیری</button>
      </div>

      <div class="search-box" id="phoneBox" style="display:none">
        <input type="tel" name="phone" id="phoneInput" placeholder="شماره موبایل (مثال: 09123456789)" value="<?= e($_POST['phone'] ?? '') ?>">
        <button type="submit"><i class="fa-solid fa-list"></i> نمایش سفارش‌ها</button>
      </div>
    </form>
    <div class="search-hint" id="searchHint">کد پیگیری را که بعد از ثبت سفارش دریافت کرده‌اید وارد کنید.</div>

    <?php if ($track_error): ?>
      <div class="alert alert-error"><i class="fa-solid fa-circle-exclamation"></i> <?= e($track_error) ?></div>
    <?php endif; ?>

    <?php if ($search_mode === 'phone' && $track_orders): ?>
      <div class="list-header">
        <div>
          <span class="count"><?= count($track_orders) ?> سفارش</span>
          <span style="font-size:13.5px;color:var(--muted);margin-right:8px">یافت شده برای</span>
          <span class="phone" dir="ltr"><?= e($track_orders[0]['phone']) ?></span>
        </div>
        <div style="font-size:12.5px;color:var(--muted)"><i class="fa-solid fa-user"></i> <?= e($track_orders[0]['customer_name']) ?></div>
      </div>

      <?php foreach($track_orders as $o):
        $items = json_decode($o['items'], true) ?: [];
        $items_count = array_sum(array_column($items, 'qty'));
      ?>
      <div class="order-card">
        <div class="head">
          <span class="code"><?= e($o['order_code']) ?></span>
          <span class="date"><?= e($o['created_at']) ?></span>
        </div>
        <div class="info-row">
          <span class="lbl">تعداد اقلام:</span>
          <span class="val"><?= $items_count ?> عدد</span>
        </div>
        <div class="info-row">
          <span class="lbl">روش پرداخت:</span>
          <span class="val"><?= $o['payment_method']==='voucher' ? 'کالابرگ' : 'نقدی درب منزل' ?></span>
        </div>
        <div class="info-row">
          <span class="lbl">آدرس:</span>
          <span class="val" style="text-align:right"><?= e(mb_substr($o['address'],0,40)) ?><?= mb_strlen($o['address'])>40?'…':'' ?></span>
        </div>
        <div class="footer-row">
          <span class="status-badge" style="background:<?= $status_colors[$o['status']] ?? '#777' ?>"><?= $status_labels[$o['status']] ?? $o['status'] ?></span>
          <span class="total"><?= toman($o['total']) ?> تومان</span>
          <form method="post" action="track.php" style="display:inline">
            <input type="hidden" name="search_type" value="code">
            <input type="hidden" name="track_code" value="<?= e($o['order_code']) ?>">
            <button type="submit" class="btn-back" style="background:var(--blue);padding:7px 14px;font-size:12.5px"><i class="fa-solid fa-eye"></i> جزئیات</button>
          </form>
        </div>
      </div>
      <?php endforeach; ?>
    <?php endif; ?>

    <?php if ($search_mode === 'code' && $track_order):
      $items = json_decode($track_order['items'], true) ?: [];
    ?>
    <div class="alert alert-success"><i class="fa-solid fa-circle-check"></i> سفارش پیدا شد!</div>

    <div class="order-info">
      <div class="row"><span class="label">کد سفارش</span><span class="value" style="font-family:monospace;font-size:16px;color:var(--primary)"><?= e($track_order['order_code']) ?></span></div>
      <div class="row"><span class="label">تاریخ ثبت</span><span class="value"><?= e($track_order['created_at']) ?></span></div>
      <div class="row"><span class="label">مشتری</span><span class="value"><?= e($track_order['customer_name']) ?></span></div>
      <div class="row"><span class="label">شماره موبایل</span><span class="value" dir="ltr"><?= e($track_order['phone']) ?></span></div>
      <div class="row"><span class="label">آدرس</span><span class="value"><?= e($track_order['address']) ?></span></div>
      <div class="row"><span class="label">وضعیت</span><span class="value"><span class="status-badge" style="background:<?= $status_colors[$track_order['status']] ?? '#777' ?>"><?= $status_labels[$track_order['status']] ?? $track_order['status'] ?></span></span></div>
      <div class="row"><span class="label">روش پرداخت</span><span class="value"><?= $track_order['payment_method']==='voucher' ? 'کالابرگ' : 'نقدی درب منزل' ?></span></div>
      <?php if ($track_order['discount_code']): ?>
      <div class="row"><span class="label">کد تخفیف</span><span class="value" style="color:var(--green)"><?= e($track_order['discount_code']) ?></span></div>
      <?php endif; ?>
    </div>

    <h3 style="font-size:15px;margin:18px 0 10px"><i class="fa-solid fa-box"></i> اقلام سفارش</h3>
    <div class="order-info" style="padding:0 8px">
      <?php foreach($items as $it): ?>
      <div class="item-row">
        <span class="item-name"><?= e($it['name']) ?></span>
        <span class="item-qty">× <?= (int)$it['qty'] ?></span>
        <span class="item-price"><?= toman($it['line']) ?> تومان</span>
      </div>
      <?php endforeach; ?>
      <?php if ((int)$track_order['discount_amount'] > 0): ?>
      <div class="summary-row" style="color:var(--green);font-weight:600"><span>تخفیف:</span><span>- <?= toman($track_order['discount_amount']) ?> تومان</span></div>
      <?php endif; ?>
      <div class="summary-row total"><span>مبلغ قابل پرداخت:</span><span><?= toman($track_order['total']) ?> تومان</span></div>
    </div>

    <?php if ($track_order['note']): ?>
    <div style="margin-top:14px;padding:12px;background:#fff3cd;border-radius:10px;font-size:13px;color:#856404">
      <i class="fa-solid fa-sticky-note"></i> <strong>توضیحات:</strong> <?= e($track_order['note']) ?>
    </div>
    <?php endif; ?>

    <?php endif; ?>

    <?php if (!$track_order && !$track_orders && !$track_error): ?>
    <div class="empty-result">
      <i class="fa-solid fa-truck-fast"></i>
      <p>برای پیگیری، کد سفارش یا شماره موبایل خود را وارد کنید.</p>
    </div>
    <?php endif; ?>
  </div>

  <div style="text-align:center">
    <a href="index.php" class="btn-back"><i class="fa-solid fa-arrow-right"></i> بازگشت به فروشگاه</a>
  </div>
</div>

<footer>
  © <?= date('Y') ?> <?= e($shop_name) ?> — تمامی حقوق محفوظ است.
</footer>

<script>
// تب‌ها
document.querySelectorAll('.tabs button').forEach(b=>{
  b.onclick = ()=>{
    document.querySelectorAll('.tabs button').forEach(x=>x.classList.remove('active'));
    b.classList.add('active');
    const t = b.dataset.tab;
    document.getElementById('searchType').value = t;
    document.getElementById('codeBox').style.display = (t==='code') ? 'flex' : 'none';
    document.getElementById('phoneBox').style.display = (t==='phone') ? 'flex' : 'none';
    document.getElementById('searchHint').textContent = (t==='code')
      ? 'کد پیگیری را که بعد از ثبت سفارش دریافت کرده‌اید وارد کنید.'
      : 'با وارد کردن شماره موبایل، همه سفارش‌های شما نمایش داده می‌شود.';
  };
});

// اگر نوع جستجو قبلاً phone بوده، تب فعال را نگه دار
<?php if ($search_mode === 'phone'): ?>
document.querySelector('.tabs button[data-tab=phone]').click();
<?php endif; ?>

// فیلتر کاراکترهای ورودی تلفن
document.getElementById('phoneInput')?.addEventListener('input', (e)=>{
  e.target.value = e.target.value.replace(/[^\d+]/g, '');
});
</script>

</body>
</html>
